/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.22-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: onlifinbd
-- ------------------------------------------------------
-- Server version	10.6.22-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'checking',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `initial_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `current_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `accounts_user_id_foreign` (`user_id`),
  CONSTRAINT `accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (11,'CORA MARCIA','checking',1,NULL,'#6366f1',3,'2025-04-27 14:49:45','2025-06-27 00:11:43',0.00,2479.69),(12,'PagBank','checking',1,NULL,'#6366f1',2,'2025-04-28 13:59:45','2025-05-14 01:06:55',0.00,0.00),(13,'Nubank alessandro','checking',1,NULL,'#6366f1',2,'2025-05-05 13:18:42','2025-05-29 18:21:24',257.22,10869.08),(18,'CORA B','checking',1,NULL,'#6366f1',1,'2025-05-14 12:57:37','2025-05-27 14:00:11',0.00,199600.00),(19,'Nu Marcia','checking',1,NULL,'#f264df',1,'2025-05-14 14:16:17','2025-05-14 14:16:17',0.00,0.00),(20,'NU CAIXINHA ALE','checking',1,NULL,'#6366f1',1,'2025-05-14 14:26:21','2025-05-14 14:26:21',210.00,0.00),(21,'Conta Principal','checking',1,NULL,NULL,5,'2025-05-21 14:39:28','2025-05-21 14:39:28',0.00,0.00),(22,'Nubank Miguel','checking',1,NULL,'#6366f1',1,'2025-05-27 15:16:29','2025-05-27 15:16:29',5.00,0.00),(23,'Nubank Beatriz','checking',1,NULL,'#6366f1',1,'2025-05-27 15:18:25','2025-06-27 00:10:08',0.00,-20.00);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_call_logs`
--

DROP TABLE IF EXISTS `ai_call_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_call_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `status_code` int(11) DEFAULT NULL,
  `prompt_preview` text DEFAULT NULL,
  `response_preview` text DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ai_call_logs_user_id_foreign` (`user_id`),
  KEY `ai_call_logs_provider_index` (`provider`),
  KEY `ai_call_logs_model_index` (`model`),
  KEY `ai_call_logs_status_code_index` (`status_code`),
  CONSTRAINT `ai_call_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_call_logs`
--

LOCK TABLES `ai_call_logs` WRITE;
/*!40000 ALTER TABLE `ai_call_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `ai_call_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_user_id_foreign` (`user_id`),
  CONSTRAINT `categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Padaria','expense',NULL,NULL,NULL,1,'2025-04-20 13:42:31','2025-05-22 19:02:02'),(2,'Transporte','expense',NULL,NULL,NULL,1,'2025-04-20 13:42:31','2025-04-20 13:42:31'),(5,'Freelance','income',NULL,NULL,NULL,1,'2025-04-20 13:42:31','2025-04-20 13:42:31'),(18,'Moradia','expense',NULL,NULL,NULL,2,'2025-04-20 13:43:34','2025-04-20 13:43:34'),(23,'Adc embraer','expense','clube de lazer','#3b82f6',NULL,2,'2025-04-28 13:21:27','2025-04-28 13:21:27'),(24,'sabesp','expense','agua','#3b82f6',NULL,2,'2025-04-29 18:24:03','2025-04-29 18:24:03'),(25,'edep','expense','Luz','#3b82f6',NULL,2,'2025-04-29 18:24:37','2025-04-29 18:24:37'),(26,'celular marcia','expense','conta','#3b82f6',NULL,2,'2025-04-29 18:25:33','2025-04-29 18:25:33'),(27,'celular Alessandro','expense','conta','#3b82f6',NULL,2,'2025-04-29 18:26:20','2025-04-29 18:26:20'),(28,'Celular Beatriz','expense','conta','#3b82f6',NULL,2,'2025-04-29 18:26:53','2025-04-29 18:26:53'),(29,'Celular Geovanna','expense','conta','#3b82f6',NULL,2,'2025-04-29 18:27:15','2025-04-29 18:27:15'),(30,'Gaz','expense','conta','#3b82f6',NULL,2,'2025-04-29 18:27:32','2025-04-29 18:27:32'),(31,'Internet casa','expense',NULL,'#3b82f6',NULL,2,'2025-05-05 13:15:21','2025-05-05 13:15:21'),(32,'Apve','expense',NULL,'#3b82f6',NULL,2,'2025-05-05 14:33:01','2025-05-05 14:33:01'),(33,'Onlitec','expense',NULL,'#3b82f6',NULL,2,'2025-05-07 13:58:42','2025-05-07 13:58:42'),(34,'combustivél','expense',NULL,'#3b82f6',NULL,2,'2025-05-07 19:20:29','2025-05-07 19:21:54'),(35,'conta avulsa','expense','Marcia','#3b82f6',NULL,2,'2025-05-07 19:22:59','2025-05-07 19:23:04'),(37,'Lazer','expense','Coronel','#3b82f6',NULL,2,'2025-05-08 13:47:46','2025-05-08 13:47:46'),(38,'Alimentação','expense',NULL,'#3b82f6',NULL,2,'2025-05-08 13:49:33','2025-05-08 13:49:33'),(39,'Quallit','income','serviço avulso','#3b82f6',NULL,2,'2025-05-08 18:38:13','2025-05-08 18:38:13'),(40,'CONTRATO HI','income',NULL,'#3b82f6',NULL,2,'2025-05-08 18:42:22','2025-05-13 22:18:15'),(41,'Hi engenharia','income','Contrato mensal','#3b82f6',NULL,2,'2025-05-08 18:43:04','2025-05-08 18:43:04'),(42,'Farmacia','expense',NULL,'#3b82f6',NULL,2,'2025-05-09 14:10:04','2025-05-09 14:10:04'),(43,'CONTRATO GERENCIAL','income',NULL,'#3b82f6',NULL,2,'2025-05-09 14:11:06','2025-05-13 22:18:00'),(44,'Farmacia','expense',NULL,'#3b82f6',NULL,2,'2025-05-09 14:11:37','2025-05-09 14:11:37'),(45,'CONTRATO HELPSEG','income','contrato mensal de TI','#3b82f6',NULL,2,'2025-05-13 19:01:37','2025-05-13 22:17:44'),(46,'PIX RECEBIDOS','income',NULL,'#3b82f6',NULL,2,'2025-05-14 14:51:18','2025-05-14 14:51:18'),(47,'PIX ENVIADOS','expense',NULL,'#3b82f6',NULL,2,'2025-05-14 14:51:27','2025-05-14 14:51:27'),(48,'Gramavale','income','Contrato Vpn','#3b82f6',NULL,2,'2025-06-04 19:14:56','2025-06-04 19:14:56'),(49,'Débito','expense',NULL,'#3b82f6',NULL,2,'2025-06-05 19:39:44','2025-06-05 19:39:44');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `personal_company` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `companies_owner_id_foreign` (`owner_id`),
  CONSTRAINT `companies_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,3,'Marcia - Empresa Pessoal',1,'2025-06-25 01:46:28','2025-06-25 01:46:28');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_profiles`
--

DROP TABLE IF EXISTS `company_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint(20) unsigned NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `phone_number` varchar(30) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `tax_id` varchar(50) DEFAULT NULL,
  `entity_type` varchar(255) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_profiles_company_id_foreign` (`company_id`),
  KEY `company_profiles_created_by_foreign` (`created_by`),
  KEY `company_profiles_updated_by_foreign` (`updated_by`),
  CONSTRAINT `company_profiles_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `company_profiles_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `company_profiles_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_profiles`
--

LOCK TABLES `company_profiles` WRITE;
/*!40000 ALTER TABLE `company_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `company_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `due_date_notification_settings`
--

DROP TABLE IF EXISTS `due_date_notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `due_date_notification_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `notify_expenses` tinyint(1) NOT NULL DEFAULT 1,
  `notify_incomes` tinyint(1) NOT NULL DEFAULT 1,
  `notify_on_due_date` tinyint(1) NOT NULL DEFAULT 1,
  `notify_days_before` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '[1,3,7]' CHECK (json_valid(`notify_days_before`)),
  `notify_channels` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '["email","database"]' CHECK (json_valid(`notify_channels`)),
  `expense_template_id` bigint(20) unsigned DEFAULT NULL,
  `income_template_id` bigint(20) unsigned DEFAULT NULL,
  `group_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `due_date_notification_settings_user_id_foreign` (`user_id`),
  KEY `due_date_notification_settings_expense_template_id_foreign` (`expense_template_id`),
  KEY `due_date_notification_settings_income_template_id_foreign` (`income_template_id`),
  CONSTRAINT `due_date_notification_settings_expense_template_id_foreign` FOREIGN KEY (`expense_template_id`) REFERENCES `notification_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `due_date_notification_settings_income_template_id_foreign` FOREIGN KEY (`income_template_id`) REFERENCES `notification_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `due_date_notification_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `due_date_notification_settings`
--

LOCK TABLES `due_date_notification_settings` WRITE;
/*!40000 ALTER TABLE `due_date_notification_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `due_date_notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_role`
--

DROP TABLE IF EXISTS `group_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_role_group_id_role_id_unique` (`group_id`,`role_id`),
  KEY `group_role_role_id_foreign` (`role_id`),
  CONSTRAINT `group_role_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_role`
--

LOCK TABLES `group_role` WRITE;
/*!40000 ALTER TABLE `group_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_user`
--

DROP TABLE IF EXISTS `group_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_user_group_id_user_id_unique` (`group_id`,`user_id`),
  KEY `group_user_user_id_foreign` (`user_id`),
  CONSTRAINT `group_user_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_user`
--

LOCK TABLES `group_user` WRITE;
/*!40000 ALTER TABLE `group_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2024_02_23_000000_create_sessions_table',1),(2,'0001_01_01_000001_create_cache_table',2),(3,'0001_01_01_000002_create_jobs_table',2),(4,'2014_10_12_000000_create_users_table',2),(5,'2024_02_23_000001_create_accounts_table',2),(6,'2024_02_23_000002_create_categories_table',2),(7,'2024_02_23_000003_create_transactions_table',2),(8,'2024_02_23_000004_create_roles_table',2),(9,'2024_02_23_000005_create_permissions_table',2),(10,'2024_02_23_000006_create_role_user_table',2),(11,'2024_02_23_000007_create_permission_role_table',2),(12,'2024_02_23_add_status_to_transactions',2),(13,'2025_03_11_230234_add_description_and_color_to_accounts_table',2),(14,'2025_03_11_233944_create_settings_table',2),(15,'2025_03_12_163420_add_description_to_categories_table',2),(16,'2025_03_12_164528_add_is_admin_to_users_table',2),(17,'2025_03_12_174726_create_replicate_settings_table',2),(18,'2025_03_30_203228_add_notification_settings_to_settings_table',2),(19,'2025_03_30_211641_add_is_active_to_users_table',2),(20,'2025_03_30_224441_sync_user_status_fields',2),(21,'2025_03_31_013443_create_password_reset_tokens_table',2),(22,'2025_03_31_015322_create_notifications_table',2),(23,'2025_03_31_020643_create_notification_templates_table',2),(24,'2025_03_31_092521_add_new_columns_to_notification_settings',2),(25,'2025_03_31_095642_add_notification_settings_to_users_table',2),(26,'[timestamp]_add_phone_to_users_table',2),(27,'2025_03_31_162902_add_whatsapp_notifications_to_users_table',3),(28,'2024_02_24_000001_update_accounts_table_structure',4),(29,'2024_04_02_000000_create_system_logs_table',4),(30,'2025_02_24_001122_add_user_id_to_categories_table',4),(31,'2025_02_24_001336_add_user_id_to_categories_table',4),(32,'2025_02_24_001358_add_description_to_categories_table',4),(33,'2025_02_24_110748_add_user_id_to_accounts_table',4),(34,'2025_02_24_114128_update_users_table_add_missing_fields',4),(35,'2025_03_13_011459_add_recurrence_fields_to_transactions_table',4),(36,'2025_04_01_090924_add_provider_to_replicate_settings_table',4),(37,'2025_04_18_023349_add_amount_to_transactions_if_not_exists',4),(38,'2025_04_18_185604_create_model_api_keys_table',4),(39,'xxxx_xx_xx_add_description_to_categories_table',4),(40,'xxxx_xx_xx_add_user_id_to_accounts_table',4),(41,'xxxx_xx_xx_add_user_id_to_categories_table',4),(42,'xxxx_xx_xx_create_role_user_table',4),(43,'xxxx_xx_xx_update_users_table_add_missing_fields',4),(44,'2023_06_01_000000_add_endpoint_to_replicate_settings',5),(45,'2024_03_21_000000_create_open_router_configs_table',5),(46,'2025_04_26_022256_create_ai_call_logs_table',5),(47,'2025_04_29_153132_add_client_and_supplier_to_transactions_table',5),(48,'2025_04_29_171528_add_api_key_to_users_table',5),(49,'2025_04_29_172731_alter_sessions_payload_column',5),(50,'2025_04_29_200000_add_endpoint_to_replicate_settings_table',5),(51,'2025_04_30_234225_update_openrouter_configs_make_endpoint_nullable',5),(52,'2024_03_19_000001_ensure_current_balance_in_accounts',6),(53,'2025_03_12_174727_add_endpoint_to_replicate_settings',7),(54,'2025_05_13_002056_add_current_balance_to_accounts_table',8),(55,'2024_06_07_000001_create_groups_table',9),(56,'2025_05_14_000000_add_profile_photo_to_users_table',9),(57,'2025_05_19_234201_create_companies_table',9),(60,'2025_05_20_002631_create_company_profiles_table',10);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_api_keys`
--

DROP TABLE IF EXISTS `model_api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_api_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(50) NOT NULL COMMENT 'Provedor de IA (openai, anthropic, gemini, etc)',
  `model` varchar(100) NOT NULL COMMENT 'Nome do modelo específico',
  `api_token` text NOT NULL COMMENT 'Chave API específica para este modelo',
  `system_prompt` text DEFAULT NULL COMMENT 'Prompt do sistema específico para este modelo',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Se esta configuração está ativa',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `model_api_keys_provider_model_unique` (`provider`,`model`),
  KEY `model_api_keys_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_api_keys`
--

LOCK TABLES `model_api_keys` WRITE;
/*!40000 ALTER TABLE `model_api_keys` DISABLE KEYS */;
INSERT INTO `model_api_keys` VALUES (1,'gemini','gemini-2.0-flash','AIzaSyBCxoPMWv4oOH84kadpv_n6SRCU2PqWPoA','Prompt para Análise e Categorização de Extrato Bancário\r\n\r\nInstrua a IA a executar os seguintes procedimentos para processar um extrato bancário:\r\n\r\nAnálise do Extrato Bancário:\r\nLeia e interprete todas as transações contidas no extrato bancário fornecido, identificando data, valor, descrição/título e tipo (débito ou crédito).\r\nCategorização das Transações:\r\nClassifique as transações de acordo com as seguintes regras:\r\nDébitos:\r\nTransações identificadas como débitos (ex.: compras, saques) devem ser registradas na categoria Débitos.\r\nPagamentos via QR Code devem ser registrados na categoria Pagamentos.\r\nTransações de transferências enviadas devem ser registradas na categoria Transferências Enviadas.\r\nPagamentos (ex.: boletos, contas) devem ser registrados na categoria Pagamentos.\r\nReceitas:\r\nTransações de recebimentos (ex.: depósitos, Pix recebido) devem ser registradas na categoria Recebimentos.\r\nTransações de transferências recebidas devem ser registradas na categoria Transferências Recebidas.\r\nTransações não identificadas:\r\nCaso não seja possível determinar a categoria de uma transação de débito, registre-a na categoria Débito.\r\nCaso não seja possível determinar a categoria de uma transação de crédito, registre-a na categoria Recebimento.\r\nExtração de Informações do Título:\r\nAnalise o título ou descrição de cada transação para identificar informações sobre quem recebeu (no caso de débitos) ou quem pagou (no caso de créditos).\r\nInsira essas informações no campo Observações da transação.\r\nExemplo: Se o título for \"Pix enviado para João Silva\", registre \"João Silva\" como destinatário no campo Observações.\r\nCaso não haja informações claras sobre o pagador ou recebedor, deixe o campo Observações em branco ou registre \"Não identificado\".\r\nRegistro das Transações:\r\nCadastre cada transação em um sistema ou planilha com os seguintes campos:\r\nData\r\nValor\r\nCategoria (conforme definido acima)\r\nDescrição/Título Original\r\nObservações (com informações sobre pagador/recebedor, quando aplicável)\r\nGaranta que as transações sejam organizadas por data em ordem cronológica.\r\nValidação e Relatório:\r\nApós o processamento, valide se todas as transações foram categorizadas corretamente.\r\nGere um relatório resumido contendo:\r\nTotal de transações processadas.\r\nQuantidade de transações por categoria.\r\nLista de transações com categorização não identificada (se houver), para revisão manual.\r\nTratamento de Erros:\r\nCaso o extrato contenha dados inconsistentes (ex.: valores inválidos, descrições ilegíveis), registre essas transações em uma lista de \"erros\" com uma nota explicativa para revisão posterior.\r\nNão interrompa o processamento em caso de erros parciais; continue processando as demais transações.',1,'2025-04-20 14:09:12','2025-04-20 19:46:50');
/*!40000 ALTER TABLE `model_api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_templates`
--

DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type` enum('expense','income','system','custom') NOT NULL,
  `event` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `email_subject` text DEFAULT NULL,
  `email_content` text DEFAULT NULL,
  `whatsapp_content` text DEFAULT NULL,
  `push_title` text DEFAULT NULL,
  `push_content` text DEFAULT NULL,
  `push_image` varchar(255) DEFAULT NULL,
  `available_variables` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`available_variables`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_templates_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_templates`
--

LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `open_router_configs`
--

DROP TABLE IF EXISTS `open_router_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `open_router_configs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `custom_model` varchar(255) DEFAULT NULL,
  `api_key` varchar(255) NOT NULL,
  `endpoint` varchar(255) DEFAULT NULL,
  `system_prompt` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_router_configs`
--

LOCK TABLES `open_router_configs` WRITE;
/*!40000 ALTER TABLE `open_router_configs` DISABLE KEYS */;
INSERT INTO `open_router_configs` VALUES (1,'openrouter','openai/gpt-4.1',NULL,'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',NULL,'INSTRUÇÕES PARA ANÁLISE DE EXTRATO BANCÁRIO:\r\n\r\nVocê é um assistente financeiro especializado em análise de transações bancárias. Examine cada linha do extrato e extraia os dados em formato JSON.\r\n\r\nCAMPOS A EXTRAIR:\r\n- name: Nome da pessoa, empresa ou serviço envolvido na transação\r\n- transaction_type: \"expense\" ou \"income\" (despesa ou receita)\r\n- date: Data da transação no formato DD/MM/AAAA\r\n- amount: Valor monetário da transação\r\n- category: Classificação da transação conforme lista abaixo\r\n- notes: Detalhes adicionais, códigos, identificadores e outras informações relevantes\r\n\r\nREGRAS DE CATEGORIZAÇÃO:\r\n\r\n1) IDENTIFICAR NOME: Extraia o nome principal da pessoa, empresa ou serviço envolvido na transação.\r\n   Exemplos: \"Supermercado Extra\", \"Salário Empresa ABC\", \"Maria Silva\"\r\n\r\n2) IDENTIFICAR TIPO DE TRANSAÇÃO:\r\n   - expense: pagamentos, compras, débitos, saídas\r\n   - income: salários, recebimentos, créditos, entradas\r\n\r\n3) CATEGORIAS PARA DESPESAS:\r\n   - Alimentação: Supermercados, restaurantes, delivery, padarias\r\n   - Transporte: Combustível, aplicativos de transporte, estacionamento, pedágios\r\n   - Moradia: Aluguel, condomínio, IPTU, manutenção, móveis\r\n   - Contas Fixas: Energia, água, gás, internet, telefonia, TV\r\n   - Saúde: Farmácias, médicos, planos de saúde, exames\r\n   - Educação: Mensalidades, cursos, livros, material escolar\r\n   - Compras: Lojas de departamento, vestuário, eletrônicos\r\n   - Lazer: Cinema, streaming, eventos, viagens\r\n   - Serviços: Assinaturas, academia, serviços domésticos\r\n   - Impostos e Taxas: Tributos, taxas bancárias, anuidades\r\n   - Saques: Retiradas em dinheiro\r\n   - Transferências Enviadas: PIX, TED, DOC enviados\r\n   - Outras Despesas: Gastos não classificados acima\r\n\r\n4) CATEGORIAS PARA RECEITAS:\r\n   - Salário: Pagamentos de salários, proventos, adiantamentos\r\n   - Recebimentos de Clientes: Vendas, pagamentos por serviços\r\n   - Transferências Recebidas: PIX, TED, DOC recebidos\r\n   - Reembolsos: Estornos, devoluções\r\n   - Rendimentos: Juros, dividendos, aluguel recebido\r\n   - Outras Receitas: Receitas não classificadas acima\r\n\r\n5) CAMPO NOTES: Inclua TODA informação adicional não utilizada nos outros campos, como:\r\n   - Códigos e identificadores (ID, número de operação)\r\n   - Detalhes da transação (itens, serviços)\r\n   - Números de documentos (NF, boletos)\r\n   - Dados de conta (agência, conta)\r\n   - Informações complementares\r\n\r\nFORMATO DE SAÍDA OBRIGATÓRIO:\r\nRetorne um array JSON com um objeto para cada transação:\r\n\r\n[\r\n  {\r\n    \"id\": 0,\r\n    \"transaction_type\": \"expense\", \r\n    \"date\": \"DD/MM/AAAA\",\r\n    \"amount\": 150.00,\r\n    \"name\": \"Nome da empresa/pessoa\",\r\n    \"category\": \"Nome da categoria\",\r\n    \"notes\": \"Informações adicionais\",\r\n    \"suggested_category\": \"Nome da categoria\" \r\n  },\r\n  ...\r\n]\r\n\r\nEXEMPLOS:\r\n\r\nInput: Pagto Eletron Boleto 123456 SUPERMERCADO ABC LTDA R$ 150,00 20/04/2024\r\nOutput:\r\n{\r\n  \"id\": 0,\r\n  \"transaction_type\": \"expense\",\r\n  \"date\": \"20/04/2024\",\r\n  \"amount\": 150.00,\r\n  \"name\": \"SUPERMERCADO ABC LTDA\",\r\n  \"category\": \"Alimentação\",\r\n  \"notes\": \"Pagto Eletron Boleto 123456\",\r\n  \"suggested_category\": \"Alimentação\"\r\n}\r\n\r\nInput: TEV PIX Recebido 30/04 Maria Silva CPF123* ID: E123456789 R$ 500,00\r\nOutput:\r\n{\r\n  \"id\": 1,\r\n  \"transaction_type\": \"income\",\r\n  \"date\": \"30/04/2024\",\r\n  \"amount\": 500.00,\r\n  \"name\": \"Maria Silva\",\r\n  \"category\": \"Transferências Recebidas\",\r\n  \"notes\": \"TEV CPF123* ID: E123456789\",\r\n  \"suggested_category\": \"Transferências Recebidas\"\r\n}\r\n\r\nIMPORTANTE: Retorne APENAS o array JSON sem textos explicativos. Não use formatação markdown.','2025-05-01 16:32:42','2025-05-01 16:32:42');
/*!40000 ALTER TABLE `open_router_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('galvatec@onlifin.com.br','$2y$12$SM.Dx0YiQkZHz8Sjm7vylOMNafcWnYDSCH72w9MOSAbZBrLoqmAV2','2025-05-10 14:56:40');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_role_permission_id_foreign` (`permission_id`),
  KEY `permission_role_role_id_foreign` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_role`
--

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
INSERT INTO `permission_role` VALUES (1,1,1,NULL,NULL),(2,2,1,NULL,NULL),(3,3,1,NULL,NULL),(4,4,1,NULL,NULL),(5,5,1,NULL,NULL),(6,6,1,NULL,NULL),(7,7,1,NULL,NULL),(8,8,1,NULL,NULL),(9,7,2,NULL,NULL),(10,9,1,NULL,NULL),(11,10,1,NULL,NULL),(12,11,1,NULL,NULL),(13,12,1,NULL,NULL),(14,13,1,NULL,NULL),(15,14,1,NULL,NULL),(16,15,1,NULL,NULL),(17,16,1,NULL,NULL),(18,17,1,NULL,NULL),(19,18,1,NULL,NULL),(20,19,1,NULL,NULL),(21,20,1,NULL,NULL),(22,21,1,NULL,NULL),(23,22,1,NULL,NULL),(24,23,1,NULL,NULL),(25,24,1,NULL,NULL),(26,25,1,NULL,NULL),(27,26,1,NULL,NULL),(28,27,1,NULL,NULL),(29,28,1,NULL,NULL),(30,29,1,NULL,NULL),(31,30,1,NULL,NULL),(32,31,1,NULL,NULL),(33,32,1,NULL,NULL),(34,33,1,NULL,NULL),(35,34,1,NULL,NULL),(36,35,1,NULL,NULL),(37,36,1,NULL,NULL),(38,37,1,NULL,NULL),(39,38,1,NULL,NULL),(40,39,1,NULL,NULL),(41,40,1,NULL,NULL),(42,41,1,NULL,NULL),(43,42,1,NULL,NULL),(44,43,1,NULL,NULL),(45,44,1,NULL,NULL);
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `category` varchar(255) NOT NULL DEFAULT 'system',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'view_users','Ver usuários','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(2,'create_users','Criar usuários','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(3,'edit_users','Editar usuários','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(4,'delete_users','Excluir usuários','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(5,'view_roles','Ver perfis','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(6,'manage_roles','Gerenciar perfis','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(7,'view_reports','Ver relatórios','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(8,'manage_backups','Gerenciar backups','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(9,'users.view_all','Visualizar todos os usuários','users','2025-06-25 01:48:48','2025-06-25 01:48:48'),(10,'users.view','Visualizar detalhes de um usuário','users','2025-06-25 01:48:48','2025-06-25 01:48:48'),(11,'users.create','Criar novos usuários','users','2025-06-25 01:48:48','2025-06-25 01:48:48'),(12,'users.edit','Editar usuários existentes','users','2025-06-25 01:48:48','2025-06-25 01:48:48'),(13,'users.delete','Excluir usuários do sistema','users','2025-06-25 01:48:48','2025-06-25 01:48:48'),(14,'users.activate','Ativar/desativar usuários','users','2025-06-25 01:48:48','2025-06-25 01:48:48'),(15,'roles.view_all','Visualizar todos os perfis','roles','2025-06-25 01:48:48','2025-06-25 01:48:48'),(16,'roles.view','Visualizar detalhes de um perfil','roles','2025-06-25 01:48:48','2025-06-25 01:48:48'),(17,'roles.create','Criar novos perfis','roles','2025-06-25 01:48:48','2025-06-25 01:48:48'),(18,'roles.edit','Editar perfis existentes','roles','2025-06-25 01:48:48','2025-06-25 01:48:48'),(19,'roles.delete','Excluir perfis do sistema','roles','2025-06-25 01:48:48','2025-06-25 01:48:48'),(20,'roles.assign','Atribuir perfis aos usuários','roles','2025-06-25 01:48:48','2025-06-25 01:48:48'),(21,'transactions.view_all','Visualizar todas as transações','transactions','2025-06-25 01:48:48','2025-06-25 01:48:48'),(22,'transactions.view','Visualizar detalhes de uma transação','transactions','2025-06-25 01:48:48','2025-06-25 01:48:48'),(23,'transactions.create','Criar novas transações','transactions','2025-06-25 01:48:48','2025-06-25 01:48:48'),(24,'transactions.edit','Editar transações existentes','transactions','2025-06-25 01:48:48','2025-06-25 01:48:48'),(25,'transactions.delete','Excluir transações do sistema','transactions','2025-06-25 01:48:48','2025-06-25 01:48:48'),(26,'transactions.import','Importar transações','transactions','2025-06-25 01:48:48','2025-06-25 01:48:48'),(27,'transactions.export','Exportar transações','transactions','2025-06-25 01:48:48','2025-06-25 01:48:48'),(28,'categories.view_all','Visualizar todas as categorias','categories','2025-06-25 01:48:48','2025-06-25 01:48:48'),(29,'categories.view','Visualizar detalhes de uma categoria','categories','2025-06-25 01:48:48','2025-06-25 01:48:48'),(30,'categories.create','Criar novas categorias','categories','2025-06-25 01:48:48','2025-06-25 01:48:48'),(31,'categories.edit','Editar categorias existentes','categories','2025-06-25 01:48:48','2025-06-25 01:48:48'),(32,'categories.delete','Excluir categorias do sistema','categories','2025-06-25 01:48:48','2025-06-25 01:48:48'),(33,'accounts.view_all','Visualizar todas as contas','accounts','2025-06-25 01:48:48','2025-06-25 01:48:48'),(34,'accounts.view','Visualizar detalhes de uma conta','accounts','2025-06-25 01:48:48','2025-06-25 01:48:48'),(35,'accounts.create','Criar novas contas','accounts','2025-06-25 01:48:48','2025-06-25 01:48:48'),(36,'accounts.edit','Editar contas existentes','accounts','2025-06-25 01:48:48','2025-06-25 01:48:48'),(37,'accounts.delete','Excluir contas do sistema','accounts','2025-06-25 01:48:48','2025-06-25 01:48:48'),(38,'reports.view','Visualizar relatórios','reports','2025-06-25 01:48:48','2025-06-25 01:48:48'),(39,'reports.generate','Gerar novos relatórios','reports','2025-06-25 01:48:48','2025-06-25 01:48:48'),(40,'reports.export','Exportar relatórios','reports','2025-06-25 01:48:48','2025-06-25 01:48:48'),(41,'system.settings','Acessar configurações do sistema','system','2025-06-25 01:48:48','2025-06-25 01:48:48'),(42,'system.backup','Criar e restaurar backups','system','2025-06-25 01:48:48','2025-06-25 01:48:48'),(43,'system.logs','Visualizar logs do sistema','system','2025-06-25 01:48:48','2025-06-25 01:48:48'),(44,'system.update','Atualizar o sistema','system','2025-06-25 01:48:48','2025-06-25 01:48:48');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replicate_settings`
--

DROP TABLE IF EXISTS `replicate_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `replicate_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(255) NOT NULL DEFAULT 'openai',
  `api_token` varchar(255) DEFAULT NULL,
  `endpoint` varchar(255) DEFAULT NULL,
  `model_version` varchar(255) NOT NULL DEFAULT 'claude-3-sonnet-20240229',
  `system_prompt` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replicate_settings`
--

LOCK TABLES `replicate_settings` WRITE;
/*!40000 ALTER TABLE `replicate_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `replicate_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  KEY `role_user_user_id_foreign` (`user_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL),(3,1,4,NULL,NULL),(4,1,5,NULL,NULL),(5,1,3,NULL,NULL);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','Acesso total ao sistema','2025-04-20 13:43:34','2025-04-20 13:43:34'),(2,'Usuário','Acesso básico ao sistema','2025-04-20 13:43:34','2025-04-20 13:43:34');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` mediumtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('Olh762tdkv1jLlgmPl8gkdgtBXNiKRr0gGSgKTCR',NULL,'172.20.120.53','Mozilla/5.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoib3dlV2VlOWFGcTN4bUVpS3ZNMENBQnFXQmJxb3k1a240cVZkWXNlTyI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyOToiaHR0cDovL29ubGlmaW4ub25saXRlYy5jb20uYnIiO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyOToiaHR0cDovL29ubGlmaW4ub25saXRlYy5jb20uYnIiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1750981964),('RhX5Tm2YfdpUxfpgQJeuWwWkA9Jzn9N62iT233wQ',3,'172.20.120.53','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','YTo2OntzOjY6Il90b2tlbiI7czo0MDoiTXU0aFZzdUZOVkFmYjZNMmNQUzU2SVpCdFdtRmxValZhUTVuS2Z6TiI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjQ1OiJodHRwOi8vb25saWZpbi5vbmxpdGVjLmNvbS5ici9zZXR0aW5ncy9zeXN0ZW0iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO3M6MTg6ImN1cnJlbnRfY29tcGFueV9pZCI7aToxO30=',1750983128);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `email_notifications_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `email_notify_new_transactions` tinyint(1) NOT NULL DEFAULT 1,
  `email_notify_due_dates` tinyint(1) NOT NULL DEFAULT 1,
  `email_notify_low_balance` tinyint(1) NOT NULL DEFAULT 1,
  `email_low_balance_threshold` decimal(10,2) DEFAULT NULL,
  `whatsapp_notifications_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `whatsapp_number` varchar(255) DEFAULT NULL,
  `whatsapp_notify_new_transactions` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_notify_due_dates` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_notify_low_balance` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_low_balance_threshold` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`),
  KEY `settings_user_id_foreign` (`user_id`),
  CONSTRAINT `settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'site_title','OnliFin Gestão de Finanças',NULL,NULL,NULL,1,1,1,1,NULL,0,NULL,1,1,1,NULL),(2,'site_favicon','storage/favicons/fE9BXNxJZ6Fdj79fVTGQfQ5r9XXQxQxGykm96Zbm.png',NULL,NULL,NULL,1,1,1,1,NULL,0,NULL,1,1,1,NULL),(3,'site_theme','light',NULL,NULL,NULL,1,1,1,1,NULL,0,NULL,1,1,1,NULL),(4,'site_logo','storage/site-logos/RgKJ2Nxm4pC8H701IRochx7m4Wq1uYP83tb17Pn4.png',NULL,NULL,NULL,1,1,1,1,NULL,0,NULL,1,1,1,NULL),(5,'font_size','lg',NULL,NULL,NULL,1,1,1,1,NULL,0,NULL,1,1,1,NULL),(6,'root_font_size','14',NULL,NULL,NULL,1,1,1,1,NULL,0,NULL,1,1,1,NULL),(7,'card_font_size','lg',NULL,NULL,NULL,1,1,1,1,NULL,0,NULL,1,1,1,NULL);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `module` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_logs_user_id_foreign` (`user_id`),
  KEY `system_logs_action_index` (`action`),
  KEY `system_logs_module_index` (`module`),
  KEY `system_logs_created_at_index` (`created_at`),
  CONSTRAINT `system_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('income','expense') NOT NULL,
  `status` enum('pending','paid') NOT NULL DEFAULT 'pending',
  `recurrence_type` enum('none','fixed','installment') NOT NULL DEFAULT 'none',
  `installment_number` int(11) DEFAULT NULL,
  `total_installments` int(11) DEFAULT NULL,
  `next_date` date DEFAULT NULL,
  `date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `fornecedor` varchar(255) DEFAULT NULL,
  `cliente` varchar(255) DEFAULT NULL,
  `amount` bigint(20) NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `notes` text DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `company_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_category_id_foreign` (`category_id`),
  KEY `transactions_account_id_foreign` (`account_id`),
  KEY `transactions_user_id_foreign` (`user_id`),
  CONSTRAINT `transactions_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `transactions_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=441 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (187,'expense','paid','fixed',NULL,NULL,'2025-06-10','2025-05-05','internet',NULL,NULL,13300,31,13,NULL,2,0,'2025-05-05 14:24:54','2025-05-05 14:24:54'),(190,'expense','paid','fixed',NULL,NULL,'2025-06-05','2025-05-12','celular','claro',NULL,4488,28,11,NULL,2,0,'2025-05-05 20:11:36','2025-05-22 18:55:44'),(191,'expense','pending','fixed',NULL,NULL,'2025-06-05','2025-05-15','apve','apve',NULL,14000,32,11,NULL,2,0,'2025-05-05 20:12:21','2025-05-05 20:12:21'),(192,'expense','paid','none',NULL,NULL,NULL,'2025-05-06','faxada',NULL,NULL,20000,33,11,NULL,2,0,'2025-05-07 13:59:18','2025-05-07 13:59:18'),(193,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','combustivél',NULL,NULL,10000,34,11,NULL,2,0,'2025-05-07 19:22:33','2025-05-07 19:22:33'),(194,'expense','pending','none',NULL,NULL,NULL,'2025-05-09','celular','claro',NULL,4872,29,11,NULL,2,0,'2025-05-07 19:43:34','2025-05-07 19:43:34'),(195,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','Bar do coronel',NULL,NULL,38000,37,11,NULL,2,0,'2025-05-08 13:48:37','2025-05-08 13:48:37'),(196,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','Bolo miguel',NULL,NULL,7800,38,11,NULL,2,0,'2025-05-08 13:50:11','2025-05-08 13:50:11'),(197,'income','paid','none',NULL,NULL,NULL,'2025-05-20','Quallit',NULL,NULL,250000,5,11,NULL,2,0,'2025-05-08 18:38:43','2025-05-21 14:50:09'),(198,'income','paid','none',NULL,NULL,NULL,'2025-05-08','Hi engenharia',NULL,'Hi engenharia',39859,41,11,NULL,2,0,'2025-05-08 22:35:12','2025-05-13 22:11:20'),(199,'expense','paid','none',NULL,NULL,NULL,'2025-05-09','remédio','droga raia',NULL,3575,42,11,NULL,2,0,'2025-05-09 14:12:37','2025-05-09 14:12:37'),(200,'expense','paid','none',NULL,NULL,NULL,'2025-05-09','agua','sabesp',NULL,8807,24,11,NULL,2,0,'2025-05-09 14:29:07','2025-05-09 14:29:07'),(201,'income','paid','fixed',NULL,NULL,'2025-06-13','2025-05-16','help seg',NULL,NULL,78600,45,11,NULL,2,0,'2025-05-13 19:02:25','2025-05-16 20:16:12'),(203,'income','paid','fixed',NULL,NULL,'2025-06-10','2025-05-08','GERENCIAL COND',NULL,'GERENCIAL',72000,43,11,NULL,2,0,'2025-05-13 19:06:52','2025-05-13 19:06:52'),(204,'income','paid','none',NULL,NULL,NULL,'2025-04-13','TRABALHO',NULL,'QUALLIT',10000,5,11,NULL,1,0,'2025-05-13 23:59:45','2025-05-13 23:59:45'),(206,'expense','paid','none',NULL,NULL,NULL,'2025-04-14','AGUA',NULL,NULL,10000,24,11,NULL,1,0,'2025-05-14 00:35:04','2025-05-14 13:33:08'),(207,'expense','paid','none',NULL,NULL,NULL,'2025-05-13','MARLI CUNHA MERCADO','MERCADINHO SEVEN',NULL,1441,38,13,NULL,2,0,'2025-05-14 14:20:36','2025-05-14 14:20:36'),(208,'expense','paid','none',NULL,NULL,NULL,'2025-05-14','PIX RECEBIDO',NULL,NULL,4000,18,13,NULL,2,0,'2025-05-14 14:22:36','2025-05-15 15:16:11'),(209,'expense','paid','none',NULL,NULL,NULL,'2025-05-12','MERCADO SEVEN',NULL,NULL,590,38,13,NULL,2,0,'2025-05-14 14:23:20','2025-05-14 14:24:40'),(210,'expense','paid','none',NULL,NULL,NULL,'2025-05-12','RESTAURANTE DUTRA',NULL,NULL,1000,38,13,NULL,2,0,'2025-05-14 14:24:16','2025-05-14 14:24:31'),(211,'expense','paid','none',NULL,NULL,NULL,'2025-05-12','PABLO GUSTAVO','UBER',NULL,1000,2,13,NULL,2,0,'2025-05-14 14:25:43','2025-05-14 14:25:43'),(212,'expense','paid','installment',1,11,'2025-05-22','2025-05-10','NEGOCIAÇÃO NUBANK CREDITO',NULL,NULL,8593,37,13,NULL,2,0,'2025-05-14 14:28:42','2025-05-14 21:57:16'),(213,'expense','paid','none',NULL,NULL,NULL,'2025-05-09','CALDO DE CANA','CARLOS CORREA MACHADO',NULL,2100,38,13,NULL,2,0,'2025-05-14 14:29:56','2025-05-14 14:29:56'),(214,'expense','paid','none',NULL,NULL,NULL,'2025-05-09','ZONA AZUL','MOBILIDADE SJC',NULL,1000,38,13,NULL,2,0,'2025-05-14 14:30:38','2025-05-14 14:30:38'),(215,'income','paid','none',NULL,NULL,NULL,'2025-05-09','VIT SOLUÇÕES',NULL,'DENER T.I',25000,5,13,NULL,2,0,'2025-05-14 14:39:09','2025-05-14 14:39:09'),(216,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','DROGA RAIA','FARMACIA RAIA',NULL,1299,44,13,NULL,2,0,'2025-05-14 14:39:53','2025-05-14 14:39:53'),(217,'income','paid','none',NULL,NULL,NULL,'2025-05-08','SERVIÇO HYPER I.T',NULL,'HYPER I.T',10000,5,13,NULL,2,0,'2025-05-14 14:40:36','2025-05-14 14:40:36'),(218,'income','paid','none',NULL,NULL,NULL,'2025-05-08','PIX RECEBIDO',NULL,'CORA MARCIA',800,5,13,NULL,2,0,'2025-05-14 14:41:16','2025-05-14 14:41:16'),(219,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','RECARGA CELULAR','TIM CELULAR',NULL,2000,27,13,NULL,2,0,'2025-05-14 14:41:58','2025-05-14 14:41:58'),(220,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','PIX RECEBIDO','CORA MARCIA',NULL,2000,27,13,NULL,2,0,'2025-05-14 14:42:55','2025-05-14 14:42:55'),(221,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','CERTIFICADO DIGITAL','ALVES OLIVEIRA SOLUÇÕES (PAULO)',NULL,14500,33,13,NULL,2,0,'2025-05-14 14:43:42','2025-05-14 14:43:42'),(222,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','PIX RECEBIDO','CORA MARCIA',NULL,1000,33,13,NULL,2,0,'2025-05-14 14:44:20','2025-05-14 14:44:20'),(223,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','LUCAS CC MINE ESTAC','LUCAS CC MINE ESTAC',NULL,1600,33,13,NULL,2,0,'2025-05-14 14:45:29','2025-05-14 14:45:29'),(224,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','COMBUSTIVEL','POSTO SETE ESTRELAS',NULL,8000,34,13,NULL,2,0,'2025-05-14 14:46:37','2025-05-14 14:46:37'),(225,'income','paid','none',NULL,NULL,NULL,'2025-05-07','PIX RECEBIDO',NULL,NULL,15000,5,13,NULL,2,0,'2025-05-14 14:47:23','2025-05-14 14:47:23'),(226,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','CALDO DE CANA',NULL,NULL,1350,38,13,NULL,2,0,'2025-05-14 14:48:09','2025-05-14 14:48:09'),(227,'income','paid','none',NULL,NULL,NULL,'2025-05-07','PIX RECEBIDO',NULL,NULL,10000,5,13,NULL,2,0,'2025-05-14 14:48:45','2025-05-14 14:48:45'),(228,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','SSD QUALLIT',NULL,NULL,16900,33,13,NULL,2,0,'2025-05-14 14:50:18','2025-05-14 14:50:18'),(229,'income','paid','none',NULL,NULL,NULL,'2025-05-07','PIX RECEBIDO',NULL,NULL,17000,5,13,NULL,2,0,'2025-05-14 14:50:49','2025-05-14 14:50:49'),(230,'expense','paid','none',NULL,NULL,NULL,'2025-05-06','COMBUSTIVEL','AUTOPOSTO CAPRICHO',NULL,4000,34,13,NULL,2,0,'2025-05-14 15:03:04','2025-05-14 15:03:04'),(231,'expense','paid','none',NULL,NULL,NULL,'2025-05-06','MARINA NICODETE','MARINANICODETE',NULL,700,35,13,NULL,2,0,'2025-05-14 15:04:13','2025-05-14 15:04:13'),(232,'income','paid','none',NULL,NULL,NULL,'2025-05-06','PIX RECEBIDO',NULL,NULL,5000,5,13,NULL,2,0,'2025-05-14 15:04:48','2025-05-14 15:04:48'),(233,'expense','paid','none',NULL,NULL,NULL,'2025-05-05','PIX ENVIADO',NULL,NULL,7900,47,13,NULL,2,0,'2025-05-14 15:05:32','2025-05-14 15:05:32'),(234,'expense','paid','none',NULL,NULL,NULL,'2025-05-05','HOSPEDAGEM ONLITEC','HOSTGATOR',NULL,4718,33,13,NULL,2,0,'2025-05-14 15:15:18','2025-05-14 15:15:18'),(235,'expense','paid','none',NULL,NULL,NULL,'2025-05-05','INTERNET FIXA','TELEFONICA VIVO',NULL,12333,31,13,NULL,2,0,'2025-05-14 15:17:49','2025-05-14 15:17:49'),(236,'expense','paid','none',NULL,NULL,NULL,'2025-05-04','MERCADO SEVEN','MERCADINHO SEVEN',NULL,1099,38,13,NULL,2,0,'2025-05-14 15:21:26','2025-05-14 15:21:26'),(237,'expense','paid','none',NULL,NULL,NULL,'2025-05-03','ASSAI SUPERMERCADO','ASSAI SUPERMERCADO',NULL,24462,38,13,NULL,2,0,'2025-05-14 15:23:35','2025-05-14 15:23:35'),(238,'expense','paid','none',NULL,NULL,NULL,'2025-05-03','COMBUSTIVEL','POSTO SETE ESTRELAS',NULL,3000,34,13,NULL,2,0,'2025-05-14 15:24:23','2025-05-14 15:24:23'),(239,'income','paid','none',NULL,NULL,NULL,'2025-05-03','SERVIÇOS AVULSO',NULL,NULL,10000,5,13,NULL,2,0,'2025-05-14 15:25:40','2025-05-14 15:25:40'),(240,'expense','paid','none',NULL,NULL,NULL,'2025-05-03','PIX ENVIADO',NULL,NULL,4000,47,13,NULL,2,0,'2025-05-14 15:26:25','2025-05-14 15:26:25'),(241,'expense','paid','none',NULL,NULL,NULL,'2025-05-03','MARKETPLACE MERCADOLIVRE','MARKETPLACE MERCADOLIVRE',NULL,3000,35,13,NULL,2,0,'2025-05-14 15:29:03','2025-05-14 15:29:03'),(242,'income','paid','none',NULL,NULL,NULL,'2025-05-03','HELPSEG',NULL,NULL,48000,46,13,NULL,2,0,'2025-05-14 15:32:55','2025-05-14 15:32:55'),(243,'expense','paid','none',NULL,NULL,NULL,'2025-05-03','MERCADO SEVEN',NULL,NULL,977,38,13,NULL,2,0,'2025-05-14 15:33:39','2025-05-14 15:33:39'),(244,'expense','paid','none',NULL,NULL,NULL,'2025-05-02','PIX ENVIADO',NULL,NULL,3200,47,13,NULL,2,0,'2025-05-14 15:35:24','2025-05-14 15:35:24'),(245,'expense','paid','none',NULL,NULL,NULL,'2025-05-02','SUPERMERCADO TENDA','SUPERMERCADO TENDA',NULL,12126,38,13,NULL,2,0,'2025-05-14 15:36:15','2025-05-14 15:36:15'),(246,'income','paid','none',NULL,NULL,NULL,'2025-05-02','INTERCOM IT BRASIL',NULL,'INTERCOM IT BRASIL',12000,5,13,NULL,2,0,'2025-05-14 15:45:01','2025-05-14 15:45:01'),(247,'expense','paid','none',NULL,NULL,NULL,'2025-05-02','COMBUSTIVEL',NULL,NULL,3000,34,13,NULL,2,0,'2025-05-14 15:45:54','2025-05-14 15:45:54'),(248,'expense','paid','none',NULL,NULL,NULL,'2025-05-02','MARLI CUNHA MERCADO','MERCADINHO SEVEN',NULL,1343,38,13,NULL,2,0,'2025-05-14 15:46:58','2025-05-14 15:46:58'),(249,'expense','paid','none',NULL,NULL,NULL,'2025-05-01','CERVEJA','ARMAZEN DA CERVEJA',NULL,3089,37,13,NULL,2,0,'2025-05-14 15:47:39','2025-05-14 15:47:39'),(250,'expense','paid','none',NULL,NULL,NULL,'2025-05-01','MERCADO SEVEN','MERCADINHO SEVEN',NULL,639,38,13,NULL,2,0,'2025-05-14 15:48:07','2025-05-14 15:48:07'),(251,'expense','paid','none',NULL,NULL,NULL,'2025-05-01','MERCADO SEVEN','MERCADINHO SEVEN',NULL,824,38,13,NULL,2,0,'2025-05-14 15:48:51','2025-05-14 15:48:51'),(252,'income','paid','fixed',NULL,NULL,'2025-06-30','2025-05-01','PAGAMENTO INTERNET MICHELLE',NULL,NULL,3000,46,13,NULL,2,0,'2025-05-14 15:49:52','2025-05-14 15:49:52'),(253,'expense','paid','none',NULL,NULL,NULL,'2025-05-14','PIX ENVIADO',NULL,NULL,4000,47,13,NULL,2,0,'2025-05-14 21:54:47','2025-05-14 21:56:56'),(254,'income','paid','none',NULL,NULL,NULL,'2025-05-14','FORMATAÇÃO MAC',NULL,'DANIELLE',8000,5,13,NULL,2,0,'2025-05-14 21:55:33','2025-05-14 21:55:33'),(255,'expense','paid','none',NULL,NULL,NULL,'2025-05-14','COMBUSTIVEL','POSTO SETE ESTRELAS',NULL,3000,34,13,NULL,2,0,'2025-05-14 21:56:04','2025-05-14 21:56:04'),(256,'expense','paid','none',NULL,NULL,NULL,'2025-05-14','SEGURO VIDA NU','NUBANK SEGUROS',NULL,3515,35,13,NULL,2,0,'2025-05-14 21:58:14','2025-05-14 21:58:14'),(257,'expense','paid','none',NULL,NULL,NULL,'2025-05-14','TECLADO E MOUSE','GOOD BLOCK COMPUTADORES',NULL,3750,33,13,NULL,2,0,'2025-05-14 21:58:53','2025-05-14 21:58:53'),(259,'income','paid','none',NULL,NULL,NULL,'2025-05-06','Quallit',NULL,'qualit',199600,39,18,NULL,2,0,'2025-05-15 14:15:42','2025-05-15 14:15:42'),(260,'expense','paid','none',NULL,NULL,NULL,'2025-05-06','tenda',NULL,NULL,45221,1,11,NULL,2,0,'2025-05-15 14:18:01','2025-05-15 14:32:56'),(261,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','Produto de beleza',NULL,NULL,13400,35,11,NULL,2,0,'2025-05-15 14:19:42','2025-05-15 14:31:25'),(262,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','Papelaria',NULL,NULL,4170,35,11,NULL,2,0,'2025-05-15 14:21:29','2025-05-15 14:32:19'),(263,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','drogaria',NULL,NULL,2538,42,11,NULL,2,0,'2025-05-15 14:22:24','2025-05-15 18:52:18'),(264,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','Pix',NULL,NULL,17000,47,11,NULL,2,0,'2025-05-15 14:23:05','2025-05-15 14:31:54'),(265,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','emprestimo',NULL,NULL,7200,35,18,NULL,2,0,'2025-05-15 14:25:18','2025-05-15 14:25:18'),(266,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','shoppe','shoppe',NULL,3250,35,18,NULL,2,0,'2025-05-15 14:26:10','2025-05-15 14:26:10'),(267,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','pix','Alessandro',NULL,10000,47,18,NULL,2,0,'2025-05-15 14:26:46','2025-05-15 14:26:46'),(268,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','Pix','Miguel',NULL,3000,35,18,NULL,2,0,'2025-05-15 14:29:10','2025-05-15 14:29:10'),(269,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','mercadinho',NULL,NULL,1223,38,11,NULL,2,0,'2025-05-15 15:04:51','2025-05-15 15:04:51'),(270,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','alessandro','Alessandro',NULL,1000,47,11,NULL,2,0,'2025-05-15 15:06:53','2025-05-15 15:06:53'),(271,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','alessandro','Alessandro',NULL,2000,47,11,NULL,2,0,'2025-05-15 15:07:19','2025-05-15 15:07:19'),(272,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','alessandro','Alessandro',NULL,800,47,11,NULL,2,0,'2025-05-15 15:07:43','2025-05-15 15:07:43'),(273,'expense','paid','none',NULL,NULL,NULL,'2025-05-07','emprestimo','emprestimo',NULL,3600,35,11,NULL,2,0,'2025-05-15 19:02:04','2025-05-15 19:02:04'),(274,'expense','paid','none',NULL,NULL,NULL,'2025-05-08','emprestimo','emprestimo',NULL,10800,35,11,NULL,2,0,'2025-05-15 19:06:35','2025-05-15 19:06:35'),(275,'expense','paid','none',NULL,NULL,NULL,'2025-05-09','mercadinho','Seven7',NULL,2848,38,11,NULL,2,0,'2025-05-15 19:09:07','2025-05-15 19:09:07'),(276,'expense','paid','none',NULL,NULL,NULL,'2025-05-09','Tenda','Tenda',NULL,28705,38,11,NULL,2,0,'2025-05-16 19:56:30','2025-05-16 19:56:30'),(277,'expense','paid','none',NULL,NULL,NULL,'2025-05-10','Mercadinho','Seven 7',NULL,2530,38,11,NULL,2,0,'2025-05-16 19:59:38','2025-05-16 19:59:38'),(278,'expense','paid','none',NULL,NULL,NULL,'2025-05-10','combustivél','combustivél',NULL,5000,34,11,NULL,2,0,'2025-05-16 20:01:01','2025-05-16 20:01:01'),(279,'expense','paid','none',NULL,NULL,NULL,'2025-05-16','pix marcia','Alessandro',NULL,3000,47,13,NULL,2,0,'2025-05-16 20:01:46','2025-05-16 20:01:46'),(280,'expense','paid','none',NULL,NULL,NULL,'2025-05-11','tenda','Tenda',NULL,11906,38,11,NULL,2,0,'2025-05-16 20:02:32','2025-05-16 20:02:32'),(281,'expense','paid','none',NULL,NULL,NULL,'2025-05-12','gasolina','combustivél',NULL,5000,34,11,NULL,2,0,'2025-05-16 20:03:57','2025-05-16 20:03:57'),(282,'expense','paid','none',NULL,NULL,NULL,'2025-05-12','99','99',NULL,1000,47,11,NULL,2,0,'2025-05-16 20:07:02','2025-05-16 20:07:02'),(283,'expense','paid','none',NULL,NULL,NULL,'2025-05-12','gasolina','combustivél',NULL,3000,34,11,NULL,2,0,'2025-05-16 20:07:44','2025-05-16 20:07:44'),(284,'expense','paid','none',NULL,NULL,NULL,'2025-05-12','mercadinho','Seven7',NULL,975,38,11,NULL,2,0,'2025-05-16 20:08:52','2025-05-16 20:08:52'),(285,'expense','paid','none',NULL,NULL,NULL,'2025-05-13','alessandro','Alessandro',NULL,4000,47,11,NULL,2,0,'2025-05-16 20:09:57','2025-05-16 20:09:57'),(286,'expense','paid','none',NULL,NULL,NULL,'2025-05-13','Barbearia miguel',NULL,NULL,3000,35,11,NULL,2,0,'2025-05-16 20:10:51','2025-05-21 15:28:56'),(287,'expense','paid','none',NULL,NULL,NULL,'2025-05-13','Mercadinho','Seven7',NULL,2773,1,11,NULL,2,0,'2025-05-16 20:11:53','2025-05-16 20:11:53'),(288,'expense','paid','none',NULL,NULL,NULL,'2025-05-14','mercadinho','Seven7',NULL,2281,38,11,NULL,2,0,'2025-05-16 20:12:47','2025-05-16 20:12:47'),(289,'expense','paid','none',NULL,NULL,NULL,'2025-05-16','Pix','Alessandro',NULL,1000,47,13,NULL,2,0,'2025-05-16 20:13:31','2025-05-16 20:13:31'),(290,'expense','paid','none',NULL,NULL,NULL,'2025-05-16','livro beatriz','shoppe',NULL,2978,35,11,NULL,2,0,'2025-05-16 20:15:23','2025-05-16 20:15:23'),(291,'expense','paid','none',NULL,NULL,NULL,'2025-05-16','Tela Notebook','mercado livre',NULL,25598,35,11,NULL,2,0,'2025-05-16 20:17:44','2025-05-16 20:17:44'),(292,'expense','paid','none',NULL,NULL,NULL,'2025-05-16','emprestimo',NULL,NULL,3600,47,11,NULL,2,0,'2025-05-19 15:03:27','2025-05-19 15:03:27'),(293,'expense','paid','none',NULL,NULL,NULL,'2025-05-16','marcia','Alessandro',NULL,600,47,11,NULL,2,0,'2025-05-19 15:04:05','2025-05-19 15:04:05'),(294,'expense','paid','none',NULL,NULL,NULL,'2025-05-17','Choperia do luigui',NULL,NULL,21479,37,11,NULL,2,0,'2025-05-19 15:07:48','2025-05-19 15:07:48'),(295,'expense','paid','none',NULL,NULL,NULL,'2025-05-17','Mercadinho','Seven7',NULL,3192,38,11,NULL,2,0,'2025-05-19 15:08:40','2025-05-19 15:08:40'),(296,'expense','paid','none',NULL,NULL,NULL,'2025-05-17','Açougue',NULL,NULL,7544,1,11,NULL,2,0,'2025-05-19 15:09:38','2025-05-19 15:09:38'),(297,'expense','paid','none',NULL,NULL,NULL,'2025-05-17','combustivél','combustivél',NULL,5000,34,11,NULL,2,0,'2025-05-19 15:11:05','2025-05-19 15:11:05'),(298,'expense','paid','none',NULL,NULL,NULL,'2025-05-17','Beatriz',NULL,NULL,2000,47,11,NULL,2,0,'2025-05-19 15:11:45','2025-05-19 15:11:45'),(299,'expense','paid','none',NULL,NULL,NULL,'2025-05-19','mercado','Tenda',NULL,1989,38,11,NULL,2,0,'2025-05-19 15:12:17','2025-05-19 15:12:17'),(300,'expense','paid','none',NULL,NULL,NULL,'2025-05-17','mercadinho','Seven7',NULL,1399,38,11,NULL,2,0,'2025-05-19 15:13:07','2025-05-19 15:13:07'),(301,'expense','paid','none',NULL,NULL,NULL,'2025-05-18','mercadinho','Seven7',NULL,2615,38,11,NULL,2,0,'2025-05-19 15:13:39','2025-05-19 15:13:39'),(302,'expense','paid','none',NULL,NULL,NULL,'2025-05-18','Beatriz','Alessandro',NULL,3000,37,13,NULL,2,0,'2025-05-19 15:15:00','2025-05-19 15:15:00'),(303,'expense','paid','none',NULL,NULL,NULL,'2025-05-19','mercadinho','Seven7',NULL,3122,38,11,NULL,2,0,'2025-05-19 15:16:32','2025-05-19 15:16:32'),(304,'income','paid','none',NULL,NULL,NULL,'2025-05-06','Quallit',NULL,'qualit',199600,39,11,NULL,2,0,'2025-05-21 14:53:25','2025-05-21 14:53:25'),(305,'expense','paid','none',NULL,NULL,NULL,'2025-05-21','transferencia',NULL,NULL,176150,47,18,NULL,2,0,'2025-05-21 14:57:49','2025-05-21 14:58:14'),(306,'expense','paid','none',NULL,NULL,NULL,'2025-05-20','emprestimo','emprestimo',NULL,3000,47,11,NULL,2,0,'2025-05-21 15:02:45','2025-05-21 15:02:45'),(307,'expense','paid','none',NULL,NULL,NULL,'2025-05-20','emprestimo','emprestimo',NULL,3600,47,11,NULL,2,0,'2025-05-21 15:03:15','2025-05-21 15:03:15'),(308,'expense','paid','none',NULL,NULL,NULL,'2025-05-20','emprestimo','emprestimo',NULL,3600,47,11,NULL,2,0,'2025-05-21 15:03:39','2025-05-21 15:03:39'),(309,'expense','paid','none',NULL,NULL,NULL,'2025-05-20','combustivél','combustivél',NULL,5000,34,11,NULL,2,0,'2025-05-21 15:04:20','2025-05-21 15:04:20'),(310,'expense','paid','none',NULL,NULL,NULL,'2025-05-20','emprestimo','emprestimo',NULL,3600,47,11,NULL,2,0,'2025-05-21 15:05:05','2025-05-21 15:05:05'),(311,'expense','paid','none',NULL,NULL,NULL,'2025-05-20','caldo de cana',NULL,NULL,2100,47,11,NULL,2,0,'2025-05-21 15:06:17','2025-05-21 15:06:17'),(312,'expense','paid','none',NULL,NULL,NULL,'2025-05-20','mercadinho','Seven7',NULL,3317,38,11,NULL,2,0,'2025-05-21 15:07:02','2025-05-21 15:07:02'),(313,'expense','paid','none',NULL,NULL,NULL,'2025-05-20','celular','claro',NULL,5117,27,11,NULL,2,0,'2025-05-21 15:07:55','2025-05-21 15:07:55'),(314,'expense','paid','none',NULL,NULL,NULL,'2025-05-20','mercado','açai',NULL,66076,1,11,NULL,2,0,'2025-05-21 15:08:50','2025-05-21 15:08:50'),(315,'expense','paid','none',NULL,NULL,NULL,'2025-05-20','provedor',NULL,NULL,22000,33,11,NULL,2,0,'2025-05-21 15:09:56','2025-05-21 15:09:56'),(316,'expense','paid','fixed',NULL,NULL,'2025-06-21','2025-05-20','tv',NULL,NULL,3990,35,11,NULL,2,0,'2025-05-21 15:11:02','2025-05-21 15:11:02'),(317,'expense','paid','fixed',NULL,NULL,'2025-06-21','2025-05-21','microsoft',NULL,NULL,7000,33,11,NULL,2,0,'2025-05-21 15:12:26','2025-05-21 15:12:26'),(318,'expense','paid','none',NULL,NULL,NULL,'2025-05-21','faculdade inscrição',NULL,NULL,5900,35,11,NULL,2,0,'2025-05-21 15:13:21','2025-05-21 15:13:21'),(319,'expense','paid','none',NULL,NULL,NULL,'2025-05-21','Pedagio','pedagio',NULL,1230,35,11,NULL,2,0,'2025-05-21 20:38:07','2025-05-21 20:38:07'),(320,'expense','paid','none',NULL,NULL,NULL,'2025-05-21','emprestimo','emprestimo',NULL,3600,47,11,NULL,2,0,'2025-05-21 20:38:58','2025-05-21 20:38:58'),(321,'expense','paid','none',NULL,NULL,NULL,'2025-05-21','celular','claro',NULL,5917,28,11,NULL,2,0,'2025-05-21 20:39:39','2025-05-21 20:39:39'),(322,'expense','paid','none',NULL,NULL,NULL,'2025-05-21','celular','claro',NULL,5486,26,11,NULL,2,0,'2025-05-21 20:40:04','2025-05-21 20:40:04'),(323,'expense','paid','none',NULL,NULL,NULL,'2025-05-21','combustivél','combustivél',NULL,8000,34,11,NULL,2,0,'2025-05-21 20:40:39','2025-05-21 20:40:39'),(324,'expense','paid','none',NULL,NULL,NULL,'2025-05-22','paçoca','paçoca',NULL,3000,38,13,NULL,2,0,'2025-05-22 19:00:37','2025-05-22 19:00:37'),(326,'income','paid','none',NULL,NULL,NULL,'2025-05-07','transferencia para nubank alessandro',NULL,'marcia',1000,5,11,NULL,2,0,'2025-05-27 14:43:36','2025-05-27 14:43:36'),(327,'income','paid','none',NULL,NULL,NULL,'2025-05-08','pix marcia cora',NULL,NULL,1000,46,11,NULL,2,0,'2025-05-27 14:46:10','2025-05-27 14:46:10'),(328,'income','paid','none',NULL,NULL,NULL,'2025-05-08','pix marcia cora',NULL,'marcia',1000,46,13,NULL,2,0,'2025-05-27 14:55:37','2025-05-27 14:55:37'),(329,'income','paid','none',NULL,NULL,NULL,'2025-05-08','pix marcia cora',NULL,'marcia',2000,46,13,NULL,2,0,'2025-05-27 14:56:42','2025-05-27 14:56:42'),(330,'income','paid','none',NULL,NULL,NULL,'2025-05-08','pix Pay pay',NULL,'Alessandro',34,46,13,NULL,2,0,'2025-05-27 14:59:05','2025-05-27 14:59:05'),(331,'income','paid','none',NULL,NULL,NULL,'2025-05-13','pix cora marcia',NULL,'marcia',4000,46,13,NULL,2,0,'2025-05-27 15:01:08','2025-05-27 15:01:08'),(332,'income','paid','none',NULL,NULL,NULL,'2025-05-14','cora marcia',NULL,'marcia',300,46,13,NULL,2,0,'2025-05-27 15:03:12','2025-05-27 15:03:12'),(333,'income','paid','none',NULL,NULL,NULL,'2025-05-14','Pix staley',NULL,'staley',5000,5,13,NULL,2,0,'2025-05-27 15:08:07','2025-05-27 15:08:07'),(334,'income','paid','none',NULL,NULL,NULL,'2025-05-15','Resgate RDB nubank',NULL,'Alessandro',1000,46,13,NULL,2,0,'2025-05-27 15:09:47','2025-05-27 15:09:47'),(335,'income','paid','none',NULL,NULL,NULL,'2025-05-15','Resgate RDB nubank',NULL,'Alessandro',20000,46,13,NULL,2,0,'2025-05-27 15:11:01','2025-05-27 15:11:01'),(336,'income','paid','none',NULL,NULL,NULL,'2025-05-17','pix marcia cora',NULL,'marcia',5000,46,13,NULL,2,0,'2025-05-27 15:12:06','2025-05-27 15:12:06'),(337,'expense','paid','none',NULL,NULL,NULL,'2025-05-19','pix Beatriz','beatriz',NULL,2000,47,23,NULL,2,0,'2025-05-27 15:19:08','2025-05-27 15:19:08'),(338,'income','paid','none',NULL,NULL,NULL,'2025-05-19','cora B',NULL,'Beatriz',2000,46,13,NULL,2,0,'2025-05-28 19:42:51','2025-05-28 19:42:51'),(339,'income','paid','none',NULL,NULL,NULL,'2025-05-20','Nubank miguel',NULL,'miguel',200,46,13,NULL,2,0,'2025-05-28 19:43:48','2025-05-28 19:43:48'),(340,'income','paid','none',NULL,NULL,NULL,'2025-05-21','Pix',NULL,'karina',6000,46,13,NULL,2,0,'2025-05-29 18:16:33','2025-05-29 18:16:33'),(341,'income','paid','none',NULL,NULL,NULL,'2025-05-22','MFM pix',NULL,'comercio e serviço de informatica',8000,46,13,NULL,2,0,'2025-05-29 18:17:59','2025-05-29 18:17:59'),(342,'income','paid','none',NULL,NULL,NULL,'2025-05-23','Pix Alessandro cora',NULL,'Alessandro',29200,46,13,NULL,2,0,'2025-05-29 18:19:37','2025-05-29 18:19:37'),(343,'income','paid','none',NULL,NULL,NULL,'2025-05-23','Pix Nektech',NULL,'Nektech',10000,46,13,NULL,2,0,'2025-05-29 18:21:24','2025-05-29 18:21:24'),(344,'income','paid','none',NULL,NULL,NULL,'2025-05-23','Nektech informatica',NULL,'nektech',10000,46,11,NULL,2,0,'2025-06-04 19:02:39','2025-06-04 19:02:39'),(345,'income','paid','none',NULL,NULL,NULL,'2025-06-04','Quallit',NULL,NULL,224000,5,11,NULL,2,0,'2025-06-04 19:06:14','2025-06-04 19:26:50'),(346,'income','paid','fixed',NULL,NULL,'2025-07-10','2025-06-10','Gerencial',NULL,NULL,72000,43,11,NULL,2,0,'2025-06-04 19:08:00','2025-06-06 13:38:22'),(349,'income','paid','fixed',NULL,NULL,'2025-07-04','2025-06-05','gramavale',NULL,NULL,5000,48,11,NULL,2,0,'2025-06-04 19:15:37','2025-06-11 19:40:43'),(350,'expense','paid','none',NULL,NULL,NULL,'2025-05-21','loterica','Alessandro',NULL,1000,47,11,NULL,2,0,'2025-06-04 19:23:43','2025-06-04 19:23:43'),(351,'expense','paid','none',NULL,NULL,NULL,'2025-05-21','mercado','Tenda',NULL,14990,38,11,NULL,2,0,'2025-06-04 19:24:34','2025-06-04 19:24:34'),(352,'expense','paid','none',NULL,NULL,NULL,'2025-05-21','banco','pagseguro',NULL,1399,47,11,NULL,2,0,'2025-06-04 19:25:22','2025-06-04 19:25:22'),(353,'expense','paid','none',NULL,NULL,NULL,'2025-05-22','pix','Alessandro',NULL,26,47,11,NULL,2,0,'2025-06-04 19:26:06','2025-06-04 19:26:06'),(354,'expense','pending','none',NULL,NULL,NULL,'2025-05-15','Apve','clube de lazer',NULL,7000,32,11,NULL,2,0,'2025-06-04 19:32:40','2025-06-04 19:32:40'),(359,'expense','pending','none',NULL,NULL,NULL,'2025-06-04','claro alessandro','claro',NULL,4512,27,11,NULL,2,0,'2025-06-04 19:44:16','2025-06-04 19:44:16'),(360,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','Desodorante boticario',NULL,NULL,13900,35,11,NULL,2,0,'2025-06-04 19:47:18','2025-06-23 18:44:31'),(362,'expense','pending','none',NULL,NULL,NULL,'2025-05-10','internet','Vivo',NULL,12353,31,11,NULL,2,0,'2025-06-04 19:55:20','2025-06-04 19:55:20'),(363,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','emprestimo','emprestimo',NULL,3000,47,11,NULL,2,0,'2025-06-05 19:28:28','2025-06-05 19:28:28'),(364,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','emprestimo 2','emprestimo',NULL,3000,47,11,NULL,2,0,'2025-06-05 19:28:58','2025-06-05 19:28:58'),(365,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','emprestimo 3','emprestimo',NULL,3600,47,11,NULL,2,0,'2025-06-05 19:29:36','2025-06-05 19:29:36'),(366,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','emprestimo 4','emprestimo',NULL,3600,47,11,NULL,2,0,'2025-06-05 19:30:09','2025-06-05 19:30:09'),(367,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','Hostgator','hostgator',NULL,4718,1,11,NULL,2,0,'2025-06-05 19:31:03','2025-06-05 19:31:03'),(368,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','cartão de crédito Beatriz','Nubank',NULL,13997,47,11,NULL,2,0,'2025-06-05 19:31:57','2025-06-05 19:31:57'),(369,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','Pix Beatriz','nubank',NULL,10000,47,11,NULL,2,0,'2025-06-05 19:33:04','2025-06-05 19:33:04'),(370,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','convênio','Cartão de todos',NULL,3090,47,11,NULL,2,0,'2025-06-05 19:34:17','2025-06-05 19:34:17'),(371,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','combustivél','combustivél',NULL,5000,34,11,NULL,2,0,'2025-06-05 19:34:52','2025-06-05 19:34:52'),(372,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','mercado','Açaí',NULL,37769,38,11,NULL,2,0,'2025-06-05 19:35:40','2025-06-05 19:35:40'),(373,'expense','paid','none',NULL,NULL,NULL,'2025-06-04','mercado','Tenda',NULL,14982,47,11,NULL,2,0,'2025-06-05 19:36:49','2025-06-05 19:36:49'),(374,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','pedagio','concessionaria',NULL,790,47,11,NULL,2,0,'2025-06-05 19:38:24','2025-06-05 19:38:24'),(375,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','Pedagio','concessionaria',NULL,440,47,11,NULL,2,0,'2025-06-05 19:39:08','2025-06-05 19:39:08'),(376,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','compra débito',NULL,NULL,600,49,11,NULL,2,0,'2025-06-05 19:40:47','2025-06-06 13:39:18'),(377,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','Pedagio','concessionaria',NULL,440,47,11,NULL,2,0,'2025-06-05 19:41:31','2025-06-05 19:41:31'),(378,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','Pedagio','concessionaria',NULL,790,47,11,NULL,2,0,'2025-06-05 19:42:05','2025-06-05 19:42:05'),(379,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','combustivél','combustivél',NULL,8000,34,11,NULL,2,0,'2025-06-05 19:42:35','2025-06-05 19:42:35'),(380,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','droga raia','farmacia',NULL,1190,49,11,NULL,2,0,'2025-06-05 19:43:19','2025-06-05 19:43:19'),(381,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','emprestimo','emprestimo',NULL,13200,47,11,NULL,2,0,'2025-06-05 19:43:58','2025-06-05 19:43:58'),(382,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','celular','claro',NULL,5930,29,11,NULL,2,0,'2025-06-06 13:40:52','2025-06-06 13:40:52'),(383,'income','paid','none',NULL,NULL,NULL,'2025-06-07','serviço avulso',NULL,'Marcos',25000,46,11,NULL,2,0,'2025-06-11 19:43:29','2025-06-11 19:43:29'),(384,'income','paid','none',NULL,NULL,NULL,'2025-06-10','Serviço Village',NULL,'Condominio Village',152400,46,11,NULL,2,0,'2025-06-11 19:44:32','2025-06-11 19:44:32'),(385,'income','paid','none',NULL,NULL,NULL,'2025-06-11','serviço nobreak',NULL,'GERENCIAL',19000,46,11,NULL,2,0,'2025-06-11 19:45:36','2025-06-11 19:45:36'),(386,'income','paid','none',NULL,NULL,NULL,'2025-06-11','condominio',NULL,'Cond Ed Green Office',19000,46,11,NULL,2,0,'2025-06-11 19:46:24','2025-06-11 19:46:24'),(387,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','combustivél','combustivél',NULL,8000,34,11,NULL,2,0,'2025-06-11 19:52:18','2025-06-11 19:52:18'),(388,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','droga raia','farmacia',NULL,1198,42,11,NULL,2,0,'2025-06-11 19:54:57','2025-06-11 19:54:57'),(389,'expense','paid','none',NULL,NULL,NULL,'2025-06-11','emprestimo','emprestimo',NULL,13000,47,11,NULL,2,0,'2025-06-11 19:55:47','2025-06-11 19:55:47'),(390,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','pasteleiro','lanchonete',NULL,2450,38,11,NULL,2,0,'2025-06-11 20:01:30','2025-06-11 20:01:30'),(391,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','parquimentro','ancar',NULL,1200,35,11,NULL,2,0,'2025-06-11 20:02:34','2025-06-11 20:02:34'),(392,'expense','paid','none',NULL,NULL,NULL,'2025-06-05','bebida','Armazem',NULL,2511,37,11,NULL,2,0,'2025-06-11 20:04:49','2025-06-11 20:04:49'),(393,'expense','paid','none',NULL,NULL,NULL,'2025-06-06','celular','claro',NULL,4930,29,11,NULL,2,0,'2025-06-11 20:10:49','2025-06-11 20:10:49'),(394,'expense','paid','none',NULL,NULL,NULL,'2025-06-06','shoppe croc da Geovanna','shoppe',NULL,6000,47,11,NULL,2,0,'2025-06-11 20:43:26','2025-06-11 20:43:26'),(395,'expense','paid','none',NULL,NULL,NULL,'2025-06-06','combustivél','posto gasolina',NULL,15600,34,11,NULL,2,0,'2025-06-11 20:44:16','2025-06-11 20:44:16'),(396,'expense','paid','none',NULL,NULL,NULL,'2025-06-06','material eletrico','Eletro aquila',NULL,3997,35,11,NULL,2,0,'2025-06-11 20:45:13','2025-06-11 20:45:13'),(397,'expense','paid','none',NULL,NULL,NULL,'2025-06-06','produto','morena rosa',NULL,3997,47,11,NULL,2,0,'2025-06-11 20:46:10','2025-06-11 20:46:10'),(398,'expense','paid','none',NULL,NULL,NULL,'2025-06-06','Bateria noreak','I9 distribuidora',NULL,19980,49,11,NULL,2,0,'2025-06-11 20:47:18','2025-06-11 20:47:18'),(399,'expense','paid','none',NULL,NULL,NULL,'2025-06-11','emprestimo','emprestimo',NULL,7200,47,11,NULL,2,0,'2025-06-11 20:48:00','2025-06-11 20:48:00'),(400,'expense','paid','none',NULL,NULL,NULL,'2025-06-06','mercado','tenda',NULL,13500,38,11,NULL,2,0,'2025-06-11 20:48:41','2025-06-11 20:48:41'),(401,'expense','paid','none',NULL,NULL,NULL,'2025-06-07','emprestimo','emprestimo',NULL,13600,47,11,NULL,2,0,'2025-06-11 20:49:15','2025-06-11 20:49:15'),(402,'expense','paid','none',NULL,NULL,NULL,'2025-06-07','Miguel','Marcia',NULL,10000,47,11,NULL,2,0,'2025-06-11 20:49:49','2025-06-11 20:49:49'),(403,'expense','paid','none',NULL,NULL,NULL,'2025-06-08','bebida',NULL,NULL,4059,47,11,NULL,2,0,'2025-06-11 20:55:09','2025-06-11 20:56:25'),(404,'expense','paid','none',NULL,NULL,NULL,'2025-06-08','Mercadinho','Seven7',NULL,2529,38,11,NULL,2,0,'2025-06-11 20:57:09','2025-06-11 20:57:09'),(405,'expense','paid','none',NULL,NULL,NULL,'2025-06-08','mercado','Barbosa',NULL,13180,38,11,NULL,2,0,'2025-06-11 20:57:40','2025-06-11 20:57:40'),(406,'expense','paid','none',NULL,NULL,NULL,'2025-06-09','emprestimo','emprestimo',NULL,13600,47,11,NULL,2,0,'2025-06-11 20:58:08','2025-06-11 20:58:08'),(407,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','padaria','capri',NULL,1830,38,11,NULL,2,0,'2025-06-11 20:58:50','2025-06-11 20:58:50'),(408,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','internet','Vivo',NULL,12353,31,11,NULL,2,0,'2025-06-11 20:59:32','2025-06-11 20:59:32'),(409,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','farmacia','raia',NULL,649,42,11,NULL,2,0,'2025-06-11 21:02:59','2025-06-11 21:02:59'),(410,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','combustivél','posto gasolina',NULL,8000,34,11,NULL,2,0,'2025-06-11 21:03:29','2025-06-11 21:03:29'),(411,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','Pedagio','concessionaria',NULL,1230,47,11,NULL,2,0,'2025-06-11 21:04:38','2025-06-11 21:04:38'),(412,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','tranferencia nubank marcia','cora',NULL,2000,47,11,NULL,2,0,'2025-06-11 21:05:19','2025-06-11 21:05:19'),(413,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','shoppe meia','shoppe',NULL,4999,35,11,NULL,2,0,'2025-06-11 21:05:58','2025-06-11 21:05:58'),(414,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','lojas americanas','Alessandro',NULL,1247,37,11,NULL,2,0,'2025-06-11 21:06:42','2025-06-11 21:06:42'),(415,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','emprestimo','emprestimo',NULL,9600,47,11,NULL,2,0,'2025-06-11 21:07:26','2025-06-11 21:07:26'),(416,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','compra alessandro','raquel ferreira',NULL,1000,37,11,NULL,2,0,'2025-06-11 21:08:25','2025-06-11 21:08:25'),(417,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','Pedagio','concessionaria',NULL,1200,49,11,NULL,2,0,'2025-06-11 21:09:41','2025-06-11 21:09:41'),(418,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','salgado','reisdopf',NULL,1240,38,11,NULL,2,0,'2025-06-11 21:10:28','2025-06-11 21:10:28'),(419,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','Padaria','capri',NULL,2519,38,11,NULL,2,0,'2025-06-11 21:10:56','2025-06-11 21:10:56'),(420,'expense','paid','none',NULL,NULL,NULL,'2025-06-10','peça do carro','mercado livre',NULL,15301,2,11,NULL,2,0,'2025-06-11 21:12:14','2025-06-11 21:12:14'),(421,'expense','paid','none',NULL,NULL,NULL,'2025-06-11','Produto de beleza','adao',NULL,8000,35,11,NULL,2,0,'2025-06-11 21:20:10','2025-06-11 21:20:10'),(422,'expense','paid','none',NULL,NULL,NULL,'2025-06-11','Pedagio','concessionaria',NULL,1100,35,11,NULL,2,0,'2025-06-11 21:20:37','2025-06-11 21:20:37'),(423,'expense','paid','none',NULL,NULL,NULL,'2025-06-11','Produto de beleza Beatriz','Akai magazine',NULL,9778,35,11,NULL,2,0,'2025-06-11 21:21:29','2025-06-11 21:21:29'),(424,'expense','paid','none',NULL,NULL,NULL,'2025-06-11','pix nubank marcia','99',NULL,1200,2,11,NULL,2,0,'2025-06-11 21:22:10','2025-06-11 21:22:10'),(425,'expense','paid','none',NULL,NULL,NULL,'2025-06-11','Meias crianças','angel presentes',NULL,5900,35,11,NULL,2,0,'2025-06-11 21:23:11','2025-06-11 21:23:11'),(426,'expense','paid','none',NULL,NULL,NULL,'2025-06-11','emprestimo','emprestimo',NULL,9600,47,11,NULL,2,0,'2025-06-11 21:23:34','2025-06-11 21:23:34');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `push_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `due_date_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_notifications` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrador','alfreire@onlitec.com.br',NULL,'2025-04-20 13:43:33','$2y$12$xQVTQih7Xc.ktckY7heCmuDntap4byDU94qK1KW6FEHCT7vMv2SFy',NULL,1,1,NULL,'2025-04-20 13:42:30','2025-05-13 19:53:14',1,0,1,0),(2,'Administrador Galvatec','galvatec@onlifin.com.br',NULL,'2025-04-20 13:43:33','$2y$12$imQVLcvWRHcT8L25YEtQOOle/NHYwJAQysABbAjKPrD2rAjJASzYS',NULL,1,1,NULL,'2025-04-20 13:42:31','2025-04-20 13:43:33',1,0,1,0),(3,'Marcia','marciafreire@onlitec.com.br',NULL,NULL,'$2y$12$zNEQwb3lTlk4.JGwh6usxOK8ndtf6A.i.JHBhKwiZmxSB0BcKRLN.',NULL,1,1,NULL,'2025-04-20 13:44:13','2025-04-20 13:45:08',1,0,1,0),(4,'Alessandro','alessandro@onlitec.com.br',NULL,'2025-05-05 13:45:03','$2y$12$x3I0ozsB6DVaDGczzlpkHOXhUOaEppkG6/uka7nMP2imUiXd.GajO',NULL,1,1,NULL,'2025-05-05 13:45:03','2025-05-05 13:45:03',1,0,1,0),(5,'Beatriz','beatrizbiafreire@gmail.com',NULL,NULL,'$2y$12$JxauvsH6k7YZwPUfvmWiSOZbaISXevJv1dZMtN.NrEY9ef97CyEMy',NULL,1,1,NULL,'2025-05-21 14:39:28','2025-06-25 01:51:40',1,0,1,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-27  0:12:09
