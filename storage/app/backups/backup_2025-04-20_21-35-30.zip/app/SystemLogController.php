<?php

namespace App\Http\Controllers;

use App\Models\SystemLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;

class SystemLogController extends Controller
{

    public function index(Request $request)
    {
        // Revertendo temporariamente para o comportamento antigo
        return $this->apiLogs($request);
        /*
        $activeTab = $request->query('tab', 'api'); // Default para 'api' se nenhuma aba for passada

        switch ($activeTab) {
            case 'system':
                return $this->systemLogs($request);
            case 'laravel':
                return $this->laravelLogs($request);
            case 'api':
            default:
                return $this->apiLogs($request);
        }
        */
    }
    
    /**
     * Exibe os logs do sistema
     */
    protected function systemLogs(Request $request)
    {
        $query = SystemLog::with('user')->latest();

        // Filtros
        if ($request->filled('module')) {
            $query->where('module', $request->module);
        }
        if ($request->filled('action')) {
            $query->where('action', $request->action);
        }
        if ($request->filled('user')) {
            $query->whereHas('user', function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->user}%")
                  ->orWhere('email', 'like', "%{$request->user}%");
            });
        }
        if ($request->filled('date_start')) {
            $query->whereDate('created_at', '>=', $request->date_start);
        }
        if ($request->filled('date_end')) {
            $query->whereDate('created_at', '<=', $request->date_end);
        }

        $logs = $query->paginate(50);
        
        // Obter lista de módulos e ações para os filtros
        $modules = SystemLog::distinct()->pluck('module');
        $actions = SystemLog::distinct()->pluck('action');

        return view('settings.logs.index', [
            'activeTab' => 'system',
            'logs' => $logs,
            'modules' => $modules,
            'actions' => $actions,
            'route' => route('settings.logs.index'),
            'exportRoute' => route('settings.logs.export')
        ]);
    }
    
    /**
     * Exibe os logs de monitoramento da API
     */
    protected function apiLogs(Request $request)
    {
        Log::info('[apiLogs] Entrando no método.');
        // Diretório de logs de API
        $logDir = storage_path('logs/api_monitor');
        Log::info('[apiLogs] Diretório de log definido:', ['dir' => $logDir]);
        
        // Verifica se o diretório existe
        Log::info('[apiLogs] Verificando se diretório existe...');
        if (!File::exists($logDir)) {
            Log::warning('[apiLogs] Diretório não existe. Tentando criar...');
            try {
                File::makeDirectory($logDir, 0755, true); // Cria se não existir
                Log::info('[apiLogs] Diretório criado com sucesso.');
            } catch (\Exception $e) {
                Log::error('[apiLogs] Falha ao criar diretório!', ['error' => $e->getMessage()]);
                // Talvez retornar um erro aqui ou uma view indicando o problema?
                // Por enquanto, apenas loga e continua, pode causar erro depois.
            }
        } else {
            Log::info('[apiLogs] Diretório já existe.');
        }
        
        // Lista todos os arquivos de log
        $logFiles = [];
        try {
            Log::info('[apiLogs] Tentando listar arquivos em:', ['dir' => $logDir]);
            $logFiles = File::files($logDir); // Pega todos os arquivos
            Log::info('[apiLogs] Arquivos listados com sucesso.', ['count' => count($logFiles)]);
        } catch (\Exception $e) {
            Log::error('[apiLogs] Falha ao listar arquivos!', ['error' => $e->getMessage()]);
             // Retornar uma view de erro aqui seria mais robusto
             return view('settings.logs.api', [
                'activeTab' => 'api',
                'logFiles' => [], // Lista vazia
                'provider' => $request->get('provider', ''),
                'error' => 'Falha ao listar arquivos no diretório de log: ' . $e->getMessage() // Passa erro para a view
            ]);
        }
        
        $logFilesData = [];
        try {
             Log::info('[apiLogs] Mapeando dados dos arquivos...');
            $logFilesData = array_map(function($file) {
                // Adicionar log dentro do map pode ser excessivo, logar antes/depois
                return [
                    'name' => $file->getFilename(),
                    'size' => $file->getSize(),
                    'modified' => date('Y-m-d H:i:s', $file->getMTime()),
                    'path' => $file->getPathname(),
                    'type' => 'api'
                ];
            }, $logFiles);
             Log::info('[apiLogs] Mapeamento concluído.', ['count' => count($logFilesData)]);
        } catch (\Exception $e) {
             Log::error('[apiLogs] Falha ao mapear dados dos arquivos!', ['error' => $e->getMessage()]);
             // Retornar view de erro
              return view('settings.logs.api', [
                 'activeTab' => 'api',
                 'logFiles' => [],
                 'provider' => $request->get('provider', ''),
                 'error' => 'Falha ao processar dados dos arquivos de log: ' . $e->getMessage()
             ]);
        }

        // Organiza por data de modificação (mais recentes primeiro)
        Log::info('[apiLogs] Ordenando arquivos...');
        usort($logFilesData, function($a, $b) {
            return strtotime($b['modified']) - strtotime($a['modified']);
        });
        Log::info('[apiLogs] Ordenação concluída.');
        
        Log::info('[apiLogs] Retornando a view settings.logs.api');
        return view('settings.logs.api', [
            'activeTab' => 'api',
            'logFiles' => $logFilesData,
            'provider' => $request->get('provider', '')
        ]);
    }
    
    /**
     * Exibe os logs do Laravel
     */
    public function laravelLogs(Request $request)
    {
        // Lista logs do Laravel e de importação
        $logFiles = File::glob(storage_path('logs/*.log')); // Usar glob para pegar todos os .log
        $logFilesData = [];
        foreach ($logFiles as $filePath) {
            $file = new \SplFileInfo($filePath);
            $logFilesData[] = [
                'name' => $file->getFilename(),
                'size' => $file->getSize(),
                'modified' => date('Y-m-d H:i:s', $file->getMTime()),
                'path' => $file->getPathname(),
                'type' => 'laravel' // Manter o tipo para a rota de view
            ];
        }
        
        usort($logFilesData, function($a, $b) {
            return strtotime($b['modified']) - strtotime($a['modified']);
        });
        
        return view('settings.logs.laravel', [
            'activeTab' => 'laravel',
            'logFiles' => $logFilesData
        ]);
    }

    /**
     * Mostrar o conteúdo de um arquivo de log
     */
    public function view(Request $request, $type, $filename)
    {
        $filePath = '';
        $content = '';
        $entries = [];
        
        if ($type === 'api') {
            $filePath = storage_path('logs/api_monitor/' . $filename);
            
            if (File::exists($filePath)) {
                $content = File::get($filePath);
                
                // Processar entradas de log de API
                $rawEntries = explode("---END-CALL---\n", $content);
                foreach ($rawEntries as $entry) {
                    $entry = trim($entry);
                    if (empty($entry)) continue;
                    
                    try {
                        $data = json_decode($entry, true);
                        if ($data) {
                            $entries[] = $data;
                        }
                    } catch (\Exception $e) {
                        // Ignora entradas com formato inválido
                    }
                }
            }
        } elseif ($type === 'laravel') {
            $filePath = storage_path('logs/' . $filename);
            if (File::exists($filePath)) {
                $content = File::get($filePath);
            }
        }
        
        if (empty($filePath) || !File::exists($filePath)) {
            return redirect()->route('settings.logs.index', ['tab' => $type])
                ->with('error', 'Arquivo de log não encontrado');
        }
        
        return view('settings.logs.view', [
            'type' => $type,
            'filename' => $filename,
            'content' => $content,
            'entries' => $entries
        ]);
    }
    
    public function show(SystemLog $log)
    {
        return view('settings.logs.show', compact('log'));
    }


    public function export(Request $request)
    {
        $query = SystemLog::with('user')->latest();

        // Aplicar os mesmos filtros do index
        if ($request->filled('module')) {
            $query->where('module', $request->module);
        }
        if ($request->filled('action')) {
            $query->where('action', $request->action);
        }
        if ($request->filled('user')) {
            $query->whereHas('user', function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->user}%")
                  ->orWhere('email', 'like', "%{$request->user}%");
            });
        }
        if ($request->filled('date_start')) {
            $query->whereDate('created_at', '>=', $request->date_start);
        }
        if ($request->filled('date_end')) {
            $query->whereDate('created_at', '<=', $request->date_end);
        }

        $logs = $query->get();

        // Criar arquivo CSV
        $filename = 'system_logs_' . now()->format('Y-m-d_His') . '.csv';
        $handle = fopen('php://temp', 'r+');
        
        // Cabeçalho
        fputcsv($handle, ['Data', 'Usuário', 'Módulo', 'Ação', 'Descrição', 'IP', 'Navegador']);

        // Dados
        foreach ($logs as $log) {
            fputcsv($handle, [
                $log->created_at->format('d/m/Y H:i:s'),
                $log->user ? $log->user->name : 'Sistema',
                $log->module,
                $log->action,
                $log->description,
                $log->ip_address,
                $log->user_agent
            ]);
        }

        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);

        return response($csv)
            ->header('Content-Type', 'text/csv')
            ->header('Content-Disposition', "attachment; filename=\"$filename\"");
    }
} 