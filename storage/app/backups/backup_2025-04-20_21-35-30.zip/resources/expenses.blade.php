<x-app-layout>
    @livewire('transactions.expenses')
</x-app-layout> 