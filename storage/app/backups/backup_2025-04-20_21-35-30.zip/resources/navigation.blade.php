<nav x-data="{ open: false }" class="bg-white shadow-sm">
    <!-- Primary Navigation Menu -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex">
                <!-- Logo -->
                <div class="shrink-0 flex items-center">
                    <a href="{{ route('dashboard') }}">
                        {{-- Se tiver um componente de logo: --}}
                        {{-- <x-application-logo class="block h-9 w-auto fill-current text-gray-800" /> --}}
                        {{-- Ou apenas o texto: --}}
                         <h1 class="text-2xl font-bold text-gray-800">Onlifin</h1>
                    </a>
                </div>

                <!-- Navigation Links -->
                <div class="hidden space-x-8 sm:-my-px sm:ml-10 sm:flex main-menu">
                     {{-- Os links do menu principal que estavam no app.blade.php --}}
                     <a href="{{ route('dashboard') }}" class="menu-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                         <i class="ri-dashboard-line mr-2"></i> Dashboard
                     </a>
                     <a href="{{ route('transactions.index') }}" class="menu-item {{ request()->routeIs('transactions.index') ? 'active' : '' }}">
                         <i class="ri-exchange-line mr-2"></i> Transações
                     </a>
                     <a href="{{ route('transactions.income') }}" class="menu-item {{ request()->routeIs('transactions.income') ? 'active' : '' }}">
                         <i class="ri-arrow-up-circle-line mr-2"></i> Receitas
                     </a>
                     <a href="{{ route('transactions.expenses') }}" class="menu-item {{ request()->routeIs('transactions.expenses') ? 'active' : '' }}">
                         <i class="ri-arrow-down-circle-line mr-2"></i> Despesas
                     </a>
                     <a href="{{ route('categories.index') }}" class="menu-item {{ request()->routeIs('categories.*') ? 'active' : '' }}">
                         <i class="ri-price-tag-3-line mr-2"></i> Categorias
                     </a>
                     <a href="{{ route('accounts.index') }}" class="menu-item {{ request()->routeIs('accounts.*') ? 'active' : '' }}">
                         <i class="ri-bank-line mr-2"></i> Contas
                     </a>
                     <a href="{{ route('settings.index') }}" class="menu-item {{ request()->routeIs('settings.*') ? 'active' : '' }}">
                         <i class="ri-settings-3-line mr-2"></i> Configurações
                     </a>
                </div>
            </div>

            <!-- Settings Dropdown -->
            <div class="hidden sm:flex sm:items-center sm:ml-6">

                 <!-- AI Status -->
                 <div class="hidden sm:flex items-center mr-4">
                     <x-ai-status />
                 </div>

                <div class="relative" x-data="{ open: false }" @click.away="open = false">
                     <button @click="open = !open" class="flex items-center text-sm font-medium text-gray-700 hover:text-gray-900 focus:outline-none transition duration-150 ease-in-out">
                         <span>{{ auth()->user()->name }}</span>
                         <i class="ri-arrow-down-s-line ml-1"></i>
                     </button>

                     <div x-show="open" x-cloak
                             class="absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5"
                             style="display: none;"
                             @click="open = false">
                        <a href="{{ route('profile.edit') }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                             Perfil
                         </a>

                        <!-- Authentication -->
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                             <button type="submit" class="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                 Sair
                             </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Hamburger -->
            <div class="-mr-2 flex items-center sm:hidden">
                <button @click="open = ! open" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 focus:text-gray-500 transition duration-150 ease-in-out">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path :class="{'hidden': open, 'inline-flex': ! open }" class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        <path :class="{'hidden': ! open, 'inline-flex': open }" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Responsive Navigation Menu -->
    <div :class="{'block': open, 'hidden': ! open}" class="hidden sm:hidden border-t border-gray-200">
         <!-- AI Status (Mobile) -->
         <div class="py-2 px-4 border-b border-gray-100">
             <x-ai-status />
         </div>
        <div class="pt-2 pb-3 space-y-1">
             {{-- Links responsivos --}}
              <a href="{{ route('dashboard') }}" class="mobile-nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                  <i class="ri-dashboard-line mr-2"></i> Dashboard
              </a>
              <a href="{{ route('transactions.index') }}" class="mobile-nav-link {{ request()->routeIs('transactions.index') ? 'active' : '' }}">
                  <i class="ri-exchange-line mr-2"></i> Transações
              </a>
              <a href="{{ route('transactions.income') }}" class="mobile-nav-link {{ request()->routeIs('transactions.income') ? 'active' : '' }}">
                  <i class="ri-arrow-up-circle-line mr-2"></i> Receitas
              </a>
              <a href="{{ route('transactions.expenses') }}" class="mobile-nav-link {{ request()->routeIs('transactions.expenses') ? 'active' : '' }}">
                  <i class="ri-arrow-down-circle-line mr-2"></i> Despesas
              </a>
              <a href="{{ route('categories.index') }}" class="mobile-nav-link {{ request()->routeIs('categories.*') ? 'active' : '' }}">
                  <i class="ri-price-tag-3-line mr-2"></i> Categorias
              </a>
              <a href="{{ route('accounts.index') }}" class="mobile-nav-link {{ request()->routeIs('accounts.*') ? 'active' : '' }}">
                  <i class="ri-bank-line mr-2"></i> Contas
              </a>
              <a href="{{ route('settings.index') }}" class="mobile-nav-link {{ request()->routeIs('settings.*') ? 'active' : '' }}">
                  <i class="ri-settings-3-line mr-2"></i> Configurações
              </a>
        </div>

        <!-- Responsive Settings Options -->
        <div class="pt-4 pb-1 border-t border-gray-200">
            <div class="px-4">
                <div class="font-medium text-base text-gray-800">{{ Auth::user()->name }}</div>
                <div class="font-medium text-sm text-gray-500">{{ Auth::user()->email }}</div>
            </div>

            <div class="mt-3 space-y-1">
                <a href="{{ route('profile.edit') }}" class="mobile-nav-link {{ request()->routeIs('profile.edit') ? 'active' : '' }}">
                     <i class="ri-user-line mr-2"></i> Perfil
                 </a>

                <!-- Authentication -->
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                     <button type="submit" class="mobile-nav-link w-full text-left">
                         <i class="ri-logout-box-line mr-2"></i> Sair
                     </button>
                </form>
            </div>
        </div>
    </div>
</nav> 