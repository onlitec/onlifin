<x-app-layout>
    <div class="container-app">
        <div class="mb-6 flex items-center justify-between">
            <h1 class="text-2xl font-bold text-gray-900">Revisão e Confirmação</h1>
            <a href="{{ route('statements.import') }}" class="btn btn-secondary">
                <i class="ri-arrow-left-line mr-2"></i>
                Voltar para Importação
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="mb-6">
                    <div class="flex items-center mb-2">
                        <i class="ri-information-line text-blue-500 text-xl mr-2"></i>
                        <h2 class="text-lg font-medium text-gray-700">Instruções</h2>
                    </div>
                    <p class="text-gray-600 mb-2">
                       Revise as transações extraídas e categorizadas abaixo. Se tudo estiver correto, clique em "Cadastrar Todas as Transações".
                    </p>
                    <div class="bg-blue-50 border-l-4 border-blue-500 text-blue-700 p-4 mb-4">
                        <p>
                            <strong>Conta selecionada:</strong> {{ $account->name }}
                        </p>
                        @if(isset($extractedTransactions) && is_array($extractedTransactions) && count($extractedTransactions) > 0)
                            <p class="mt-2">
                                <strong>{{ count($extractedTransactions) }} transações</strong> prontas para serem cadastradas.
                            </p>
                        @endif
                    </div>
                    
                    @if(isset($useAI) && $useAI)
                        <div class="bg-purple-50 border-l-4 border-purple-500 text-purple-700 p-4 mb-4">
                            <div class="flex items-center">
                                <i class="ri-brain-line text-purple-600 text-xl mr-2"></i>
                                <h3 class="font-medium">Análise por Inteligência Artificial</h3>
                            </div>
                            @if(isset($aiAnalysisResult) && $aiAnalysisResult)
                                <p class="mt-2">
                                    A IA analisou e sugeriu categorias para as transações.
                                </p>
                                <!-- Remover botão de auto-save antigo -->
                            @else
                                <p class="mt-2">
                                    Não foi possível obter sugestões da IA. As transações podem estar sem categoria ou com uma categoria padrão.
                                </p>
                                <p class="text-sm mt-2">
                                    Você pode verificar as configurações de IA em <a href="{{ route('settings.model-keys.index') }}" class="underline hover:text-purple-800">Configurações > IA</a>.
                                </p>
                            @endif
                        </div>
                    @endif
                </div>

                <!-- Remover form antigo -->
                
                 <!-- Inputs hidden para guardar dados essenciais para o botão de salvar -->
                 <input type="hidden" id="account_id" value="{{ $account->id }}">
                 <input type="hidden" id="file_path" value="{{ $path }}">
                    
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="border-b border-gray-200 text-left text-sm">
                                <th class="px-3 py-3 bg-gray-50 text-gray-600 font-medium">Data</th>
                                <th class="px-3 py-3 bg-gray-50 text-gray-600 font-medium">Descrição</th>
                                <th class="px-3 py-3 bg-gray-50 text-gray-600 font-medium">Valor</th>
                                <th class="px-3 py-3 bg-gray-50 text-gray-600 font-medium">Tipo</th>
                                <th class="px-3 py-3 bg-gray-50 text-gray-600 font-medium">Categoria</th>
                                <!-- Remover coluna Ações -->
                            </tr>
                        </thead>
                        <tbody id="transactions-container">
                            <!-- As transações serão carregadas aqui pelo JavaScript como texto -->
                        </tbody>
                    </table>
                </div>
                
                <!-- Remover botão Add-row -->
                
                <div class="flex justify-end mt-6">
                    <button type="button" id="confirm-save-all" class="btn btn-primary">
                         <span class="button-text">
                            <i class="ri-save-line mr-2"></i>
                            Cadastrar Todas as Transações
                         </span>
                         <span class="loading-spinner hidden animate-spin mr-2">
                            <i class="ri-loader-4-line"></i>
                         </span>
                         <span class="loading-text hidden">Cadastrando...</span>
                    </button>
                </div>
                
                 <!-- Mensagem de erro geral AJAX -->
                 <div id="ajax-error-message" class="mt-4 hidden bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                    <strong class="font-bold">Erro!</strong>
                    <span class="block sm:inline">Ocorreu um erro ao processar a solicitação.</span>
                 </div>
                 
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const container = document.getElementById('transactions-container');
            const confirmSaveButton = document.getElementById('confirm-save-all');
            const accountIdInput = document.getElementById('account_id');
            const filePathInput = document.getElementById('file_path');
            const ajaxErrorMessage = document.getElementById('ajax-error-message');
            
            // Dados passados pelo PHP
            const transactions = @json($extractedTransactions ?? []);
            const categories = @json($categories ?? []); // Estrutura: { income: [...], expense: [...] }
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            // --- Funções Auxiliares ---
            function showLoading(button) {
                button.disabled = true;
                button.querySelector('.button-text').classList.add('hidden');
                button.querySelector('.loading-spinner').classList.remove('hidden');
                button.querySelector('.loading-text').classList.remove('hidden');
            }

            function hideLoading(button) {
                button.disabled = false;
                button.querySelector('.button-text').classList.remove('hidden');
                button.querySelector('.loading-spinner').classList.add('hidden');
                button.querySelector('.loading-text').classList.add('hidden');
            }
            
            function showAjaxError(message = 'Ocorreu um erro ao processar a solicitação.') {
                 ajaxErrorMessage.querySelector('span').textContent = message;
                 ajaxErrorMessage.classList.remove('hidden');
            }
            
            function hideAjaxError() {
                 ajaxErrorMessage.classList.add('hidden');
            }
            
            function getCategoryName(categoryId, suggestedName, type) {
                if (categoryId) {
                    const categoryList = (type === 'income' ? categories.income : categories.expense) || [];
                    const category = categoryList.find(c => c.id == categoryId); // Comparação frouxa por precaução
                    return category ? category.name : `ID Categoria: ${categoryId}`; // Retorna nome ou ID se não encontrar
                } else if (suggestedName) {
                    return `${suggestedName} (Nova)`;
                }
                return 'Sem Categoria';
            }

            // --- Renderizar Tabela Estática ---
            function renderTransactions() {
                container.innerHTML = ''; // Limpar container
                if (!transactions || transactions.length === 0) {
                     container.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-gray-500">Nenhuma transação para exibir.</td></tr>';
                     confirmSaveButton.disabled = true; // Desabilitar botão se não houver transações
                     return;
                 }
                
                transactions.forEach((transaction, index) => {
                    const row = document.createElement('tr');
                    row.className = 'border-b border-gray-200';
                    
                    const formattedAmount = parseFloat(transaction.amount || 0).toLocaleString('pt-BR', {
                        style: 'currency',
                        currency: 'BRL'
                    });
                    
                    const typeText = transaction.type === 'income' ? 'Receita' : 'Despesa';
                    const typeColor = transaction.type === 'income' ? 'text-green-600' : 'text-red-600';
                    
                    // Usar category_id e suggested_category conforme aplicados pelo controller
                    const categoryName = getCategoryName(transaction.category_id, transaction.suggested_category, transaction.type);

                    row.innerHTML = `
                        <td class="px-3 py-3 text-sm">${transaction.date || 'N/A'}</td>
                        <td class="px-3 py-3 text-sm">${transaction.description || 'N/A'}</td>
                        <td class="px-3 py-3 text-sm text-right">${formattedAmount}</td>
                        <td class="px-3 py-3 text-sm"><span class="${typeColor} font-medium">${typeText}</span></td>
                        <td class="px-3 py-3 text-sm">${categoryName}</td>
                    `;
                    container.appendChild(row);
                });
            }

            // --- Event Listener para o Botão de Salvar ---
            confirmSaveButton.addEventListener('click', function() {
                showLoading(this);
                hideAjaxError();

                const accountId = accountIdInput.value;
                const filePath = filePathInput.value;

                // Preparar os dados das transações para envio
                // O controller saveTransactions espera amount como string ou numérico, 
                // e category_id como ID numérico ou string 'new_...' se for nova.
                // A função applyCategorization no controller já deve ter preparado os dados.
                // Verificar se precisamos ajustar algo aqui baseado na validação do saveTransactions
                const transactionsToSave = transactions.map(t => ({
                    date: t.date,
                    description: t.description,
                    amount: t.amount, // Enviar o valor numérico
                    type: t.type,
                    category_id: t.category_id, // Enviar ID ou null
                    suggested_category: t.suggested_category // Enviar nome sugerido se category_id for null
                    // O controller saveTransactions decidirá se cria a categoria
                }));

                const payload = {
                    account_id: accountId,
                    file_path: filePath,
                    transactions: transactionsToSave,
                    _token: csrfToken
                };

                fetch('{{ route("statements.save") }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify(payload)
                })
                .then(response => {
                    if (!response.ok) {
                        return response.json().then(errData => {
                             throw { status: response.status, data: errData };
                        }).catch(() => {
                            throw new Error(`Erro HTTP: ${response.status}`); 
                        });
                    }
                    return response.json(); // Espera uma resposta JSON do controller (mesmo que seja só redirect info)
                })
                .then(data => {
                    // Assumindo que o controller retorna sucesso ou redireciona em caso de sucesso.
                    // Se o saveTransactions retornar JSON com uma URL de redirecionamento:
                    if (data.redirect_url) {
                         window.location.href = data.redirect_url; // Idealmente, o controller redireciona via HTTP 302
                    } else {
                         // Se não houver URL de redirect, assumir sucesso e redirecionar para o índice
                         window.location.href = '{{ route("transactions.index") }}'; 
                         // Nota: Mensagens flash (withSuccess) não funcionarão com redirect JS.
                         // Seria melhor o controller retornar um redirect HTTP real.
                    }
                })
                .catch(error => {
                    console.error('Erro ao salvar transações:', error);
                    let errorMessage = 'Ocorreu um erro ao salvar as transações.';
                    if (error.data && error.data.message) {
                        errorMessage = error.data.message;
                        // Se houver erros de validação específicos por campo (improvável aqui, mais no form original)
                        // if(error.data.errors) { ... } 
                    } else if (error.message) {
                         errorMessage = error.message;
                    }
                    showAjaxError(errorMessage);
                    hideLoading(confirmSaveButton);
                });
            });

            // --- Inicialização ---
            renderTransactions();

        });
    </script>
</x-app-layout> 