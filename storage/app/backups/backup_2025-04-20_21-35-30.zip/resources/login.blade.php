<div class="form-group">
    <button type="submit" class="btn btn-primary w-100">Entrar</button>
</div>

<div class="mt-3">
    <a href="{{ route('register') }}">Criar nova conta</a> 