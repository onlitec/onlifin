<x-app-layout>
    @livewire('transactions.income')
</x-app-layout> 