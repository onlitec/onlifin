<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    @auth
    <!-- User ID for notifications -->
    <meta name="user-id" content="{{ auth()->id() }}">
    @endauth

    <title>{{ config('app.name', 'Onlifin') }}</title>

    <!-- Fonts -->
    <style>
        @font-face {
            font-family: 'Inter';
            font-style: normal;
            font-weight: 400;
            src: url('{{ asset('assets/fonts/inter/inter-regular.ttf') }}') format('truetype');
        }
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
    
    <!-- Icons (Local) -->
    <link href="{{ asset('assets/css/remixicon.css') }}" rel="stylesheet">
    
    <!-- IMask para campos de formulário -->

    
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @livewireStyles
    
    <!-- Alpine.js -->

    
    <!-- LivewireUI Modal -->
    @livewireScripts
    @livewire('components.modal')
    
    <style>
        /* Estilos básicos */
        body {
            font-family: 'Inter', sans-serif;
        }
        
        /* Menu principal */
        .main-menu {
            display: flex;
            flex-direction: row;
            justify-content: center;
            width: 100%;
        }
        
        .menu-container {
            display: flex;
            flex-direction: row;
            align-items: center;
            gap: 24px;
        }
        
        .menu-item {
            display: inline-flex;
            align-items: center;
            padding: 8px 12px;
            font-size: 18px;
            font-weight: 500;
            color: #4B5563;
            white-space: nowrap;
            transition: color 0.2s;
        }
        
        .menu-item:hover {
            color: #2563EB;
        }
        
        .menu-item.active {
            color: #2563EB;
            font-weight: 600;
        }
        
        /* Menu mobile */
        .mobile-nav-link {
            display: block;
            width: 100%;
            padding: 12px 16px;
            font-size: 16px;
            font-weight: 500;
            color: #4B5563;
            transition: all 0.2s;
            border-radius: 6px;
        }
        
        .mobile-nav-link:hover {
            color: #1F2937;
            background-color: #F3F4F6;
        }
        
        .mobile-nav-link.active {
            color: #2563EB;
            background-color: #EFF6FF;
            font-weight: 600;
        }
        
        /* Botões */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-weight: 500;
            transition-property: color, background-color, border-color;
            transition-duration: 150ms;
        }
        
        .btn-primary {
            background-color: #2563EB;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #1D4ED8;
        }
        
        .btn-secondary {
            background-color: #E5E7EB;
            color: #374151;
        }
        
        .btn-secondary:hover {
            background-color: #D1D5DB;
        }
        
        /* Cards */
        .card {
            border-radius: 0.75rem;
            border: 1px solid #E5E7EB;
            background-color: white;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        }
        
        .card-header {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #E5E7EB;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        /* Tabelas */
        .table {
            min-width: 100%;
        }
        
        .table-header {
            background-color: #F9FAFB;
        }
        
        .table-header-cell {
            padding: 0.75rem 1.5rem;
            text-align: left;
            font-size: 0.75rem;
            line-height: 1rem;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #6B7280;
        }
        
        .table-body {
            background-color: white;
        }
        
        .table-row:hover {
            background-color: #F9FAFB;
        }
        
        .table-cell {
            padding: 1rem 1.5rem;
            font-size: 0.875rem;
            line-height: 1.25rem;
            color: #6B7280;
        }
        
        /* Responsividade */
        @media (max-width: 767px) {
            .main-menu {
                display: none;
            }
        }
    </style>
</head>
<body class="font-sans antialiased bg-gray-50">
    <div class="min-h-screen flex flex-col">
        <!-- Top Navigation -->
        @include('layouts.navigation')

        <!-- Page Content -->
        <main class="flex-grow px-4 sm:px-6 lg:px-8 py-8">
            {{ $slot }}
        </main>
    </div>

    <script src="{{ asset('assets/js/sweetalert2.all.min.js') }}"></script>
    <script>
        window.addEventListener('alert', event => {
            Swal.fire({
                title: event.detail.title,
                text: event.detail.text,
                icon: event.detail.icon,
                confirmButtonText: 'OK'
            });
        });
        
        function toggleMobileMenu() {
            var menu = document.getElementById('mobileMenu');
            if (menu.classList.contains('hidden')) {
                menu.classList.remove('hidden');
            } else {
                menu.classList.add('hidden');
            }
        }
    </script>
    @stack('scripts')
</body>
</html> 