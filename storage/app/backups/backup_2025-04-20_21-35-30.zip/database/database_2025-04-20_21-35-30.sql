/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.21-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: onlifinbd
-- ------------------------------------------------------
-- Server version	10.6.21-MariaDB-0ubuntu0.22.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'checking',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `initial_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  `current_balance` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `accounts_user_id_foreign` (`user_id`),
  CONSTRAINT `accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (8,'CORA','checking',1,NULL,'#6366f1',3,'2025-04-20 16:40:29','2025-04-20 16:40:29',0.00,0.00),(9,'NUBANK-PF-ALESANDRO','checking',1,NULL,'#6366f1',3,'2025-04-20 16:40:42','2025-04-20 16:40:42',0.00,0.00),(10,'TESTE','checking',1,NULL,'#6366f1',3,'2025-04-20 16:44:11','2025-04-20 16:44:11',0.00,0.00);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_user_id_foreign` (`user_id`),
  CONSTRAINT `categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Alimentação','expense',NULL,NULL,NULL,1,'2025-04-20 13:42:31','2025-04-20 13:42:31'),(2,'Transporte','expense',NULL,NULL,NULL,1,'2025-04-20 13:42:31','2025-04-20 13:42:31'),(5,'Freelance','income',NULL,NULL,NULL,1,'2025-04-20 13:42:31','2025-04-20 13:42:31'),(18,'Moradia','expense',NULL,NULL,NULL,2,'2025-04-20 13:43:34','2025-04-20 13:43:34'),(19,'Salário','income',NULL,NULL,NULL,2,'2025-04-20 13:43:34','2025-04-20 13:43:34'),(21,'Recebido','income',NULL,'#3b82f6',NULL,3,'2025-04-20 19:44:08','2025-04-20 19:44:08'),(22,'Débito','expense',NULL,'#3b82f6',NULL,3,'2025-04-20 19:45:49','2025-04-20 19:45:49');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `due_date_notification_settings`
--

DROP TABLE IF EXISTS `due_date_notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `due_date_notification_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `notify_expenses` tinyint(1) NOT NULL DEFAULT 1,
  `notify_incomes` tinyint(1) NOT NULL DEFAULT 1,
  `notify_on_due_date` tinyint(1) NOT NULL DEFAULT 1,
  `notify_days_before` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '[1,3,7]' CHECK (json_valid(`notify_days_before`)),
  `notify_channels` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '["email","database"]' CHECK (json_valid(`notify_channels`)),
  `expense_template_id` bigint(20) unsigned DEFAULT NULL,
  `income_template_id` bigint(20) unsigned DEFAULT NULL,
  `group_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `due_date_notification_settings_user_id_foreign` (`user_id`),
  KEY `due_date_notification_settings_expense_template_id_foreign` (`expense_template_id`),
  KEY `due_date_notification_settings_income_template_id_foreign` (`income_template_id`),
  CONSTRAINT `due_date_notification_settings_expense_template_id_foreign` FOREIGN KEY (`expense_template_id`) REFERENCES `notification_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `due_date_notification_settings_income_template_id_foreign` FOREIGN KEY (`income_template_id`) REFERENCES `notification_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `due_date_notification_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `due_date_notification_settings`
--

LOCK TABLES `due_date_notification_settings` WRITE;
/*!40000 ALTER TABLE `due_date_notification_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `due_date_notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2024_02_23_000000_create_sessions_table',1),(2,'0001_01_01_000001_create_cache_table',2),(3,'0001_01_01_000002_create_jobs_table',2),(4,'2014_10_12_000000_create_users_table',2),(5,'2024_02_23_000001_create_accounts_table',2),(6,'2024_02_23_000002_create_categories_table',2),(7,'2024_02_23_000003_create_transactions_table',2),(8,'2024_02_23_000004_create_roles_table',2),(9,'2024_02_23_000005_create_permissions_table',2),(10,'2024_02_23_000006_create_role_user_table',2),(11,'2024_02_23_000007_create_permission_role_table',2),(12,'2024_02_23_add_status_to_transactions',2),(13,'2025_03_11_230234_add_description_and_color_to_accounts_table',2),(14,'2025_03_11_233944_create_settings_table',2),(15,'2025_03_12_163420_add_description_to_categories_table',2),(16,'2025_03_12_164528_add_is_admin_to_users_table',2),(17,'2025_03_12_174726_create_replicate_settings_table',2),(18,'2025_03_30_203228_add_notification_settings_to_settings_table',2),(19,'2025_03_30_211641_add_is_active_to_users_table',2),(20,'2025_03_30_224441_sync_user_status_fields',2),(21,'2025_03_31_013443_create_password_reset_tokens_table',2),(22,'2025_03_31_015322_create_notifications_table',2),(23,'2025_03_31_020643_create_notification_templates_table',2),(24,'2025_03_31_092521_add_new_columns_to_notification_settings',2),(25,'2025_03_31_095642_add_notification_settings_to_users_table',2),(26,'[timestamp]_add_phone_to_users_table',2),(27,'2025_03_31_162902_add_whatsapp_notifications_to_users_table',3),(28,'2024_02_24_000001_update_accounts_table_structure',4),(29,'2024_04_02_000000_create_system_logs_table',4),(30,'2025_02_24_001122_add_user_id_to_categories_table',4),(31,'2025_02_24_001336_add_user_id_to_categories_table',4),(32,'2025_02_24_001358_add_description_to_categories_table',4),(33,'2025_02_24_110748_add_user_id_to_accounts_table',4),(34,'2025_02_24_114128_update_users_table_add_missing_fields',4),(35,'2025_03_13_011459_add_recurrence_fields_to_transactions_table',4),(36,'2025_04_01_090924_add_provider_to_replicate_settings_table',4),(37,'2025_04_18_023349_add_amount_to_transactions_if_not_exists',4),(38,'2025_04_18_185604_create_model_api_keys_table',4),(39,'xxxx_xx_xx_add_description_to_categories_table',4),(40,'xxxx_xx_xx_add_user_id_to_accounts_table',4),(41,'xxxx_xx_xx_add_user_id_to_categories_table',4),(42,'xxxx_xx_xx_create_role_user_table',4),(43,'xxxx_xx_xx_update_users_table_add_missing_fields',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_api_keys`
--

DROP TABLE IF EXISTS `model_api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_api_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(50) NOT NULL COMMENT 'Provedor de IA (openai, anthropic, gemini, etc)',
  `model` varchar(100) NOT NULL COMMENT 'Nome do modelo específico',
  `api_token` text NOT NULL COMMENT 'Chave API específica para este modelo',
  `system_prompt` text DEFAULT NULL COMMENT 'Prompt do sistema específico para este modelo',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Se esta configuração está ativa',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `model_api_keys_provider_model_unique` (`provider`,`model`),
  KEY `model_api_keys_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_api_keys`
--

LOCK TABLES `model_api_keys` WRITE;
/*!40000 ALTER TABLE `model_api_keys` DISABLE KEYS */;
INSERT INTO `model_api_keys` VALUES (1,'gemini','gemini-2.0-flash','AIzaSyBCxoPMWv4oOH84kadpv_n6SRCU2PqWPoA','Prompt para Análise e Categorização de Extrato Bancário\r\n\r\nInstrua a IA a executar os seguintes procedimentos para processar um extrato bancário:\r\n\r\nAnálise do Extrato Bancário:\r\nLeia e interprete todas as transações contidas no extrato bancário fornecido, identificando data, valor, descrição/título e tipo (débito ou crédito).\r\nCategorização das Transações:\r\nClassifique as transações de acordo com as seguintes regras:\r\nDébitos:\r\nTransações identificadas como débitos (ex.: compras, saques) devem ser registradas na categoria Débitos.\r\nPagamentos via QR Code devem ser registrados na categoria Pagamentos.\r\nTransações de transferências enviadas devem ser registradas na categoria Transferências Enviadas.\r\nPagamentos (ex.: boletos, contas) devem ser registrados na categoria Pagamentos.\r\nReceitas:\r\nTransações de recebimentos (ex.: depósitos, Pix recebido) devem ser registradas na categoria Recebimentos.\r\nTransações de transferências recebidas devem ser registradas na categoria Transferências Recebidas.\r\nTransações não identificadas:\r\nCaso não seja possível determinar a categoria de uma transação de débito, registre-a na categoria Débito.\r\nCaso não seja possível determinar a categoria de uma transação de crédito, registre-a na categoria Recebimento.\r\nExtração de Informações do Título:\r\nAnalise o título ou descrição de cada transação para identificar informações sobre quem recebeu (no caso de débitos) ou quem pagou (no caso de créditos).\r\nInsira essas informações no campo Observações da transação.\r\nExemplo: Se o título for \"Pix enviado para João Silva\", registre \"João Silva\" como destinatário no campo Observações.\r\nCaso não haja informações claras sobre o pagador ou recebedor, deixe o campo Observações em branco ou registre \"Não identificado\".\r\nRegistro das Transações:\r\nCadastre cada transação em um sistema ou planilha com os seguintes campos:\r\nData\r\nValor\r\nCategoria (conforme definido acima)\r\nDescrição/Título Original\r\nObservações (com informações sobre pagador/recebedor, quando aplicável)\r\nGaranta que as transações sejam organizadas por data em ordem cronológica.\r\nValidação e Relatório:\r\nApós o processamento, valide se todas as transações foram categorizadas corretamente.\r\nGere um relatório resumido contendo:\r\nTotal de transações processadas.\r\nQuantidade de transações por categoria.\r\nLista de transações com categorização não identificada (se houver), para revisão manual.\r\nTratamento de Erros:\r\nCaso o extrato contenha dados inconsistentes (ex.: valores inválidos, descrições ilegíveis), registre essas transações em uma lista de \"erros\" com uma nota explicativa para revisão posterior.\r\nNão interrompa o processamento em caso de erros parciais; continue processando as demais transações.',1,'2025-04-20 14:09:12','2025-04-20 19:46:50');
/*!40000 ALTER TABLE `model_api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_templates`
--

DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type` enum('expense','income','system','custom') NOT NULL,
  `event` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `email_subject` text DEFAULT NULL,
  `email_content` text DEFAULT NULL,
  `whatsapp_content` text DEFAULT NULL,
  `push_title` text DEFAULT NULL,
  `push_content` text DEFAULT NULL,
  `push_image` varchar(255) DEFAULT NULL,
  `available_variables` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`available_variables`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_templates_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_templates`
--

LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_role_permission_id_foreign` (`permission_id`),
  KEY `permission_role_role_id_foreign` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_role`
--

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
INSERT INTO `permission_role` VALUES (1,1,1,NULL,NULL),(2,2,1,NULL,NULL),(3,3,1,NULL,NULL),(4,4,1,NULL,NULL),(5,5,1,NULL,NULL),(6,6,1,NULL,NULL),(7,7,1,NULL,NULL),(8,8,1,NULL,NULL),(9,7,2,NULL,NULL);
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `category` varchar(255) NOT NULL DEFAULT 'system',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'view_users','Ver usuários','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(2,'create_users','Criar usuários','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(3,'edit_users','Editar usuários','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(4,'delete_users','Excluir usuários','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(5,'view_roles','Ver perfis','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(6,'manage_roles','Gerenciar perfis','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(7,'view_reports','Ver relatórios','system','2025-04-20 13:43:34','2025-04-20 13:43:34'),(8,'manage_backups','Gerenciar backups','system','2025-04-20 13:43:34','2025-04-20 13:43:34');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replicate_settings`
--

DROP TABLE IF EXISTS `replicate_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `replicate_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(255) NOT NULL DEFAULT 'openai',
  `api_token` varchar(255) DEFAULT NULL,
  `model_version` varchar(255) NOT NULL DEFAULT 'claude-3-sonnet-20240229',
  `system_prompt` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replicate_settings`
--

LOCK TABLES `replicate_settings` WRITE;
/*!40000 ALTER TABLE `replicate_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `replicate_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  KEY `role_user_user_id_foreign` (`user_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','Acesso total ao sistema','2025-04-20 13:43:34','2025-04-20 13:43:34'),(2,'Usuário','Acesso básico ao sistema','2025-04-20 13:43:34','2025-04-20 13:43:34');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('bg0tKqCxa9YcUTmqfYhp82HgIRGWZmQW8pQhO7ws',3,'172.20.120.166','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiU0t5cnlCRE5LVFo4RGhvR2JIRkxzeVByeXNYM25ZMzN6ZHVwMmZqdyI7czozOiJ1cmwiO2E6MDp7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDU6Imh0dHA6Ly9vbmxpZmluLm9ubGl0ZWMuY29tLmJyL3NldHRpbmdzL2JhY2t1cCI7fX0=',1745184928),('NLmgq4qRDxBMer4LiCogwQRZIEChRAWdBQWvocVR',3,'172.20.120.166','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoieURGUDRKQk93MUh0S00yN2hrT3I3ZFJBRXRtVEc2WFJERVk5U3pkQiI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjQyOiJodHRwOi8vb25saWZpbi5vbmxpdGVjLmNvbS5ici90cmFuc2FjdGlvbnMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1745184720),('zCrMs89Lw17Jv7VmEf7idmXIsYUdJ3ikxBAMPcWx',3,'172.20.120.166','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWGprdzVOSEc1RUhSc1k3bXhaMThvbVc0OXp3djNVeW1BSTlPcG9NdCI7czozOiJ1cmwiO2E6MDp7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDI6Imh0dHA6Ly9vbmxpZmluLm9ubGl0ZWMuY29tLmJyL3RyYW5zYWN0aW9ucyI7fX0=',1745178482);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `email_notifications_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `email_notify_new_transactions` tinyint(1) NOT NULL DEFAULT 1,
  `email_notify_due_dates` tinyint(1) NOT NULL DEFAULT 1,
  `email_notify_low_balance` tinyint(1) NOT NULL DEFAULT 1,
  `email_low_balance_threshold` decimal(10,2) DEFAULT NULL,
  `whatsapp_notifications_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `whatsapp_number` varchar(255) DEFAULT NULL,
  `whatsapp_notify_new_transactions` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_notify_due_dates` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_notify_low_balance` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_low_balance_threshold` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`),
  KEY `settings_user_id_foreign` (`user_id`),
  CONSTRAINT `settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `module` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_logs_user_id_foreign` (`user_id`),
  KEY `system_logs_action_index` (`action`),
  KEY `system_logs_module_index` (`module`),
  KEY `system_logs_created_at_index` (`created_at`),
  CONSTRAINT `system_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('income','expense') NOT NULL,
  `status` enum('pending','paid') NOT NULL DEFAULT 'pending',
  `recurrence_type` enum('none','fixed','installment') NOT NULL DEFAULT 'none',
  `installment_number` int(11) DEFAULT NULL,
  `total_installments` int(11) DEFAULT NULL,
  `next_date` date DEFAULT NULL,
  `date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `account_id` bigint(20) unsigned NOT NULL,
  `notes` text DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_category_id_foreign` (`category_id`),
  KEY `transactions_account_id_foreign` (`account_id`),
  KEY `transactions_user_id_foreign` (`user_id`),
  CONSTRAINT `transactions_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `transactions_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (2,'expense','paid','none',NULL,NULL,NULL,'2025-04-01','Compra no débito - Auto Posto Santa Ines',5000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(3,'income','paid','none',NULL,NULL,NULL,'2025-04-01','Transferência recebida pelo Pix - MICHELLE GALVAO FREIRE - •••.234.998-•• - BCO C6 S.A. (0336) Agência: 1 Conta: 27968388-0',3000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(4,'expense','paid','none',NULL,NULL,NULL,'2025-04-01','Compra no débito - Restaurante e Lanchon',500,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(5,'expense','paid','none',NULL,NULL,NULL,'2025-04-01','Compra no débito - Montana',2000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(6,'expense','paid','none',NULL,NULL,NULL,'2025-04-02','Transferência enviada pelo Pix - ONLITEC INFORMATICA - 13.666.555/0001-19 - Nubank (0260) Agência: 1 Conta: 61409826-4',1000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(7,'expense','paid','none',NULL,NULL,NULL,'2025-04-02','Compra no débito - Drogasil2422',299,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(8,'expense','paid','none',NULL,NULL,NULL,'2025-04-02','Compra no débito - Bandeirante Auto Post',700,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(9,'income','paid','none',NULL,NULL,NULL,'2025-04-02','Transferência recebida pelo Pix - 57815082 BEATRIZ DOMINGOS GALVAO FREIRE - 57.815.082/0001-40 - CORA SCFI (0403) Agência: 1 Conta: 5382301-2',5000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(10,'expense','paid','none',NULL,NULL,NULL,'2025-04-02','Compra no débito - Marinanicodetede',700,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(11,'expense','paid','none',NULL,NULL,NULL,'2025-04-02','Compra no débito - Rede Sete Estrelas P',3000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(12,'expense','paid','none',NULL,NULL,NULL,'2025-04-03','Compra no débito - Marinanicodetede',950,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(13,'expense','paid','none',NULL,NULL,NULL,'2025-04-03','Compra no débito - Marinanicodetede',250,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(14,'income','paid','none',NULL,NULL,NULL,'2025-04-03','Transferência recebida pelo Pix - 57815082 BEATRIZ DOMINGOS GALVAO FREIRE - 57.815.082/0001-40 - CORA SCFI (0403) Agência: 1 Conta: 5382301-2',5000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(15,'expense','paid','none',NULL,NULL,NULL,'2025-04-03','Compra no débito - Cunha',5000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(16,'income','paid','none',NULL,NULL,NULL,'2025-04-03','Transferência recebida pelo Pix - 57815082 BEATRIZ DOMINGOS GALVAO FREIRE - 57.815.082/0001-40 - CORA SCFI (0403) Agência: 1 Conta: 5382301-2',50000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(17,'expense','paid','none',NULL,NULL,NULL,'2025-04-03','Compra no débito - Assai Atacadista Lj121',50076,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(18,'income','paid','none',NULL,NULL,NULL,'2025-04-04','Transferência recebida pelo Pix - CTECH SOLUCOES - 35.614.415/0001-30 - BANCO INTER (0077) Agência: 1 Conta: 4691835-3',10000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(19,'expense','paid','none',NULL,NULL,NULL,'2025-04-04','Compra no débito - Rede Sete Estrelas P',3000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(20,'expense','paid','none',NULL,NULL,NULL,'2025-04-04','Transferência enviada pelo Pix - Pagarme Pagamentos SA - 18.727.053/0001-74 - STONE IP S.A. (0197) Agência: 1 Conta: 16714636-4',3637,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(21,'expense','paid','none',NULL,NULL,NULL,'2025-04-05','Transferência enviada pelo Pix - 57815082 BEATRIZ DOMINGOS GALVAO FREIRE - 57.815.082/0001-40 - CORA SCFI (0403) Agência: 1 Conta: 5382301-2',3000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(22,'income','paid','none',NULL,NULL,NULL,'2025-04-08','Transferência recebida pelo Pix - ANA LUCIA ROCHA MAGALHAES - •••.807.638-•• - BCO SANTANDER (BRASIL) S.A. (0033) Agência: 3310 Conta: 1017696-7',10500,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(23,'expense','paid','none',NULL,NULL,NULL,'2025-04-08','Compra no débito - Restaurante e Lanchon',1500,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(24,'expense','paid','none',NULL,NULL,NULL,'2025-04-08','Compra no débito - Assai Atacadista Lj121',9000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(25,'income','paid','none',NULL,NULL,NULL,'2025-04-08','Transferência recebida pelo Pix - 57815082 BEATRIZ DOMINGOS GALVAO FREIRE - 57.815.082/0001-40 - CORA SCFI (0403) Agência: 1 Conta: 5382301-2',3000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(26,'expense','paid','none',NULL,NULL,NULL,'2025-04-08','Compra no débito - Autopostolc',3000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(27,'income','paid','none',NULL,NULL,NULL,'2025-04-10','Transferência recebida pelo Pix - 57815082 BEATRIZ DOMINGOS GALVAO FREIRE - 57.815.082/0001-40 - CORA SCFI (0403) Agência: 1 Conta: 5382301-2',5000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(28,'expense','paid','none',NULL,NULL,NULL,'2025-04-10','Compra no débito - Autopostolc',5000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(29,'income','paid','none',NULL,NULL,NULL,'2025-04-10','Transferência recebida pelo Pix - 57815082 BEATRIZ DOMINGOS GALVAO FREIRE - 57.815.082/0001-40 - CORA SCFI (0403) Agência: 1 Conta: 5382301-2',3000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(30,'expense','paid','none',NULL,NULL,NULL,'2025-04-10','Compra no débito - Autopostolc',3000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(31,'income','paid','none',NULL,NULL,NULL,'2025-04-11','Transferência recebida pelo Pix - Alessandro Galvão Freire - •••.841.228-•• - 99PAY IP S.A. Agência: 1 Conta: 514588-0',300,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(32,'income','paid','none',NULL,NULL,NULL,'2025-04-11','Transferência recebida pelo Pix - 57815082 BEATRIZ DOMINGOS GALVAO FREIRE - 57.815.082/0001-40 - CORA SCFI (0403) Agência: 1 Conta: 5382301-2',700,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(33,'income','paid','none',NULL,NULL,NULL,'2025-04-11','Transferência Recebida - Márcia Aparecida Domingos Freire - •••.569.868-•• - NU PAGAMENTOS - IP (0260) Agência: 1 Conta: 15572782-4',50,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(34,'expense','paid','none',NULL,NULL,NULL,'2025-04-11','Compra no débito - Autopostolc',1500,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(35,'income','paid','none',NULL,NULL,NULL,'2025-04-12','Transferência Recebida - Márcia Aparecida Domingos Freire - •••.569.868-•• - NU PAGAMENTOS - IP (0260) Agência: 1 Conta: 15572782-4',5000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(36,'expense','paid','none',NULL,NULL,NULL,'2025-04-12','Compra no débito - Autopostolc',5000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(37,'income','paid','none',NULL,NULL,NULL,'2025-04-14','Transferência recebida pelo Pix - DOSEVITA PRODUTOS NATURAIS LTDA - 31.196.826/0001-00 - CAIXA ECONOMICA FEDERAL (0104) Agência: 2935 Conta: 578063836-1',22000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(38,'expense','paid','none',NULL,NULL,NULL,'2025-04-14','Débito em conta',3332,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(39,'expense','paid','none',NULL,NULL,NULL,'2025-04-14','Compra no débito - Kalunga',7280,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(40,'expense','paid','none',NULL,NULL,NULL,'2025-04-14','Compra no débito - Acai do Genio',3750,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(41,'expense','paid','none',NULL,NULL,NULL,'2025-04-15','Compra no débito - Marli Cunha Mercado',2357,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(42,'income','paid','none',NULL,NULL,NULL,'2025-04-15','Transferência Recebida - Márcia Aparecida Domingos Freire - •••.569.868-•• - NU PAGAMENTOS - IP (0260) Agência: 1 Conta: 15572782-4',800000,5,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 21:31:58'),(43,'expense','paid','none',NULL,NULL,NULL,'2025-04-15','Compra no débito - Autopostolc',6000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(44,'expense','paid','none',NULL,NULL,NULL,'2025-04-15','Compra no débito - Raia3049',599,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(45,'income','paid','none',NULL,NULL,NULL,'2025-04-15','Transferência Recebida - Márcia Aparecida Domingos Freire - •••.569.868-•• - NU PAGAMENTOS - IP (0260) Agência: 1 Conta: 15572782-4',5000,2,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(46,'expense','paid','none',NULL,NULL,NULL,'2025-04-15','Compra no débito - Rede Sete Estrelas',5000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(47,'expense','paid','none',NULL,NULL,NULL,'2025-04-15','Compra no débito - Restaurante 4r',1600,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(48,'expense','paid','none',NULL,NULL,NULL,'2025-04-16','Compra no débito - Raia3049',599,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(49,'expense','paid','none',NULL,NULL,NULL,'2025-04-16','Compra no débito - Marinanicodetede',1700,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(50,'expense','paid','none',NULL,NULL,NULL,'2025-04-16','Compra no débito - Nutri Vale Produtos Na',1482,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(51,'income','paid','none',NULL,NULL,NULL,'2025-04-16','Transferência recebida pelo Pix - 57815082 BEATRIZ DOMINGOS GALVAO FREIRE - 57.815.082/0001-40 - CORA SCFI (0403) Agência: 1 Conta: 5382301-2',500000,5,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 21:31:52'),(52,'expense','paid','none',NULL,NULL,NULL,'2025-04-16','Compra no débito - Rede Sete Estrelas',3000,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(53,'expense','paid','none',NULL,NULL,NULL,'2025-04-17','Compra no débito - Marinanicodetede',1500,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(54,'income','paid','none',NULL,NULL,NULL,'2025-04-18','Transferência recebida pelo Pix - DANIELLE F F ABREU - •••.391.087-•• - BCO DO BRASIL S.A. (0001) Agência: 2909 Conta: 49585-9',600000,5,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 21:31:47'),(55,'expense','paid','none',NULL,NULL,NULL,'2025-04-18','Compra no débito - Mercado Seven Ii',1598,1,9,NULL,3,'2025-04-20 16:41:09','2025-04-20 16:41:09'),(56,'income','paid','none',NULL,NULL,NULL,'2025-04-20','SALARIO',30000,5,9,NULL,3,'2025-04-20 17:04:06','2025-04-20 17:06:23'),(57,'expense','paid','none',NULL,NULL,NULL,'2025-03-24','Transf Pix enviada - Marcia Aparecida Domingos Freire - 277.569.868-90',300,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(58,'expense','paid','none',NULL,NULL,NULL,'2025-03-21','Transf Pix enviada - Antonio Carlos Freire Silva - 623.192.132-87',12500,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(59,'income','paid','none',NULL,NULL,NULL,'2025-03-21','Transf Pix recebida - Márcia Aparecida Domingos Freire - 277.569.868-90',500,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(60,'income','paid','none',NULL,NULL,NULL,'2025-03-21','Pagamento recebido - Hi Engenharia - 10.698.394/0001-57',12000,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(61,'expense','paid','none',NULL,NULL,NULL,'2025-03-20','Transf Pix enviada - MARGARETH APARECIDA DA SILVA - 098.424.168-01',4000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(62,'expense','paid','none',NULL,NULL,NULL,'2025-03-20','Pgto QR Code Pix - ACAI DO GENIO LTDA - 31.868.849/0001-05',5050,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(63,'expense','paid','none',NULL,NULL,NULL,'2025-03-20','Pgto QR Code Pix - AUTO POSTO LC ANDROMEDA LTDA - 55.238.424/0001-80',10000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(64,'expense','paid','none',NULL,NULL,NULL,'2025-03-20','Pgto QR Code Pix - COMERCIAL SACILOTTO LTDA - 50.028.976/0001-40',4286,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(65,'expense','paid','none',NULL,NULL,NULL,'2025-03-20','Transf Pix enviada - MARGARETH APARECIDA DA SILVA - 098.424.168-01',4000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(66,'expense','paid','none',NULL,NULL,NULL,'2025-03-20','Pgto QR Code Pix - Miriam De Paula Ribeiro Da Cunha - 407.447.498-08',1687,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(67,'expense','paid','none',NULL,NULL,NULL,'2025-03-19','Pgto QR Code Pix - Demerge Brasil Facilitadora de Pagamentos - 33.967.103/0001-84',3990,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(68,'expense','paid','none',NULL,NULL,NULL,'2025-03-19','Pgto QR Code Pix - TENDA ATACADO LTDA - 01.157.555/0001-04',27921,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(69,'expense','paid','none',NULL,NULL,NULL,'2025-03-19','Transf Pix enviada - Marcia Aparecida Domingos Freire - 277.569.868-90',54000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(70,'expense','paid','none',NULL,NULL,NULL,'2025-03-19','Transf Pix enviada - MARIA FERNANDA VARGAS MURILLO - 715.286.541-88',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(71,'expense','paid','none',NULL,NULL,NULL,'2025-03-19','Transf Pix enviada - MARLON ANDRES FLOREZ OSPINA - 236.244.918-14',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(72,'expense','paid','none',NULL,NULL,NULL,'2025-03-19','Transf Pix enviada - ASDRUBAL ALEXANDRO M AYALA - 800.743.429-16',2400,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(73,'expense','paid','none',NULL,NULL,NULL,'2025-03-19','Transf Pix enviada - Alessandro Galvão Freire - 248.841.228-79',2000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(74,'expense','paid','none',NULL,NULL,NULL,'2025-03-19','Transf Pix enviada - JULIO SUNE 27323598826 - 12.616.426/0001-53',20000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(75,'expense','paid','none',NULL,NULL,NULL,'2025-03-19','Transf Pix enviada - Beatriz Domingos Galvão Freire - 581.630.298-11',5000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(76,'expense','paid','none',NULL,NULL,NULL,'2025-03-19','Transf Pix enviada - Geovanna Domingos Galvão Freire - 581.630.078-42',8000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(77,'income','paid','none',NULL,NULL,NULL,'2025-03-19','Transferência recebida - Quallit Servicos De Informatica Ltda - 09.639.356/0001-44',128000,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(78,'income','paid','none',NULL,NULL,NULL,'2025-03-19','Transf Pix recebida - VSIT SOLUCOES - 34.946.642/0001-08',10000,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(79,'expense','paid','none',NULL,NULL,NULL,'2025-03-18','Pgto QR Code Pix - ARMAZEM SAO JOSE DOS CAMPOS COMERCIO DE BEBIDAS E CONEXOS LTDA - 29.123.325/0001-43',3228,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(80,'expense','paid','none',NULL,NULL,NULL,'2025-03-18','Pgto QR Code Pix - ASSAI ATACADISTA - 06.057.223/0001-71',39463,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(81,'expense','paid','none',NULL,NULL,NULL,'2025-03-18','Transf Pix enviada - MARLON ANDRES FLOREZ OSPINA - 236.244.918-14',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(82,'expense','paid','none',NULL,NULL,NULL,'2025-03-18','Transf Pix enviada - MARIA FERNANDA VARGAS MURILLO - 715.286.541-88',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(83,'expense','paid','none',NULL,NULL,NULL,'2025-03-18','Transf Pix enviada - ASDRUBAL ALEXANDRO M AYALA - 800.743.429-16',2400,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(84,'income','paid','none',NULL,NULL,NULL,'2025-03-18','Pagamento recebido - Helpdeg - 06.195.060/0001-93',74100,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(85,'expense','paid','none',NULL,NULL,NULL,'2025-03-13','Transf Pix enviada - MARLON ANDRES FLOREZ OSPINA - 236.244.918-14',3000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(86,'expense','paid','none',NULL,NULL,NULL,'2025-03-13','Transf Pix enviada - MARIA FERNANDA VARGAS MURILLO - 715.286.541-88',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(87,'expense','paid','none',NULL,NULL,NULL,'2025-03-13','Transf Pix enviada - ASDRUBAL ALEXANDRO M AYALA - 800.743.429-16',2400,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(88,'expense','paid','none',NULL,NULL,NULL,'2025-03-13','Pgto QR Code Pix - MARLI CUNHA MERCADO LTDA - 55.585.729/0001-69',2503,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(89,'expense','paid','none',NULL,NULL,NULL,'2025-03-12','Pgto QR Code Pix - AUTO POSTO LC ANDROMEDA LTDA - 55.238.424/0001-80',3000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(90,'expense','paid','none',NULL,NULL,NULL,'2025-03-12','Pgto QR Code Pix - Miriam De Paula Ribeiro Da Cunha - 407.447.498-08',1631,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(91,'income','paid','none',NULL,NULL,NULL,'2025-03-12','Transf Pix recebida - CALABASAS CONDOMINIUN RESORT - 59.120.700/0001-62',9500,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(92,'expense','paid','none',NULL,NULL,NULL,'2025-03-12','Transf Pix enviada - MARLON ANDRES FLOREZ OSPINA - 236.244.918-14',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(93,'expense','paid','none',NULL,NULL,NULL,'2025-03-12','Transf Pix enviada - MARIA FERNANDA VARGAS MURILLO - 715.286.541-88',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(94,'expense','paid','none',NULL,NULL,NULL,'2025-03-12','Transf Pix enviada - ASDRUBAL ALEXANDRO M AYALA - 800.743.429-16',2400,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(95,'expense','paid','none',NULL,NULL,NULL,'2025-03-12','Pgto QR Code Pix - MARLI CUNHA MERCADO LTDA - 55.585.729/0001-69',3749,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(96,'expense','paid','none',NULL,NULL,NULL,'2025-03-11','Transf Pix enviada - Alessandro Galvão Freire - 248.841.228-79',2000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(97,'expense','paid','none',NULL,NULL,NULL,'2025-03-11','Pgto QR Code Pix - Miriam De Paula Ribeiro Da Cunha - 407.447.498-08',1624,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(98,'expense','paid','none',NULL,NULL,NULL,'2025-03-11','Transf Pix enviada - MARLON ANDRES FLOREZ OSPINA - 236.244.918-14',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(99,'expense','paid','none',NULL,NULL,NULL,'2025-03-11','Transf Pix enviada - MARIA FERNANDA VARGAS MURILLO - 715.286.541-88',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(100,'expense','paid','none',NULL,NULL,NULL,'2025-03-11','Transf Pix enviada - ASDRUBAL ALEXANDRO M AYALA - 800.743.429-16',2400,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(101,'expense','paid','none',NULL,NULL,NULL,'2025-03-10','Pgto QR Code Pix - PIX Marketplace - 10.573.521/0001-91',2845,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(102,'expense','paid','none',NULL,NULL,NULL,'2025-03-10','Transf Pix enviada - Alessandro Galvão Freire - 248.841.228-79',2000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(103,'expense','paid','none',NULL,NULL,NULL,'2025-03-10','Pgto QR Code Pix - PADARIA E CONFEITARIA IRMAOS RAM - 02.240.666/0001-42',4200,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(104,'income','paid','none',NULL,NULL,NULL,'2025-03-10','Pagamento recebido - Grama Vale - 37.880.206/0001-63',5000,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(105,'expense','paid','none',NULL,NULL,NULL,'2025-03-10','Transf Pix enviada - MARLON ANDRES FLOREZ OSPINA - 236.244.918-14',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(106,'expense','paid','none',NULL,NULL,NULL,'2025-03-10','Transf Pix enviada - MARIA FERNANDA VARGAS MURILLO - 715.286.541-88',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(107,'expense','paid','none',NULL,NULL,NULL,'2025-03-10','Transf Pix enviada - ASDRUBAL ALEXANDRO M AYALA - 800.743.429-16',2400,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(108,'expense','paid','none',NULL,NULL,NULL,'2025-03-10','Transf Pix enviada - Marcia Aparecida Domingos Freire - 277.569.868-90',1200,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(109,'expense','paid','none',NULL,NULL,NULL,'2025-03-10','Pgto QR Code Pix - MARLI CUNHA MERCADO LTDA - 55.585.729/0001-69',2438,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(110,'expense','paid','none',NULL,NULL,NULL,'2025-03-09','Pgto QR Code Pix - IUSDREIA BIANCA DOS SANTOS 29040764840 - 36.326.250/0001-63',1500,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(111,'expense','paid','none',NULL,NULL,NULL,'2025-03-09','Pgto QR Code Pix - SERGIO QUINTANILHA NETO - 383.757.948-48',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(112,'expense','paid','none',NULL,NULL,NULL,'2025-03-09','Pgto QR Code Pix - CACHOEIRA DA PEDREIRA RECREACAO E LAZERLTDA ME - 46.217.910/0001-21',15000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(113,'expense','paid','none',NULL,NULL,NULL,'2025-03-09','Pgto QR Code Pix - DROGARIA SAO PAULO S A - 61.412.110/0002-36',2258,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(114,'expense','paid','none',NULL,NULL,NULL,'2025-03-09','Pgto QR Code Pix - AUTO POSTO LC ANDROMEDA LTDA - 55.238.424/0001-80',15000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(115,'expense','paid','none',NULL,NULL,NULL,'2025-03-09','Pgto QR Code Pix - Miriam De Paula Ribeiro Da Cunha - 407.447.498-08',2940,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(116,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Transf Pix enviada - Marcia Aparecida Domingos Freire - 277.569.868-90',5960,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(117,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Pgto QR Code Pix - WMS SUPERMERCADOS DO BRASIL LTDA - 93.209.765/0001-17',3721,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(118,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Pgto QR Code Pix - WMS SUPERMERCADOS DO BRASIL LTDA - 93.209.765/0001-17',9578,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(119,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Transf Pix enviada - Alessandro Galvão Freire - 248.841.228-79',4000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(120,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Pgto QR Code Pix - Eliane de Fatima Paiva - 094.209.238-43',2285,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(121,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Transf Pix enviada - ASDRUBAL ALEXANDRO M AYALA - 800.743.429-16',2400,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(122,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Transf Pix enviada - MARIA FERNANDA VARGAS MURILLO - 715.286.541-88',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(123,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Pgto QR Code Pix - SHPP BRASIL INSTITUICAO DE PAGAMENTO E S - 38.372.267/0001-82',2988,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(124,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Pgto QR Code Pix - SHPP BRASIL INSTITUICAO DE PAGAMENTO E S - 38.372.267/0001-82',5290,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(125,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Pgto QR Code Pix - SHPP BRASIL INSTITUICAO DE PAGAMENTO E S - 38.372.267/0001-82',3870,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(126,'expense','paid','none',NULL,NULL,NULL,'2025-03-08','Pgto QR Code Pix - HOSTGATOR - 15.754.475/0001-40',4718,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(127,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Pgto QR Code Pix - Pagarme Pagamentos SA - 18.727.053/0001-74',3638,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(128,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Pgto QR Code Pix - Danilo Mendes de Andrade - 348.118.688-62',4000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(129,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Pgto QR Code Pix - Marcio Heraldo Dos Santos - 246.870.668-44',3200,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(130,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Pgto QR Code Pix - TENDA ATACADO LTDA - 01.157.555/0001-04',24491,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(131,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Transf Pix enviada - MARLON ANDRES FLOREZ OSPINA - 236.244.918-14',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(132,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Transf Pix enviada - Miriam De Paula Ribeiro Da Cunha - 407.447.498-08',1254,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(133,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Transf Pix enviada - JULIANA PRISCILA DE OLIVEIRA - 405.293.608-61',10000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(134,'income','paid','none',NULL,NULL,NULL,'2025-03-07','Transf Pix recebida - HI C E S LTDA - 10.892.915/0001-02',39859,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(135,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Transf Pix enviada - MARIA FERNANDA VARGAS MURILLO - 715.286.541-88',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(136,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Pgto QR Code Pix - Claro - 40.432.544/0001-47',2596,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(137,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Boleto pago - Sabesp -',9895,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(138,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Transf Pix enviada - ASDRUBAL ALEXANDRO M AYALA - 800.743.429-16',2400,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(139,'income','paid','none',NULL,NULL,NULL,'2025-03-07','Transferência recebida - Quallit Servicos De Informatica Ltda - 09.639.356/0001-44',168000,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(140,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Transf Pix enviada - Alessandro Galvão Freire - 248.841.228-79',2600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(141,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Pgto QR Code Pix - TELEFONICA BRASIL S A - 02.558.157/0001-62',12349,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(142,'expense','paid','none',NULL,NULL,NULL,'2025-03-07','Pgto QR Code Pix - MARLI CUNHA MERCADO LTDA - 55.585.729/0001-69',1460,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(143,'expense','paid','none',NULL,NULL,NULL,'2025-03-06','Transf Pix enviada - Marcia Aparecida Domingos Freire - 277.569.868-90',16055,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(144,'expense','paid','none',NULL,NULL,NULL,'2025-03-06','Pgto QR Code Pix - ASSAI ATACADISTA - 06.057.223/0001-71',29554,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(145,'expense','paid','none',NULL,NULL,NULL,'2025-03-06','Transf Pix enviada - Marcia Aparecida Domingos Freire - 277.569.868-90',8000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(146,'income','paid','none',NULL,NULL,NULL,'2025-03-06','Transf Pix recebida - Márcia Aparecida Domingos Freire - 277.569.868-90',400,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(147,'expense','paid','none',NULL,NULL,NULL,'2025-03-06','Pgto QR Code Pix - Miriam De Paula Ribeiro Da Cunha - 407.447.498-08',2733,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(148,'income','paid','none',NULL,NULL,NULL,'2025-03-06','Pagamento recebido - Giselle Karine Guedes Ribeiro Eireli - 16.571.130/0001-14',72000,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(149,'expense','paid','none',NULL,NULL,NULL,'2025-03-03','Pgto QR Code Pix - Pagarme Pagamentos SA - 18.727.053/0001-74',3223,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(150,'expense','paid','none',NULL,NULL,NULL,'2025-03-03','Pgto QR Code Pix - ASSAI ATACADISTA - 06.057.223/0001-71',7170,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(151,'expense','paid','none',NULL,NULL,NULL,'2025-03-03','Transf Pix enviada - MARIA FERNANDA VARGAS MURILLO - 715.286.541-88',3600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(152,'expense','paid','none',NULL,NULL,NULL,'2025-03-03','Transf Pix enviada - ASDRUBAL ALEXANDRO M AYALA - 800.743.429-16',2400,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(153,'expense','paid','none',NULL,NULL,NULL,'2025-03-03','Transf Pix enviada - Alessandro Galvão Freire - 248.841.228-79',3000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(154,'expense','paid','none',NULL,NULL,NULL,'2025-03-03','Pgto QR Code Pix - MARLI CUNHA MERCADO LTDA - 55.585.729/0001-69',1600,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(155,'expense','paid','none',NULL,NULL,NULL,'2025-03-02','Transf Pix enviada - Simone Cristina Mariano Siqueira - 338.364.578-90',3200,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(156,'expense','paid','none',NULL,NULL,NULL,'2025-03-02','Transf Pix enviada - Simone Cristina Mariano Siqueira - 338.364.578-90',3000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(157,'expense','paid','none',NULL,NULL,NULL,'2025-03-02','Pgto QR Code Pix - ASSOCIACAO DESPORTIVA CLASSISTA EMBRAER - 45.183.845/0001-06',12500,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(158,'expense','paid','none',NULL,NULL,NULL,'2025-03-02','Pgto QR Code Pix - Miriam De Paula Ribeiro Da Cunha - 407.447.498-08',2659,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(159,'income','paid','none',NULL,NULL,NULL,'2025-03-02','Transf Pix recebida - Alessandro Galvão Freire - 248.841.228-79',1900,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(160,'income','paid','none',NULL,NULL,NULL,'2025-03-02','Transf Pix recebida - Márcia Aparecida Domingos Freire - 277.569.868-90',5000,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(161,'income','paid','none',NULL,NULL,NULL,'2025-03-02','Resgate de Reserva de Limite - Cartão de Crédito - 37.880.206/0001-63',23500,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(162,'expense','paid','none',NULL,NULL,NULL,'2025-03-01','Pgto QR Code Pix - ARMAZEM SAO JOSE DOS CAMPOS COMERCIO DE BEBIDAS E CONEXOS LTDA - 29.123.325/0001-43',3089,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(163,'expense','paid','none',NULL,NULL,NULL,'2025-03-01','Pgto QR Code Pix - ASSAI ATACADISTA - 06.057.223/0001-71',25053,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(164,'expense','paid','none',NULL,NULL,NULL,'2025-03-01','Transf Pix enviada - Geovanna Domingos Galvão Freire - 581.630.078-42',2000,1,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48'),(165,'income','paid','none',NULL,NULL,NULL,'2025-03-01','Transf Pix recebida - AIYRA VITORIA BRASIL PRADO DE CARVALHO - 386.720.558-29',42500,2,8,NULL,3,'2025-04-20 19:47:48','2025-04-20 19:47:48');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `push_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `due_date_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `whatsapp_notifications` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrador','alfreire@onlitec.com.br',NULL,'2025-04-20 13:43:33','$2y$12$dWXmsVSNSDFtmMeIrHdD0eChR454d9i6TWnGW69b/.FTyRX2e6mJO',1,1,NULL,'2025-04-20 13:42:30','2025-04-20 13:43:33',1,0,1,0),(2,'Administrador Galvatec','galvatec@onlifin.com.br',NULL,'2025-04-20 13:43:33','$2y$12$imQVLcvWRHcT8L25YEtQOOle/NHYwJAQysABbAjKPrD2rAjJASzYS',1,1,NULL,'2025-04-20 13:42:31','2025-04-20 13:43:33',1,0,1,0),(3,'Marcia','marciafreire@onlitec.com.br',NULL,NULL,'$2y$12$zNEQwb3lTlk4.JGwh6usxOK8ndtf6A.i.JHBhKwiZmxSB0BcKRLN.',1,1,NULL,'2025-04-20 13:44:13','2025-04-20 13:45:08',1,0,1,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-20 21:35:30
