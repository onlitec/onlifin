<?php

namespace App\Livewire;

use Livewire\Component;

class DummyComponent extends Component
{
    public function render()
    {
        return view('livewire.dummy-component');
    }
}
