<x-app-layout>
    <div class="container-app">
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-gray-900">Verificação de Menu</h1>
            <p class="mt-1 text-sm text-gray-600">Esta página é apenas para verificar se o menu foi atualizado.</p>
        </div>

        <div class="card">
            <div class="card-body">
                <p>Se você está vendo esta página, significa que o arquivo foi criado com sucesso.</p>
                <p>Agora vamos substituir o arquivo do layout principal.</p>
            </div>
        </div>
    </div>
</x-app-layout> 