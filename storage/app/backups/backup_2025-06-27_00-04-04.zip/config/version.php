<?php

return [
    'number' => '1.0.1',
    'name' => 'Onlifin',
    'release_date' => '2024-03-11', // Data atual
]; 