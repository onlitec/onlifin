<div>
    <h2>Configurações de Notificações</h2>
    <p>Este é um teste do modal.</p>
    <button wire:click="closeModal">Fechar</button>
</div> 