<x-app-layout>
    <div class="container-app">
        <!-- Cabeçalho -->
        <div class="flex justify-between items-center mb-6">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">Saldos das Contas</h1>
                <p class="text-gray-600">Visualização dos saldos de todas as suas contas bancárias</p>
            </div>
            <div>
                <a href="{{ route('accounts.create') }}" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:outline-none focus:border-blue-700 focus:ring-blue-200 active:bg-blue-800 transition ease-in-out duration-150">
                    <i class="ri-add-line mr-1"></i> Nova Conta
                </a>
            </div>
        </div>

        <!-- Resumo total -->
        <div class="card shadow-sm border border-gray-200 rounded-xl mb-6">
            <div class="p-6">
                <h2 class="text-lg font-semibold mb-4">Saldo Total</h2>
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-gray-600">Soma de todas as contas:</p>
                    </div>
                    <div>
                        @php
                            $totalBalance = $accounts->sum('current_balance');
                        @endphp
                        <p class="text-2xl font-bold {{ $totalBalance >= 0 ? 'text-green-600' : 'text-red-600' }}">
                            R$ {{ number_format($totalBalance, 2, ',', '.') }}
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Listagem das contas -->
        <div class="card shadow-sm border border-gray-200 rounded-xl">
            <div class="flex justify-between items-center p-4 border-b border-gray-200">
                <div class="flex items-center">
                    <div class="bg-blue-100 p-2 rounded-full text-blue-600 mr-3">
                        <i class="ri-bank-line text-lg"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold">Detalhamento por Conta</h3>
                        <p class="text-sm text-gray-500">Visualize os saldos de cada conta bancária</p>
                    </div>
                </div>
            </div>

            <div class="p-4">
                @if($accounts->count() > 0)
                    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
                        @foreach($accounts as $account)
                            <div class="border border-gray-200 rounded-lg shadow-sm overflow-hidden">
                                <div class="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                                    <div class="flex items-center">
                                        <span class="w-3 h-3 rounded-full mr-2" style="background-color: {{ $account->color ?? '#6b7280' }};"></span>
                                        <h3 class="font-medium">{{ $account->name }}</h3>
                                    </div>
                                    <a href="{{ route('accounts.edit', $account) }}" class="text-gray-400 hover:text-blue-600">
                                        <i class="ri-edit-line"></i>
                                    </a>
                                </div>
                                <div class="p-4">
                                    <div class="flex justify-between items-center mb-2">
                                        <span class="text-gray-600">Saldo Atual:</span>
                                        <span class="font-bold {{ $account->current_balance >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                            R$ {{ number_format($account->current_balance, 2, ',', '.') }}
                                        </span>
                                    </div>
                                    <div class="flex justify-between items-center text-sm">
                                        <span class="text-gray-500">Saldo Inicial:</span>
                                        <span class="text-gray-700">
                                            R$ {{ number_format($account->initial_balance, 2, ',', '.') }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="text-center py-8 bg-gray-50 rounded-lg">
                        <p class="text-gray-500 mb-4">Você ainda não possui contas bancárias cadastradas.</p>
                        <a href="{{ route('accounts.create') }}" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                            <i class="ri-add-line mr-1"></i> Adicionar Conta
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </div>
</x-app-layout> 