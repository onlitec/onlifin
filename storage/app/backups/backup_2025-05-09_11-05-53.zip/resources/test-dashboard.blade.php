<!DOCTYPE html>
<html>
<head>
    <title>Teste Dashboard</title>
</head>
<body>
    <h1>Esta é uma página de teste do dashboard</h1>
    <p>Se você está vendo esta página, o roteamento está funcionando corretamente.</p>
</body>
</html> 