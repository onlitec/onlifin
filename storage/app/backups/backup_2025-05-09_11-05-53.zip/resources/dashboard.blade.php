<x-app-layout>
    <!-- Import Chart.js para gráficos -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <div class="container-app">
        <!-- Cabeçalho -->
        <div class="flex justify-between items-center mb-6">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">Dashboard</h1>
                <p class="text-gray-600">Visão geral das suas finanças</p>
            </div>
            <div>
                <form method="GET" action="{{ route('dashboard') }}" class="flex items-center">
                    <span class="mr-2">Período:</span>
                    <select name="period" id="period" class="form-select rounded-md border-gray-300 shadow-sm" style="min-width: 150px" onchange="this.form.submit()">
                            <option value="current_month" {{ $period == 'current_month' ? 'selected' : '' }}>Este Mês</option>
                            <option value="last_month" {{ $period == 'last_month' ? 'selected' : '' }}>Mês Passado</option>
                            <option value="current_year" {{ $period == 'current_year' ? 'selected' : '' }}>Este Ano</option>
                            <option value="last_year" {{ $period == 'last_year' ? 'selected' : '' }}>Ano Passado</option>
                            <option value="all_time" {{ $period == 'all_time' ? 'selected' : '' }}>Todo Período</option>
                        </select>
                </form>
            </div>
        </div>

        <!-- Cards de Resumo - Grid responsivo -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <!-- Saldo Atual -->
            <div class="card border-l-4 border-l-blue-500 overflow-hidden">
                <div class="p-4">
                    <div class="flex items-center justify-between pb-2">
                        <h3 class="text-sm font-medium text-gray-600">Saldo Atual Total</h3>
                        <div x-data="{ tooltipVisible: false, tooltipText: 'Soma dos saldos atuais de todas as suas contas.' }" class="relative">
                            <div 
                                @mouseenter="tooltipVisible = true" 
                                @mouseleave="tooltipVisible = false"
                                class="bg-blue-100 p-1.5 rounded-full text-blue-600 cursor-pointer">
                                <i class="ri-wallet-line text-lg"></i>
                            </div>
                            <div x-show="tooltipVisible" x-transition 
                                 class="absolute z-10 -top-2 right-full mr-2 w-48 p-2 text-xs text-white bg-gray-700 rounded-md shadow-lg whitespace-normal">
                                <span x-text="tooltipText"></span>
                            </div>
                        </div>
                    </div>
                    <div class="text-2xl font-bold">R$ {{ number_format($currentBalance, 2, ',', '.') }}</div>
                    <p class="text-xs text-gray-500 mt-1">Inclui saldo inicial e transações</p>
                </div>
            </div>

            <!-- Receitas (Período) -->
            <div class="card border-l-4 border-l-green-500 overflow-hidden">
                <div class="p-4">
                    <div class="flex items-center justify-between pb-2">
                        <h3 class="text-sm font-medium text-gray-600">Receitas</h3>
                        <div x-data="{ tooltipVisible: false, tooltipText: 'Soma de todas as receitas marcadas como \'Pagas\' no período selecionado.' }" class="relative">
                            <div 
                                @mouseenter="tooltipVisible = true" 
                                @mouseleave="tooltipVisible = false"
                                class="bg-green-100 p-1.5 rounded-full text-green-600 cursor-pointer">
                                <i class="ri-arrow-up-circle-line text-lg"></i>
                            </div>
                            <div x-show="tooltipVisible" x-transition 
                                 class="absolute z-10 -top-2 right-full mr-2 w-48 p-2 text-xs text-white bg-gray-700 rounded-md shadow-lg whitespace-normal">
                                <span x-text="tooltipText"></span>
                            </div>
                        </div>
                    </div>
                    <div class="text-2xl font-bold">R$ {{ number_format($totalIncomePeriod / 100, 2, ',', '.') }}</div>
                    @if($period !== 'all_time')
                    <div class="flex items-center mt-1">
                        <span class="text-xs {{ $incomeVariation >= 0 ? 'text-green-600' : 'text-red-600' }}">
                            <i class="ri-{{ $incomeVariation >= 0 ? 'arrow-up-line' : 'arrow-down-line' }} mr-1"></i>
                        {{ number_format(abs($incomeVariation), 1, ',', '.') }}%
                    </span>
                        <span class="text-xs ml-1 text-gray-500">vs período anterior</span>
                    </div>
                    @else
                    <p class="text-xs text-gray-500 mt-1">Período total</p>
                    @endif
                </div>
            </div>

            <!-- Despesas (Período) -->
            <div class="card border-l-4 border-l-red-500 overflow-hidden">
                <div class="p-4">
                    <div class="flex items-center justify-between pb-2">
                        <h3 class="text-sm font-medium text-gray-600">Despesas</h3>
                        <div x-data="{ tooltipVisible: false, tooltipText: 'Soma de todas as despesas marcadas como \'Pagas\' no período selecionado.' }" class="relative">
                            <div 
                                @mouseenter="tooltipVisible = true" 
                                @mouseleave="tooltipVisible = false"
                                class="bg-red-100 p-1.5 rounded-full text-red-600 cursor-pointer">
                                <i class="ri-arrow-down-circle-line text-lg"></i>
                            </div>
                            <div x-show="tooltipVisible" x-transition 
                                 class="absolute z-10 -top-2 right-full mr-2 w-48 p-2 text-xs text-white bg-gray-700 rounded-md shadow-lg whitespace-normal">
                                <span x-text="tooltipText"></span>
                            </div>
                        </div>
                    </div>
                    <div class="text-2xl font-bold">R$ {{ number_format($totalExpensesPeriod / 100, 2, ',', '.') }}</div>
                    @if($period !== 'all_time')
                    <div class="flex items-center mt-1">
                        <span class="text-xs {{ $expensesVariation <= 0 ? 'text-green-600' : 'text-red-600' }}">
                            <i class="ri-{{ $expensesVariation >= 0 ? 'arrow-up-line' : 'arrow-down-line' }} mr-1"></i>
                        {{ number_format(abs($expensesVariation), 1, ',', '.') }}%
                    </span>
                        <span class="text-xs ml-1 text-gray-500">vs período anterior</span>
                    </div>
                    @else
                    <p class="text-xs text-gray-500 mt-1">Período total</p>
                    @endif
                </div>
            </div>

            <!-- Saldo (Período) -->
            <div class="card border-l-4 {{ $balancePeriod >= 0 ? 'border-l-green-500' : 'border-l-red-500' }} overflow-hidden">
                <div class="p-4">
                    <div class="flex items-center justify-between pb-2">
                        <h3 class="text-sm font-medium text-gray-600">Saldo Período</h3>
                        <div x-data="{ tooltipVisible: false, tooltipText: 'Receitas pagas menos despesas pagas no período selecionado.' }" class="relative">
                            <div 
                                @mouseenter="tooltipVisible = true" 
                                @mouseleave="tooltipVisible = false"
                                class="bg-{{ $balancePeriod >= 0 ? 'green' : 'red' }}-100 p-1.5 rounded-full text-{{ $balancePeriod >= 0 ? 'green' : 'red' }}-600 cursor-pointer">
                                <i class="ri-pie-chart-line text-lg"></i>
                            </div>
                            <div x-show="tooltipVisible" x-transition 
                                 class="absolute z-10 -top-2 right-full mr-2 w-48 p-2 text-xs text-white bg-gray-700 rounded-md shadow-lg whitespace-normal">
                                <span x-text="tooltipText"></span>
                            </div>
                        </div>
                    </div>
                    <div class="text-2xl font-bold">R$ {{ number_format($balancePeriod / 100, 2, ',', '.') }}</div>
                    @if($period !== 'all_time')
                    <div class="flex items-center mt-1">
                        <span class="text-xs {{ $balanceVariation >= 0 ? 'text-green-600' : 'text-red-600' }}">
                            <i class="ri-{{ $balanceVariation >= 0 ? 'arrow-up-line' : 'arrow-down-line' }} mr-1"></i>
                        {{ number_format(abs($balanceVariation), 1, ',', '.') }}%
                    </span>
                        <span class="text-xs ml-1 text-gray-500">vs período anterior</span>
                    </div>
                    @else
                    <p class="text-xs text-gray-500 mt-1">Período total</p>
                    @endif
                </div>
            </div>
        </div>

        <!-- NOVA SEÇÃO: Saldos por Contas Bancárias -->
        <div class="card shadow-sm border border-gray-200 rounded-xl mb-6">
            <div class="flex justify-between items-center p-4 border-b border-gray-200">
                <div class="flex items-center">
                    <div class="bg-blue-100 p-2 rounded-full text-blue-600 mr-3">
                        <i class="ri-bank-line text-lg"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold">Saldos por Contas Bancárias</h3>
                        <p class="text-sm text-gray-500">Visualize o saldo de cada conta</p>
                    </div>
                </div>
                <a href="{{ route('accounts.create') }}" class="inline-flex items-center px-3 py-1.5 text-sm font-medium bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50">
                    <i class="ri-add-line mr-1.5"></i>
                    Nova Conta
                </a>
            </div>
            <div class="p-4">
                @if(isset($userAccounts) && $userAccounts->count() > 0)
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        @foreach($userAccounts as $account)
                            <div class="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                                <div class="p-4 border-b border-gray-100 flex justify-between items-center">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full flex items-center justify-center" 
                                             style="background-color: {{ $account->color ?? '#e5e7eb' }}40;">
                                            <i class="ri-bank-line text-lg" 
                                               style="color: {{ $account->color ?? '#6b7280' }};"></i>
                                        </div>
                                        <div class="ml-3">
                                            <h4 class="font-medium">{{ $account->name }}</h4>
                                            <p class="text-xs text-gray-500">{{ $account->type }}</p>
                                        </div>
                                    </div>
                                    <a href="{{ route('accounts.edit', $account) }}" class="text-gray-400 hover:text-blue-600">
                                        <i class="ri-edit-line"></i>
                                    </a>
                                </div>
                                <div class="p-4">
                                    <div class="flex justify-between items-center mb-2">
                                        <span class="text-sm text-gray-500">Saldo Atual:</span>
                                        <span class="text-lg font-bold {{ $account->current_balance >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                            R$ {{ number_format($account->current_balance, 2, ',', '.') }}
                                        </span>
                                    </div>
                                    <div class="flex justify-between items-center">
                                        <span class="text-xs text-gray-500">Saldo Inicial:</span>
                                        <span class="text-sm">
                                            R$ {{ number_format($account->initial_balance, 2, ',', '.') }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @else
                    <div class="text-center p-6 bg-gray-50 rounded-lg">
                        <div class="text-gray-400 mb-3">
                            <i class="ri-bank-line text-4xl"></i>
                        </div>
                        <p class="text-gray-600 mb-4">Você ainda não possui contas bancárias cadastradas</p>
                        <a href="{{ route('accounts.create') }}" class="inline-flex items-center px-4 py-2 text-sm font-medium bg-blue-600 text-white rounded-md hover:bg-blue-700">
                            <i class="ri-add-line mr-1.5"></i>
                            Adicionar Nova Conta
                        </a>
                    </div>
                @endif
            </div>
        </div>

        <!-- Seção principal com tabs -->
        <div class="card shadow-sm border border-gray-200 rounded-xl mb-6" x-data="{ activeTab: 'overview' }">
            <div class="flex justify-between items-center p-4 border-b border-gray-200">
                <div class="flex space-x-4">
                    <button 
                        @click="activeTab = 'overview'" 
                        :class="{ 'text-blue-600 border-b-2 border-blue-600 -mb-px': activeTab === 'overview' }" 
                        class="px-3 py-2 font-medium text-sm focus:outline-none">
                        Visão Geral
                    </button>
                    <button 
                        @click="activeTab = 'transactions'" 
                        :class="{ 'text-blue-600 border-b-2 border-blue-600 -mb-px': activeTab === 'transactions' }" 
                        class="px-3 py-2 font-medium text-sm focus:outline-none">
                        Transações
                    </button>
                    <button 
                        @click="activeTab = 'categories'" 
                        :class="{ 'text-blue-600 border-b-2 border-blue-600 -mb-px': activeTab === 'categories' }" 
                        class="px-3 py-2 font-medium text-sm focus:outline-none">
                        Categorias
                    </button>
    </div>
                <div class="flex items-center space-x-2">
                    <a href="{{ route('transactions.create') }}" class="inline-flex items-center px-3 py-1.5 text-sm font-medium bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50">
                        <i class="ri-add-line mr-1.5"></i>
                        Nova Transação
                    </a>
                </div>
            </div>

            <!-- Tab content -->
            <div>
                <!-- Overview Tab -->
                <div x-show="activeTab === 'overview'" class="p-4">
                    <!-- Visão geral aqui -->
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
                        <!-- Despesas Pendentes -->
                        <div class="card shadow-sm">
                            <div class="p-4 border-b border-gray-100">
                                <h3 class="font-semibold">Despesas Pendentes</h3>
                                <p class="text-sm text-gray-500">Hoje e amanhã</p>
                            </div>
                            <div class="divide-y divide-gray-100">
                                <!-- Despesas hoje -->
                                <div>
                                    <div class="px-4 py-2 bg-gray-50 text-sm font-medium text-gray-700 border-l-4 border-red-500">
                                        Hoje ({{ \Carbon\Carbon::now()->format('d/m') }})
                                    </div>

                                    @forelse ($pendingExpensesToday as $transaction)
                                    <div class="px-4 py-3 flex items-center justify-between">
                                        <div class="flex items-center">
                                            <div class="bg-red-100 rounded-full p-2 text-red-600">
                                                <i class="ri-arrow-down-line"></i>
                                            </div>
                                            <div class="ml-3">
                                                <p class="font-medium line-clamp-1" style="max-width: 180px;">{{ $transaction->description }}</p>
                                                <p class="text-xs text-gray-500">{{ $transaction->category->name }}</p>
                                            </div>
                                        </div>
                                        <div class="flex items-center">
                                            <span class="text-red-600 font-medium mr-3">
                                                R$ {{ number_format($transaction->amount / 100, 2, ',', '.') }}
                                            </span>
                                            <a href="{{ route('transactions.edit', $transaction) }}" class="text-gray-400 hover:text-blue-600">
                                                <i class="ri-edit-line"></i>
                                            </a>
                                        </div>
                                    </div>
                                    @empty
                                    <div class="p-4 text-center text-gray-500">
                                        <i class="ri-check-line mr-1"></i>
                                        Nenhuma despesa pendente para hoje
                                    </div>
                                    @endforelse
                                </div>

                                <!-- Despesas amanhã -->
                                <div>
                                    <div class="px-4 py-2 bg-gray-50 text-sm font-medium text-gray-700 border-l-4 border-yellow-500">
                                        Amanhã ({{ \Carbon\Carbon::tomorrow()->format('d/m') }})
                                    </div>

                                    @forelse ($pendingExpensesTomorrow as $transaction)
                                    <div class="px-4 py-3 flex items-center justify-between">
                                        <div class="flex items-center">
                                            <div class="bg-red-100 rounded-full p-2 text-red-600">
                                                <i class="ri-arrow-down-line"></i>
                                            </div>
                                            <div class="ml-3">
                                                <p class="font-medium line-clamp-1" style="max-width: 180px;">{{ $transaction->description }}</p>
                                                <p class="text-xs text-gray-500">{{ $transaction->category->name }}</p>
                                            </div>
                                        </div>
                                        <div class="flex items-center">
                                            <span class="text-red-600 font-medium mr-3">
                                                R$ {{ number_format($transaction->amount / 100, 2, ',', '.') }}
                                            </span>
                                            <a href="{{ route('transactions.edit', $transaction) }}" class="text-gray-400 hover:text-blue-600">
                                                <i class="ri-edit-line"></i>
                                            </a>
                                        </div>
                                    </div>
                                    @empty
                                    <div class="p-4 text-center text-gray-500">
                                        <i class="ri-check-line mr-1"></i>
                                        Nenhuma despesa pendente para amanhã
                                    </div>
                                    @endforelse
                                </div>
                            </div>
                        </div>

                        <!-- Receitas Pendentes -->
                        <div class="card shadow-sm">
                            <div class="p-4 border-b border-gray-100">
                                <h3 class="font-semibold">Receitas Pendentes</h3>
                                <p class="text-sm text-gray-500">Hoje e amanhã</p>
                            </div>
                            <div class="divide-y divide-gray-100">
                                <!-- Receitas hoje -->
                                <div>
                                    <div class="px-4 py-2 bg-gray-50 text-sm font-medium text-gray-700 border-l-4 border-green-500">
                                        Hoje ({{ \Carbon\Carbon::now()->format('d/m') }})
                                    </div>

                                    @forelse ($pendingIncomesToday as $transaction)
                                    <div class="px-4 py-3 flex items-center justify-between">
                                        <div class="flex items-center">
                                            <div class="bg-green-100 rounded-full p-2 text-green-600">
                                                <i class="ri-arrow-up-line"></i>
                                            </div>
                                            <div class="ml-3">
                                                <p class="font-medium line-clamp-1" style="max-width: 180px;">{{ $transaction->description }}</p>
                                                <p class="text-xs text-gray-500">{{ $transaction->category->name }}</p>
                                            </div>
                                        </div>
                                        <div class="flex items-center">
                                            <span class="text-green-600 font-medium mr-3">
                                                R$ {{ number_format($transaction->amount / 100, 2, ',', '.') }}
                                            </span>
                                            <a href="{{ route('transactions.edit', $transaction) }}" class="text-gray-400 hover:text-blue-600">
                                                <i class="ri-edit-line"></i>
                                            </a>
                                        </div>
                                    </div>
                                    @empty
                                    <div class="p-4 text-center text-gray-500">
                                        <i class="ri-check-line mr-1"></i>
                                        Nenhuma receita pendente para hoje
                                    </div>
                                    @endforelse
                                </div>

                                <!-- Receitas amanhã -->
                                <div>
                                    <div class="px-4 py-2 bg-gray-50 text-sm font-medium text-gray-700 border-l-4 border-yellow-500">
                                        Amanhã ({{ \Carbon\Carbon::tomorrow()->format('d/m') }})
                                    </div>

                                    @forelse ($pendingIncomesTomorrow as $transaction)
                                    <div class="px-4 py-3 flex items-center justify-between">
                                        <div class="flex items-center">
                                            <div class="bg-green-100 rounded-full p-2 text-green-600">
                                                <i class="ri-arrow-up-line"></i>
                                            </div>
                                            <div class="ml-3">
                                                <p class="font-medium line-clamp-1" style="max-width: 180px;">{{ $transaction->description }}</p>
                                                <p class="text-xs text-gray-500">{{ $transaction->category->name }}</p>
                                            </div>
                                        </div>
                                        <div class="flex items-center">
                                            <span class="text-green-600 font-medium mr-3">
                                                R$ {{ number_format($transaction->amount / 100, 2, ',', '.') }}
                                            </span>
                                            <a href="{{ route('transactions.edit', $transaction) }}" class="text-gray-400 hover:text-blue-600">
                                                <i class="ri-edit-line"></i>
                                            </a>
                                        </div>
                                    </div>
                                    @empty
                                    <div class="p-4 text-center text-gray-500">
                                        <i class="ri-check-line mr-1"></i>
                                        Nenhuma receita pendente para amanhã
                                    </div>
                                    @endforelse
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Transactions Tab -->
                <div x-show="activeTab === 'transactions'" class="p-4">
                    <div class="card shadow-sm">
                        <div class="p-4 border-b border-gray-100">
                            <h3 class="font-semibold">Transações Recentes</h3>
                            <p class="text-sm text-gray-500">Últimas 10 transações</p>
                        </div>
                        <div class="divide-y divide-gray-100">
                            @if(isset($recentTransactions) && $recentTransactions->count() > 0)
                                @foreach($recentTransactions as $transaction)
                                <div class="p-4 flex items-center justify-between">
                                    <div class="flex items-center">
                                        <div class="bg-{{ $transaction->type == 'income' ? 'green' : 'red' }}-100 rounded-full p-2 text-{{ $transaction->type == 'income' ? 'green' : 'red' }}-600">
                                            <i class="ri-arrow-{{ $transaction->type == 'income' ? 'up' : 'down' }}-line"></i>
                                        </div>
                                        <div class="ml-3">
                                            <p class="font-medium">{{ $transaction->description }}</p>
                                            <div class="flex text-xs text-gray-500 mt-0.5">
                                                <span>{{ $transaction->category->name }}</span>
                                                <span class="mx-1">•</span>
                                                <span>{{ $transaction->date->format('d/m/Y') }}</span>
                                                <span class="mx-1">•</span>
                                                <span class="text-{{ $transaction->status == 'paid' ? 'green' : 'yellow' }}-600">
                                                    {{ $transaction->status == 'paid' ? 'Pago' : 'Pendente' }}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-{{ $transaction->type == 'income' ? 'green' : 'red' }}-600 font-medium">
                                        {{ $transaction->type == 'income' ? '+' : '-' }}R$ {{ number_format($transaction->amount / 100, 2, ',', '.') }}
                                    </div>
                                </div>
                                @endforeach
                            @else
                                <div class="p-4 text-center text-gray-500">
                                    Não há transações para exibir
                                </div>
                            @endif
                        </div>
                        @if(isset($recentTransactions) && $recentTransactions->count() > 0)
                        <div class="p-3 border-t border-gray-100 bg-gray-50 text-center">
                            <a href="{{ route('transactions.index') }}" class="text-sm text-blue-600 font-medium hover:underline">
                                Ver todas as transações
                            </a>
                        </div>
                        @endif
                    </div>
                </div>

                <!-- Categories Tab -->
                <div x-show="activeTab === 'categories'" class="p-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <!-- Categorias de Despesas -->
                        <div class="card shadow-sm">
                            <div class="p-4 border-b border-gray-100">
                                <h3 class="font-semibold">Categorias de Despesas</h3>
                                <p class="text-sm text-gray-500">Por valor gasto no período</p>
                            </div>
                            <div class="divide-y divide-gray-100">
                                @if(isset($expenseCategories) && $expenseCategories->count() > 0)
                                    @foreach($expenseCategories as $category)
                                    <div class="p-4 flex items-center justify-between">
                                        <div class="flex items-center">
                                            <div class="w-2 h-2 rounded-full bg-red-500 mr-2"></div>
                                            <span>{{ $category->name }}</span>
                                        </div>
                                        <div>
                                            <span class="font-medium">R$ {{ number_format($category->total / 100, 2, ',', '.') }}</span>
                                        </div>
                                    </div>
                                    @endforeach
                                @else
                                    <div class="p-4 text-center text-gray-500">
                                        Não há dados para exibir
                                    </div>
                                @endif
                            </div>
                        </div>

                        <!-- Categorias de Receitas -->
                        <div class="card shadow-sm">
                            <div class="p-4 border-b border-gray-100">
                                <h3 class="font-semibold">Categorias de Receitas</h3>
                                <p class="text-sm text-gray-500">Por valor recebido no período</p>
                            </div>
                            <div class="divide-y divide-gray-100">
                                @if(isset($incomeCategories) && $incomeCategories->count() > 0)
                                    @foreach($incomeCategories as $category)
                                    <div class="p-4 flex items-center justify-between">
                                        <div class="flex items-center">
                                            <div class="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
                                            <span>{{ $category->name }}</span>
                                        </div>
                                        <div>
                                            <span class="font-medium">R$ {{ number_format($category->total / 100, 2, ',', '.') }}</span>
                                        </div>
                                    </div>
                                    @endforeach
                                @else
                                    <div class="p-4 text-center text-gray-500">
                                        Não há dados para exibir
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if(isset($categoryColors))
    <script>
        // Definir cores de categoria para gráficos dinâmicos
        const categoryColors = @json($categoryColors);
    </script>
    @endif
</x-app-layout>