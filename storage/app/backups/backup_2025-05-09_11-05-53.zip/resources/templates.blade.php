<x-app-layout>
    <div class="container mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold text-gray-900">Modelos de Notificação</h1>
            <div class="flex space-x-2">
                <a href="{{ route('settings.notifications.index') }}" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2">
                    Voltar para Configurações
                </a>
                <button type="button" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2" onclick="document.getElementById('modal-new-template').classList.remove('hidden')">
                    Novo Modelo
                </button>
            </div>
        </div>

        @if (session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline">{{ session('success') }}</span>
        </div>
        @endif

        @if (session('error'))
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline">{{ session('error') }}</span>
        </div>
        @endif

        <div class="bg-white shadow rounded-lg overflow-hidden">
            <div class="p-6 bg-gray-50 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">Modelos de Notificação</h2>
                <p class="mt-1 text-sm text-gray-600">
                    Gerencie modelos de notificação para diferentes tipos de mensagens.
                </p>
            </div>

            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Nome
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Tipo
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Última Atualização
                        </th>
                        <th scope="col" class="relative px-6 py-3">
                            <span class="sr-only">Ações</span>
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @forelse($templates ?? [] as $template)
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">{{ $template->name }}</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full {{ $template->type == 'expense' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800' }}">
                                {{ $template->type == 'expense' ? 'Despesa' : 'Receita' }}
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {{ $template->updated_at->format('d/m/Y H:i') }}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button onclick="openEditModal({{ $template->id }})" class="text-indigo-600 hover:text-indigo-900">Editar</button>
                            <button onclick="deleteTemplate({{ $template->id }})" class="ml-2 text-red-600 hover:text-red-900">Excluir</button>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                            Nenhum modelo de notificação encontrado. Clique em "Novo Modelo" para criar.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal para criar novo modelo -->
    <div id="modal-new-template" class="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50 hidden">
        <div class="bg-white rounded-lg p-6 max-w-2xl w-full">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-medium text-gray-900">Novo Modelo de Notificação</h3>
                <button type="button" class="text-gray-400 hover:text-gray-500" onclick="document.getElementById('modal-new-template').classList.add('hidden')">
                    <span class="sr-only">Fechar</span>
                    <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

            <form action="{{ route('settings.notifications.templates.store') }}" method="POST">
                @csrf
                <div class="space-y-4">
                    <div>
                        <label for="name" class="block text-sm font-medium text-gray-700">Nome</label>
                        <input type="text" name="name" id="name" required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    </div>
                    
                    <div>
                        <label for="type" class="block text-sm font-medium text-gray-700">Tipo</label>
                        <select name="type" id="type" required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                            <option value="expense">Despesa</option>
                            <option value="income">Receita</option>
                        </select>
                    </div>
                    
                    <div>
                        <label for="email_subject" class="block text-sm font-medium text-gray-700">Assunto do Email</label>
                        <input type="text" name="email_subject" id="email_subject" required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <p class="mt-1 text-xs text-gray-500">Variáveis disponíveis: {transaction_description}, {due_date}, {amount}, {days_left}</p>
                    </div>
                    
                    <div>
                        <label for="email_content" class="block text-sm font-medium text-gray-700">Conteúdo do Email (HTML)</label>
                        <textarea name="email_content" id="email_content" rows="5" required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"></textarea>
                        <p class="mt-1 text-xs text-gray-500">Variáveis disponíveis: {transaction_description}, {due_date}, {amount}, {days_left}, {transaction_details}</p>
                    </div>
                    
                    <div>
                        <label for="whatsapp_content" class="block text-sm font-medium text-gray-700">Conteúdo WhatsApp (Texto)</label>
                        <textarea name="whatsapp_content" id="whatsapp_content" rows="3" required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"></textarea>
                        <p class="mt-1 text-xs text-gray-500">Variáveis disponíveis: {transaction_description}, {due_date}, {amount}, {days_left}</p>
                    </div>
                    
                    <div>
                        <label for="push_title" class="block text-sm font-medium text-gray-700">Título Notificação Push</label>
                        <input type="text" name="push_title" id="push_title" required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <p class="mt-1 text-xs text-gray-500">Variáveis disponíveis: {days_left}</p>
                    </div>
                    
                    <div>
                        <label for="push_content" class="block text-sm font-medium text-gray-700">Conteúdo Notificação Push</label>
                        <input type="text" name="push_content" id="push_content" required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <p class="mt-1 text-xs text-gray-500">Variáveis disponíveis: {transaction_description}, {due_date}, {amount}</p>
                    </div>
                </div>

                <div class="mt-5 flex justify-end space-x-3">
                    <button type="button" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
                        onclick="document.getElementById('modal-new-template').classList.add('hidden')">
                        Cancelar
                    </button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                        Salvar Modelo
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openEditModal(templateId) {
            // Implementar lógica para abrir modal de edição
            alert('Editar template ' + templateId + ' (Funcionalidade a ser implementada)');
        }
        
        function deleteTemplate(templateId) {
            if (confirm('Tem certeza que deseja excluir este modelo de notificação?')) {
                // Criar um formulário para enviar a requisição DELETE
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '/settings/notifications/templates/' + templateId;
                form.style.display = 'none';
                
                const method = document.createElement('input');
                method.type = 'hidden';
                method.name = '_method';
                method.value = 'DELETE';
                
                const token = document.createElement('input');
                token.type = 'hidden';
                token.name = '_token';
                token.value = '{{ csrf_token() }}';
                
                form.appendChild(method);
                form.appendChild(token);
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</x-app-layout> 