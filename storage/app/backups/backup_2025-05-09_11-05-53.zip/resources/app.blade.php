<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <!-- Desabilitar o cliente Vite para evitar erros de conexão -->
    <script src="{{ asset('js/disable-vite.js') }}"></script>
    
    <!-- Prevenir carregamento de recursos problemáticos -->
    <meta name="vite-dev" content="disabled">
    <meta http-equiv="Content-Security-Policy" content="connect-src 'self' https: data:; default-src 'self' https: 'unsafe-inline' 'unsafe-eval';">
    
    <!-- Preload de recursos importantes -->
    <link rel="preload" href="{{ asset('build/assets/style-BthKUVhI.css') }}" as="style">
    <link rel="preload" href="{{ asset('build/assets/vendor-Bb-BfKkS.js') }}" as="script">
    <link rel="preload" href="{{ asset('build/assets/app-16GRR4ge.js') }}" as="script">
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="Sistema de gestão financeira pessoal" />
    <meta name="keywords" content="finanças, despesas, receitas, controle financeiro">
    <meta name="author" content="Onlifin" />
    <!-- Modified: {{ date('Y-m-d H:i:s') }} -->

    @auth
    <!-- User ID for notifications -->
    <meta name="user-id" content="{{ auth()->id() }}">
    @endauth

    <title>{{ $title ?? config('app.name', 'Onlifin') }}</title>

    <!-- Script para desativar SweetAlert2 - Carregado antes de tudo para interceptar -->
    <script src="{{ asset('js/disable-sweetalert.js') }}"></script>
    
    <!-- HTML5 Shim and Respond.js IE11 support of HTML5 elements and media queries -->
    <!--[if lt IE 11]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Favicon icon -->
    <link rel="icon" href="{{ asset('assets/images/favicon.ico') }}" type="image/x-icon">
    
    <!-- fontawesome icon -->
    <link rel="stylesheet" href="{{ asset('assets/datta-able/fonts/fontawesome/css/fontawesome-all.min.css') }}">
    
    <!-- animation css -->
    <link rel="stylesheet" href="{{ asset('assets/datta-able/plugins/animation/css/animate.min.css') }}">
    
    <!-- notification css -->
    <link rel="stylesheet" href="{{ asset('assets/datta-able/plugins/notification/css/notification.min.css') }}">
    
    <!-- Local Icons (Remix icon) -->
    <link href="{{ asset('assets/css/remixicon.css') }}" rel="stylesheet">
    
    <!-- vendor css -->
    <link rel="stylesheet" href="{{ asset('assets/datta-able/css/style.css') }}">
    
    <!-- Vite resources ou CSS direto -->
    <link rel="stylesheet" href="{{ asset('build/assets/style-BthKUVhI.css') }}">
    
    <!-- Livewire Styles - importante -->
    <style>
        /* Estilos básicos do Livewire em caso de falha do carregamento */
        [wire\:loading], [wire\:loading\.delay], [wire\:loading\.inline-block], [wire\:loading\.inline], [wire\:loading\.block], [wire\:loading\.flex], [wire\:loading\.table], [wire\:loading\.grid], [wire\:loading\.inline-flex] {
            display: none;
        }
        [wire\:loading\.delay\.shortest], [wire\:loading\.delay\.shorter], [wire\:loading\.delay\.short], [wire\:loading\.delay\.long], [wire\:loading\.delay\.longer], [wire\:loading\.delay\.longest] {
            display: none;
        }
        [wire\:offline] {
            display: none;
        }
        [wire\:dirty]:not(textarea):not(input):not(select) {
            display: none;
        }
    </style>
    @livewireStyles
    
    <!-- Fallback para caso o Vite falhe -->
    <script>
        // Verifica se o Vite injetou os scripts
        window.addEventListener('DOMContentLoaded', function() {
            if (!window.Alpine) {
                console.log('Carregando recursos de fallback...');
                // Carrega script de fallback
                var script = document.createElement('script');
                script.src = "{{ asset('js/app-fallback.js') }}";
                document.head.appendChild(script);
            }
        });
    </script>
    
    <!-- Scripts -->
    <script>
        // Definir variáveis globais para evitar erros
        window.livewire = window.livewire || {
            components: new Map(),
            directive: function(name) { return name; },
            hook: function(name, callback) {},
            emit: function(name, ...params) {},
            on: function(name, callback) {}
        };
    </script>
    @livewireScripts
    <script src="{{ asset('build/assets/vendor-Bb-BfKkS.js') }}"></script>
    <script src="{{ asset('build/assets/app-16GRR4ge.js') }}"></script>
    
    <!-- LivewireUI Modal -->
    @livewire('components.modal')

    <!-- Importando Imask via CDN -->
    <script src="https://unpkg.com/imask"></script>

    @stack('styles')
</head>
<body class="">
    <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>
    <!-- [ Pre-loader ] End -->

    <!-- [ navigation menu ] start -->
    <nav class="pcoded-navbar menupos-fixed menu-light">
        <div class="navbar-wrapper">
            <div class="navbar-brand header-logo">
                <a href="{{ route('dashboard') }}" class="b-brand">
                    <div class="b-bg">
                        <i class="feather icon-trending-up"></i>
                    </div>
                    <span class="b-title">{{ config('app.name', 'Onlifin') }}</span>
                </a>
                <a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
            </div>
            <div class="navbar-content scroll-div">
                <ul class="nav pcoded-inner-navbar">
                    <li class="nav-item pcoded-menu-caption">
                        <label>Navegação</label>
                    </li>
                    <li class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                        <a href="{{ route('dashboard') }}" class="nav-link">
                            <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                            <span class="pcoded-mtext">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->routeIs('transactions.*') ? 'active' : '' }}">
                        <a href="{{ route('transactions.index') }}" class="nav-link">
                            <span class="pcoded-micon"><i class="feather icon-layers"></i></span>
                            <span class="pcoded-mtext">Transações</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->routeIs('transactions.income') ? 'active' : '' }}">
                        <a href="{{ route('transactions.income') }}" class="nav-link">
                            <span class="pcoded-micon"><i class="feather icon-arrow-up-circle"></i></span>
                            <span class="pcoded-mtext">Receitas</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->routeIs('transactions.expenses') ? 'active' : '' }}">
                        <a href="{{ route('transactions.expenses') }}" class="nav-link">
                            <span class="pcoded-micon"><i class="feather icon-arrow-down-circle"></i></span>
                            <span class="pcoded-mtext">Despesas</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->routeIs('settings.reports') ? 'active' : '' }}">
                        <a href="{{ route('settings.reports') }}" class="nav-link">
                            <span class="pcoded-micon"><i class="feather icon-bar-chart-2"></i></span>
                            <span class="pcoded-mtext">Relatórios</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->routeIs('accounts.*') ? 'active' : '' }}">
                        <a href="{{ route('accounts.index') }}" class="nav-link">
                            <span class="pcoded-micon"><i class="feather icon-credit-card"></i></span>
                            <span class="pcoded-mtext">Contas</span>
                        </a>
                    </li>
                    <li class="nav-item {{ request()->routeIs('account.balances') ? 'active' : '' }}">
                        <a href="{{ route('account.balances') }}" class="nav-link">
                            <span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span>
                            <span class="pcoded-mtext">Saldos Bancários</span>
                        </a>
                    </li>
                    
                    <li class="nav-item pcoded-menu-caption">
                        <label>Configurações</label>
                    </li>
                    <li class="nav-item pcoded-hasmenu {{ request()->routeIs('settings.*') || request()->routeIs('categories.*') ? 'active pcoded-trigger' : '' }}">
                        <a href="#!" class="nav-link">
                            <span class="pcoded-micon"><i class="feather icon-settings"></i></span>
                            <span class="pcoded-mtext">Configurações</span>
                        </a>
                        <ul class="pcoded-submenu">
                            <li class="{{ request()->routeIs('categories.*') ? 'active' : '' }}">
                                <a href="{{ route('categories.index') }}">Categorias</a>
                            </li>
                            <li class="{{ request()->routeIs('settings.model-keys.*') ? 'active' : '' }}">
                                <a href="{{ route('settings.model-keys.index') }}">Configurações de IA</a>
                            </li>
                            <li class="{{ request()->routeIs('settings.index') ? 'active' : '' }}">
                                <a href="{{ route('settings.index') }}">Configurações gerais</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- [ navigation menu ] end -->

    <!-- [ Header ] start -->
    <header class="navbar pcoded-header navbar-expand-lg navbar-light headerpos-fixed">
        <div class="m-header">
            <a class="mobile-menu" id="mobile-collapse1" href="#!"><span></span></a>
            <a href="{{ route('dashboard') }}" class="b-brand">
                <div class="b-bg">
                    <i class="feather icon-trending-up"></i>
                </div>
                <span class="b-title">{{ config('app.name', 'Onlifin') }}</span>
            </a>
        </div>
        <a class="mobile-menu" id="mobile-header" href="#!">
            <i class="feather icon-more-horizontal"></i>
        </a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li><a href="#!" class="full-screen" onclick="javascript:toggleFullScreen()"><i class="feather icon-maximize"></i></a></li>
                <li class="nav-item">
                    <div class="main-search">
                        <div class="input-group">
                            <input type="text" id="m-search" class="form-control" placeholder="Buscar...">
                            <a href="#!" class="input-group-append search-close">
                                <i class="feather icon-x input-group-text"></i>
                            </a>
                            <span class="input-group-append search-btn btn btn-primary">
                                <i class="feather icon-search input-group-text"></i>
                            </span>
                        </div>
                    </div>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <li>
                    <div class="dropdown">
                        <a class="dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="icon feather icon-bell"></i>
                            <span class="badge bg-danger">
                                0
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end notification">
                            <div class="noti-head">
                                <h6 class="d-inline-block m-b-0">Notificações</h6>
                                <div class="float-end">
                                    <a href="#!" class="m-r-10">marcar como lido</a>
                                    <a href="#!">limpar todas</a>
                                </div>
                            </div>
                            <ul class="noti-body">
                                <li class="p-3 text-center">Nenhuma notificação no momento</li>
                            </ul>
                            <div class="noti-footer">
                                <a href="{{ route('dashboard') }}">mostrar todas</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="dropdown drp-user">
                        <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="icon feather icon-user"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end profile-notification">
                            <div class="pro-head">
                                <img src="{{ auth()->user()->profile_photo_url }}" class="img-radius" alt="Foto de Perfil">
                                <span>{{ auth()->user()->name }}</span>
                                <a href="{{ route('logout') }}" class="dud-logout" title="Logout"
                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class="feather icon-log-out"></i>
                                </a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    @csrf
                                </form>
                            </div>
                            <ul class="pro-body">
                                <li><a href="{{ route('profile.edit') }}" class="dropdown-item"><i class="feather icon-user"></i> Perfil</a></li>
                                <li><a href="{{ route('settings.index') }}" class="dropdown-item"><i class="feather icon-settings"></i> Configurações</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </header>
    <!-- [ Header ] end -->

    <!-- [ Main Content ] start -->
    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">
            <div class="pcoded-content">
                <div class="pcoded-inner-content">
                    <div class="main-body">
                        <div class="page-wrapper">
                            @yield('breadcrumb')
                            
                            <!-- [ Main Content ] start -->
                            <div class="row">
                                <div class="col-sm-12">
                                    @if (isset($header))
                                    <div class="page-header-title mb-4">
                                        <h5 class="m-b-10">{{ $header }}</h5>
                                    </div>
                                    @endif
                                    
                                    @if (session('success'))
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        {{ session('success') }}
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                    @endif
                                    
                                    @if (session('error'))
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        {{ session('error') }}
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                    @endif
                                    
                                    @if ($errors->any())
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <ul class="mb-0">
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                    @endif
                                    
                                    {{ $slot ?? '' }}
                                    @yield('content')
                                </div>
                            </div>
                            <!-- [ Main Content ] end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- [ Main Content ] end -->

    <!-- Required Js -->
    <script src="{{ asset('assets/datta-able/js/vendor-all.min.js') }}"></script>
    <script src="{{ asset('assets/datta-able/plugins/bootstrap/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('assets/datta-able/js/pcoded.min.js') }}"></script>

    <!-- Carregando scripts manualmente se necessário -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Carrega o vendor-all.min.js se não existir
            if (typeof jQuery === 'undefined') {
                console.log('jQuery não detectado, carregando manualmente...');
                var script = document.createElement('script');
                script.src = "{{ asset('assets/datta-able/js/vendor-all.min.js') }}";
                document.body.appendChild(script);
            }
        });
    </script>

    @stack('scripts')
</body>
</html> 