<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\Category;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use DateTime;
use SimpleXMLElement;
use App\Services\AIConfigService;
use Illuminate\Support\Facades\Cache;

class StatementImportController extends Controller
{
    /**
     * Mostra o formulário de upload de extratos
     */
    public function index()
    {
        $accounts = Account::where('active', true)
            ->where('user_id', auth()->id())
            ->orderBy('name')
            ->get();
            
        // Verifica se a IA está configurada
        $aiConfigService = new AIConfigService();
        $aiConfig = $aiConfigService->getAIConfig();
        $aiConfigured = false;
        
        // Verificar ReplicateSetting
        if (class_exists('\App\Models\ReplicateSetting')) {
            $settings = \App\Models\ReplicateSetting::getActive();
            $aiConfigured = $settings && $settings->isConfigured();
            
            Log::info('Verificação de configuração da IA no index', [
                'has_settings' => !empty($settings),
                'is_active' => $settings ? $settings->is_active : false,
                'has_api_token' => $settings ? !empty($settings->api_token) : false,
                'has_model' => $settings ? !empty($settings->model_version) : false,
                'has_provider' => $settings ? !empty($settings->provider) : false,
                'is_configured' => $aiConfigured
            ]);
        }
            
        return view('transactions.import', compact('accounts', 'aiConfig', 'aiConfigured'));
    }

    /**
     * Processa o upload do extrato
     */
    public function upload(Request $request)
    {
        $request->validate([
            'statement_file' => 'required|file|max:10240', // Removido mimes para validar apenas como arquivo
            'account_id' => 'required|exists:accounts,id',
            'use_ai' => 'nullable|boolean'
        ]);
        
        // Verificar se a IA está configurada
        $aiConfigService = new AIConfigService();
        $aiConfigured = $aiConfigService->isAIConfigured();
        
        // Se a IA não estiver configurada e o usuário tentar usar, exibe erro
        if ($request->boolean('use_ai') && !$aiConfigured) {
            return redirect()->back()->withErrors([
                'use_ai' => 'Não há IA configurada no sistema. Por favor, configure a API e o modelo nas configurações.'
            ])->withInput();
        }

        // Validação personalizada para verificar a extensão do arquivo
        $file = $request->file('statement_file');
        $extension = strtolower($file->getClientOriginalExtension());
        $allowedExtensions = ['pdf', 'csv', 'ofx', 'qif', 'xls', 'xlsx', 'qfx', 'txt'];
        
        if (!in_array($extension, $allowedExtensions)) {
            return redirect()->back()->withErrors([
                'statement_file' => 'O arquivo deve ser um dos seguintes formatos: PDF, CSV, OFX, QIF, QFX, XLS, XLSX ou TXT'
            ])->withInput();
        }

        // Se o uso de IA estiver habilitado e for um formato compatível
        $aiCompatibleFormats = ['pdf', 'csv', 'txt'];
        if ($request->boolean('use_ai') && in_array($extension, $aiCompatibleFormats)) {
            try {
                // Processar com o serviço de IA unificado
                $aiConfig = $aiConfigService->getAIConfig();
                $modelName = $aiConfig['model_name'];
                
                Log::info('Processando arquivo com modelo de IA: ' . $modelName);
                
                // Processar o documento diretamente com o serviço de IA
                $extractedData = $aiConfigService->processDocument($file->path());
                
                // Processa os dados extraídos da IA
                $processedData = $this->processDocumentAiData($extractedData);
                
                // Redireciona para a página de mapeamento com os dados processados
                return redirect()->route('transactions.mapping', [
                    'account_id' => $request->account_id,
                    'ai_data' => json_encode($processedData),
                    'ai_model' => $modelName
                ]);
            } catch (\Exception $e) {
                Log::error('Erro ao processar arquivo com IA (' . ($primaryAI ?? 'desconhecida') . '): ' . $e->getMessage());
                return redirect()->back()->withErrors([
                    'statement_file' => 'Erro ao processar o arquivo com IA: ' . $e->getMessage()
                ])->withInput();
            }
        }

        // Verifica se a conta pertence ao usuário autenticado
        $account = Account::findOrFail($request->account_id);
        if ($account->user_id !== auth()->id()) {
            abort(403, 'Você não tem permissão para acessar esta conta.');
        }

        // Armazena o arquivo
        $path = $file->store('statement_imports/' . auth()->id(), 'local');
        
        // IA é utilizada por padrão, a menos que o usuário explicitamente desative
        $useAI = !$request->has('disable_ai');
        
        // Verifica se deve usar o controlador fixo
        if ($request->has('use_fixed_controller')) {
            // Redireciona para a página de mapeamento normal, mas com IA ativada
            return redirect()->route('statements.mapping', [
                'path' => $path, 
                'account_id' => $account->id,
                'extension' => $extension,
                'use_ai' => true
            ])->with('success', 'Arquivo carregado com sucesso. Usando análise por IA.');
        } else {
            // Redireciona para a página de mapeamento manual original
            return redirect()->route('statements.mapping', [
                'path' => $path, 
                'account_id' => $account->id,
                'extension' => $extension,
                'use_ai' => $useAI
            ])->with('success', 'Arquivo carregado com sucesso. Por favor, faça o mapeamento das transações.');
        }
    }

    /**
     * Processa os dados extraídos do Document AI
     * @param array $data Dados extraídos do Document AI
     * @return array Dados processados e prontos para mapeamento
     */
    private function processDocumentAiData(array $data): array
    {
        $processedData = [
            'transactions' => [],
            'bank_info' => $data['bank_info'] ?? []
        ];

        foreach ($data['transactions'] ?? [] as $transaction) {
            $processedData['transactions'][] = [
                'date' => $transaction['date'] ?? null,
                'amount' => $this->formatAmount($transaction['amount'] ?? '0'),
                'description' => $transaction['description'] ?? '',
                'category' => $this->suggestCategory($transaction['description'] ?? '')
            ];
        }

        return $processedData;
    }

    /**
     * Mostra a tela de mapeamento de transações
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function showMapping(Request $request)
    {
        $path = $request->path;
        $account_id = $request->account_id;
        $extension = $request->extension;
        
        // IA é sempre ativada por padrão, independente do valor passado pelo usuário
        $use_ai = true;
        $ai_data = $request->ai_data ? json_decode($request->ai_data, true) : null;

        // Carrega a conta
        $account = Account::findOrFail($account_id);
        if ($account->user_id !== auth()->id()) {
            abort(403, 'Você não tem permissão para acessar esta conta.');
        }

        // Carrega as categorias do usuário
        $categories = Category::where('user_id', auth()->id())
            ->orderBy('name')
            ->get()
            ->groupBy('type');

        // Extrai as transações do arquivo baseado no formato
        $extractedTransactions = [];
        try {
            if (in_array($extension, ['ofx', 'qfx'])) {
                $extractedTransactions = $this->extractTransactionsFromOFX($path);
            } elseif ($extension === 'csv') {
                $extractedTransactions = $this->extractTransactionsFromCSV($path);
            }
        } catch (\Exception $e) {
            Log::error('Erro ao extrair transações: ' . $e->getMessage());
            $extractedTransactions = $this->getExampleTransactions();
        }
        
        // Se não há transações, usar exemplos
        if (empty($extractedTransactions)) {
            $extractedTransactions = $this->getExampleTransactions();
        }
        
        // Analisar transações com IA
        $aiAnalysisResult = null;
        if (!empty($extractedTransactions)) {
            Log::info('Iniciando análise de transações com IA', ['count' => count($extractedTransactions)]);
            $aiAnalysisResult = $this->analyzeTransactionsWithAI($extractedTransactions);
            
            // Se a análise por IA falhar, usar resposta simulada
            if (empty($aiAnalysisResult)) {
                Log::warning('Análise por IA falhou, usando resposta simulada');
                $aiAnalysisResult = $this->getMockAIResponse($extractedTransactions);
            }
        }

        return view('transactions.mapping', compact(
            'path',
            'account',
            'extension',
            'use_ai',
            'ai_data',
            'categories',
            'extractedTransactions',
            'aiAnalysisResult'
        ));
    }

    /**
     * Formata o valor para o padrão do sistema
     * @param string $amount Valor extraído do Document AI
     * @return float Valor formatado
     */
    private function formatAmount(string $amount): float
    {
        // Remove caracteres não numéricos
        $amount = preg_replace('/[^0-9.,-]/', '', $amount);
        // Substitui vírgula por ponto
        $amount = str_replace(',', '.', $amount);
        return (float) $amount;
    }

    /**
     * Sugere uma categoria baseada na descrição da transação
     * @param string $description Descrição da transação
     * @return string Nome da categoria sugerida
     */
    private function suggestCategory(string $description): string
    {
        // Implementar lógica de sugestão de categoria
        // Por enquanto retorna uma categoria genérica
        return 'Despesa Geral';
    }

    /**
     * Retorna transações de exemplo para testes
     */
    private function getExampleTransactions()
    {
        return [
            [
                'date' => '2022-01-01',
                'description' => 'Transação de exemplo 1',
                'amount' => 100.00,
                'type' => 'income'
            ],
            [
                'date' => '2022-01-05',
                'description' => 'Transação de exemplo 2',
                'amount' => -50.00,
                'type' => 'expense'
            ],
            [
                'date' => '2022-01-10',
                'description' => 'Transação de exemplo 3',
                'amount' => 200.00,
                'type' => 'income'
            ]
        ];
    }

    /**
     * Extrai transações de um arquivo CSV
     */
    private function extractTransactionsFromCSV($path)
    {
        $content = Storage::get($path);
        $lines = explode("\n", $content);
        $transactions = [];
        
        // Remove a primeira linha se for um cabeçalho (assumimos que é)
        if (count($lines) > 1) {
            array_shift($lines);
        }
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            
            // Divide a linha por vírgula ou ponto e vírgula
            $data = str_getcsv($line, ',');
            if (count($data) < 3) {
                $data = str_getcsv($line, ';');
            }
            
            // Se ainda não temos pelo menos 3 colunas, pula esta linha
            if (count($data) < 3) continue;
            
            // Tenta adivinhar qual coluna é o quê baseado em padrões comuns
            $dateIndex = $this->findDateColumn($data);
            $amountIndex = $this->findAmountColumn($data);
            $descriptionIndex = $this->findDescriptionColumn($data, $dateIndex, $amountIndex);
            
            if ($dateIndex !== false && $amountIndex !== false && $descriptionIndex !== false) {
                $date = $this->parseDate($data[$dateIndex]);
                $amount = $this->parseAmount($data[$amountIndex]);
                $description = trim($data[$descriptionIndex]);
                
                // Determina o tipo
                $type = ($amount >= 0) ? 'income' : 'expense';
                
                $transactions[] = [
                    'date' => $date,
                    'description' => $description,
                    'amount' => abs($amount),
                    'type' => $type
                ];
            }
        }
        
        return $transactions;
    }
    
    /**
     * Tenta encontrar a coluna de data
     */
    private function findDateColumn(array $data)
    {
        foreach ($data as $index => $value) {
            // Verifica se parece uma data
            $value = trim($value);
            if (preg_match('/^\d{2}[\/\.-]\d{2}[\/\.-]\d{2,4}$/', $value) || 
                preg_match('/^\d{4}[\/\.-]\d{2}[\/\.-]\d{2}$/', $value)) {
                return $index;
            }
        }
        return 0; // Assume que a primeira coluna é a data se não conseguir determinar
    }
    
    /**
     * Tenta encontrar a coluna de valor
     */
    private function findAmountColumn(array $data)
    {
        foreach ($data as $index => $value) {
            // Verifica se parece um valor monetário
            $value = trim($value);
            // Remove caracteres de moeda e separadores de milhares
            $valueClean = preg_replace('/[^\d\.,\-\+]/', '', $value);
            if (preg_match('/^[\-\+]?\d+[\.,]?\d*$/', $valueClean)) {
                return $index;
            }
        }
        return count($data) - 1; // Assume que a última coluna é o valor se não conseguir determinar
    }
    
    /**
     * Tenta encontrar a coluna de descrição
     */
    private function findDescriptionColumn(array $data, $dateIndex, $amountIndex)
    {
        // Procura por uma coluna que não seja a data nem o valor e tenha texto
        foreach ($data as $index => $value) {
            if ($index !== $dateIndex && $index !== $amountIndex && !empty(trim($value))) {
                return $index;
            }
        }
        
        // Se não encontrar, usa índice 1 (normalmente é a segunda coluna)
        return 1;
    }
    
    /**
     * Converte várias formas de data para ISO
     */
    private function parseDate($dateStr)
    {
        $dateStr = trim($dateStr);
        
        // Formatos comuns no Brasil: dd/mm/yyyy, dd/mm/yy
        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{2,4})$/', $dateStr, $matches)) {
            $day = $matches[1];
            $month = $matches[2];
            $year = $matches[3];
            
            // Se ano tiver 2 dígitos, adiciona 2000
            if (strlen($year) === 2) {
                $year = '20' . $year;
            }
            
            return "$year-$month-$day";
        }
        
        // Formato ISO: yyyy-mm-dd
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $dateStr)) {
            return $dateStr;
        }
        
        // Outros formatos: tenta converter com DateTime
        try {
            $date = new DateTime($dateStr);
            return $date->format('Y-m-d');
        } catch (\Exception $e) {
            // Se falhar, retorna a data atual
            return date('Y-m-d');
        }
    }
    
    /**
     * Converte string de valor para float
     */
    private function parseAmount($amountStr)
    {
        // Remove caracteres não numéricos, exceto ponto, vírgula, sinal de mais e menos
        $amount = preg_replace('/[^\d\.,\-\+]/', '', $amountStr);
        
        // Formato brasileiro: troca vírgula por ponto
        $amount = str_replace(',', '.', $amount);
        
        // Remove pontos de separação de milhares
        $parts = explode('.', $amount);
        if (count($parts) > 2) {
            $lastPart = array_pop($parts);
            $amount = implode('', $parts) . '.' . $lastPart;
        }
        
        return (float) $amount;
    }
    
    /**
     * Analisa as transações usando IA
     * 
     * @param array $transactions Transações extraídas do extrato
     * @return array Resultado da análise por IA
     */
    private function analyzeTransactionsWithAI($transactions)
    {
        Log::info('🔍 [DIAGNÓSTICO IA] Método analyzeTransactionsWithAI INICIADO', [
            'total_transacoes' => count($transactions),
            'usuario_id' => auth()->id(),
            'memory_usage' => round(memory_get_usage() / 1024 / 1024, 2) . ' MB',
            'exemplo_transacao' => json_encode($transactions[0] ?? null)
        ]);

        try {
            // Carregar todas as configurações ativas e ordenadas por prioridade
            $allConfigs = $this->loadAllActiveConfigurations();
            
            if (empty($allConfigs)) {
                Log::error('❌ [DIAGNÓSTICO IA] Nenhuma configuração de IA ativa encontrada');
                throw new \Exception('Nenhuma configuração de IA ativa encontrada. Configure pelo menos um provedor em Settings > Model Keys.');
            }
            
            // Usar a primeira configuração (maior prioridade) como principal
            $aiConfig = (object)$allConfigs[0];
            
            Log::info('✅ [DIAGNÓSTICO IA] Configuração prioritária selecionada', [
                'provider' => $aiConfig->provider,
                'model' => $aiConfig->model,
                'api_token_length' => strlen($aiConfig->api_token),
                'api_token_start' => substr($aiConfig->api_token, 0, 6) . '...',
                'total_configs' => count($allConfigs)
            ]);

            Log::info('🤖 INICIANDO ANÁLISE COM IA', [
                'total_transacoes' => count($transactions),
                'usuario_id' => auth()->id(),
                'exemplo_transacao' => json_encode($transactions[0] ?? null)
            ]);

            Log::info('🔍 Usando provedor IA prioritário: ' . $aiConfig->provider);
            
            // Roteamento baseado no provedor prioritário
            $processedTransactions = [];
            
            Log::info('🧪 [DEBUG PROVIDER] Antes do switch', [
                'provider' => $aiConfig->provider,
                'provider_type' => gettype($aiConfig->provider),
                'provider_length' => strlen($aiConfig->provider),
                'hex_value' => bin2hex($aiConfig->provider),
                'comparisons' => [
                    'is_google' => $aiConfig->provider === 'google',
                    'is_gemini' => $aiConfig->provider === 'gemini',
                    'is_empty' => empty($aiConfig->provider)
                ]
            ]);
            
            switch ($aiConfig->provider) {
                case 'google':
                    Log::info('✅ [DEBUG PROVIDER] Caso google encontrado');
                    // fall through
                case 'gemini':
                    Log::info('✅ [DEBUG PROVIDER] Caso gemini encontrado');
                    try {
                        // Processar em lotes
                        $batchSize = 8;
                        $batches = array_chunk($transactions, $batchSize);
                        $totalBatches = count($batches);
                        
                        Log::info('🔄 Processando análise em ' . $totalBatches . ' lotes de até ' . $batchSize . ' transações');
                        
                        foreach ($batches as $index => $batch) {
                            $currentBatch = $index + 1;
                            Log::info('🔍 Processando lote ' . $currentBatch . ' de ' . $totalBatches . ' (' . count($batch) . ' transações, índices ' . ($index * $batchSize) . ' a ' . (($index + 1) * $batchSize - 1) . ')');
                            
                            try {
                                $result = $this->processBatchWithAI($batch, $aiConfig->model, $aiConfig->api_token, $aiConfig->provider);
                                if ($result) {
                                    $processedTransactions = array_merge($processedTransactions, $result);
                                    Log::info('✅ Lote ' . $currentBatch . ' processado com sucesso');
                                } else {
                                    Log::warning('⚠️ Resposta do ' . $aiConfig->provider . ' não contém dados válidos para o lote ' . $currentBatch);
                                    
                                    // Se o provedor principal falhou, tentar com todos os provedores disponíveis
                                    Log::info('🔄 Tentando processar com provedores alternativos...');
                                    return $this->tryAnalysisWithAllAvailableProviders($transactions);
                                }
                            } catch (\Exception $e) {
                                Log::error('❌ Erro ao processar lote ' . $currentBatch . ': ' . $e->getMessage());
                                
                                // Se o provedor principal falhou, tentar com todos os provedores disponíveis
                                Log::info('🔄 Tentando processar com provedores alternativos após erro...');
                                return $this->tryAnalysisWithAllAvailableProviders($transactions);
                            }
                        }
                    } catch (\Exception $e) {
                        Log::error('❌ Erro ao processar lotes com ' . $aiConfig->provider . ': ' . $e->getMessage());
                        
                        // Se o provedor principal falhou completamente, tentar com todos os provedores disponíveis
                        Log::info('🔄 Tentando processar com provedores alternativos após erro completo...');
                        return $this->tryAnalysisWithAllAvailableProviders($transactions);
                    }
                    break;
                    
                case 'openai':
                    Log::info('✅ [DEBUG PROVIDER] Caso OpenAI encontrado');
                    try {
                        // Processar com OpenAI
                        $aiService = new \App\Services\AIService('openai', $aiConfig->model, $aiConfig->api_token);
                        
                        // Preparar prompt para OpenAI
                        $prompt = $this->prepareUserPrompt($transactions);
                        
                        try {
                            $response = $aiService->analyze($prompt);
                            $processedData = $this->extractOpenRouterJsonOutput($response);
                            
                            if ($processedData) {
                                $processedTransactions = $processedData;
                                Log::info('✅ Análise com OpenAI processada com sucesso');
                            } else {
                                Log::warning('⚠️ Resposta da OpenAI não contém dados válidos');
                                
                                // Se OpenAI falhou, tentar com todos os provedores disponíveis
                                Log::info('🔄 Tentando processar com provedores alternativos...');
                                return $this->tryAnalysisWithAllAvailableProviders($transactions);
                            }
                        } catch (\Exception $e) {
                            Log::error('❌ Erro ao processar com OpenAI: ' . $e->getMessage());
                            
                            // Se OpenAI falhou, tentar com todos os provedores disponíveis
                            Log::info('🔄 Tentando processar com provedores alternativos após erro...');
                            return $this->tryAnalysisWithAllAvailableProviders($transactions);
                        }
                    } catch (\Exception $e) {
                        Log::error('❌ Erro ao inicializar serviço OpenAI: ' . $e->getMessage());
                        
                        // Se OpenAI falhou completamente, tentar com todos os provedores disponíveis
                        Log::info('🔄 Tentando processar com provedores alternativos após erro completo...');
                        return $this->tryAnalysisWithAllAvailableProviders($transactions);
                    }
                    break;
                    
                case 'anthropic':
                    Log::info('✅ [DEBUG PROVIDER] Caso Anthropic encontrado');
                    try {
                        // Processar com Anthropic
                        $aiService = new \App\Services\AIService('anthropic', $aiConfig->model, $aiConfig->api_token);
                        
                        // Preparar prompt para Anthropic
                        $prompt = $this->prepareUserPrompt($transactions);
                        
                        try {
                            $response = $aiService->analyze($prompt);
                            $processedData = $this->extractOpenRouterJsonOutput($response);
                            
                            if ($processedData) {
                                $processedTransactions = $processedData;
                                Log::info('✅ Análise com Anthropic processada com sucesso');
                            } else {
                                Log::warning('⚠️ Resposta da Anthropic não contém dados válidos');
                                
                                // Se Anthropic falhou, tentar com todos os provedores disponíveis
                                Log::info('🔄 Tentando processar com provedores alternativos...');
                                return $this->tryAnalysisWithAllAvailableProviders($transactions);
                            }
                        } catch (\Exception $e) {
                            Log::error('❌ Erro ao processar com Anthropic: ' . $e->getMessage());
                            
                            // Se Anthropic falhou, tentar com todos os provedores disponíveis
                            Log::info('🔄 Tentando processar com provedores alternativos após erro...');
                            return $this->tryAnalysisWithAllAvailableProviders($transactions);
                        }
                    } catch (\Exception $e) {
                        Log::error('❌ Erro ao inicializar serviço Anthropic: ' . $e->getMessage());
                        
                        // Se Anthropic falhou completamente, tentar com todos os provedores disponíveis
                        Log::info('🔄 Tentando processar com provedores alternativos após erro completo...');
                        return $this->tryAnalysisWithAllAvailableProviders($transactions);
                    }
                    break;
                    
                case 'openrouter':
                    Log::info('✅ [DEBUG PROVIDER] Caso OpenRouter encontrado');
                    try {
                        // Usar o método processBatchesWithMultipleAIs que já implementa a lógica para o OpenRouter
                        $processedTransactions = $this->processBatchesWithMultipleAIs($transactions);
                        Log::info('✅ Análise com OpenRouter processada com sucesso');
                    } catch (\Exception $e) {
                        Log::error('❌ Erro ao processar com OpenRouter: ' . $e->getMessage());
                        
                        // Se OpenRouter falhou, tentar com todos os provedores disponíveis
                        Log::info('🔄 Tentando processar com provedores alternativos após erro...');
                        return $this->tryAnalysisWithAllAvailableProviders($transactions);
                    }
                    break;
                    
                default:
                    // Tentar utilizar o AIService como última tentativa
                    Log::warning('⚠️ Provedor desconhecido ("' . $aiConfig->provider . '"). Tentando usar AIService genérico...');
                    try {
                        $aiService = new \App\Services\AIService($aiConfig->provider, $aiConfig->model, $aiConfig->api_token);
                        
                        // Preparar prompt genérico
                        $prompt = $this->prepareUserPrompt($transactions);
                        
                        try {
                            $response = $aiService->analyze($prompt);
                            $processedData = $this->extractOpenRouterJsonOutput($response);
                            
                            if ($processedData) {
                                $processedTransactions = $processedData;
                                Log::info('✅ Análise com ' . $aiConfig->provider . ' processada com sucesso usando AIService');
                                break;
                            }
                        } catch (\Exception $e) {
                            Log::error('❌ Tentativa com AIService falhou: ' . $e->getMessage());
                        }
                    } catch (\Exception $e) {
                        Log::error('❌ Erro ao inicializar AIService para ' . $aiConfig->provider . ': ' . $e->getMessage());
                    }
                    
                    // Se chegou aqui, o provedor principal falhou completamente
                    // Tentar com todos os provedores disponíveis
                    Log::info('🔄 Tentando processar com provedores alternativos após falha do provedor principal...');
                    return $this->tryAnalysisWithAllAvailableProviders($transactions);
            }

            Log::info('🎉 Análise com ' . $aiConfig->provider . ' concluída com sucesso', [
                'provedor_usado' => $aiConfig->provider,
                'total_transacoes_analisadas' => count($processedTransactions),
                'exemplo_resultado' => json_encode($processedTransactions[0] ?? null)
            ]);

            return $processedTransactions;
        } catch (\Exception $e) {
            // Se houve qualquer erro não tratado, usar o fallback
            Log::error('❌ Erro não tratado na análise de transações: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            
            // Última tentativa: usar fallback inteligente
            return $this->getMockAIResponse($transactions);
        }
    }

    private function processBatchesWithMultipleAIs($transactions)
    {
        $maxTimeout = 300; // 5 minutos de timeout global
        $startTime = time();
        $processedTransactions = [];
        $batchSize = 8;
        $batches = array_chunk($transactions, $batchSize);
        $totalBatches = count($batches);
        $currentBatch = 0;

        // Lista de modelos disponíveis para distribuição
        $availableModels = [
            'google/gemini-2.0-flash-exp:free',
            'moonshot/moonlight-16b-a3b-instruct:free',
            'deepseek/r1-distill-llama-70b:free',
            'google/gemma-2-9b:free',
            'allenai/molmo-7b-d:free',
            'huggingface/zephyr-7b:free'
        ];

        // Inicializa estatísticas dos modelos
        $modelStats = [];
        foreach ($availableModels as $model) {
            $modelStats[$model] = [
                'success_count' => 0,
                'failure_count' => 0,
                'last_used' => 0,
                'rate_limit_hit_at' => 0
            ];
        }

        // Carrega o cache de rate limits
        $rateLimitCache = Cache::get('ai_model_rate_limits', []);
        
        // Filtra modelos que estão em rate limit
        $availableModels = array_filter($availableModels, function($model) use ($rateLimitCache) {
            if (isset($rateLimitCache[$model])) {
                $timeSinceRateLimit = time() - $rateLimitCache[$model];
                // Se passou menos de 24 horas desde o rate limit, remove o modelo
                if ($timeSinceRateLimit < 86400) {
                    Log::warning("Modelo {$model} ainda está em rate limit. Tempo restante: " . 
                        round((86400 - $timeSinceRateLimit) / 3600, 2) . " horas");
                    return false;
                }
                // Se passou 24 horas, remove do cache
                Cache::forget("ai_model_rate_limits.{$model}");
            }
            return true;
        });

        if (empty($availableModels)) {
            Log::error("Todos os modelos estão em rate limit. Usando fallback para todas as transações.");
            return $this->generateIntelligentFallback($transactions);
        }

        foreach ($batches as $batch) {
            $currentBatch++;
            $triedModels = [];
            $maxRetries = 3;
            $retryCount = 0;
            $success = false;

            while ($retryCount < $maxRetries && !$success) {
                $retryCount++;
                $model = $this->selectBestModel($modelStats, $availableModels, $triedModels);

                if (!$model) {
                    Log::error("❌ Todos os modelos disponíveis falharam para o lote {$currentBatch}");
                    break;
                }

                try {
                    Log::info("🔍 Processando lote {$currentBatch} de {$totalBatches} ({$batchSize} transações)");
                    $result = $this->processBatchWithAI($batch, $model);
                    
                    if ($result) {
                        $processedTransactions = array_merge($processedTransactions, $result);
                        $modelStats[$model]['success_count']++;
                        $modelStats[$model]['last_used'] = time();
                        $success = true;
                        Log::info("✅ Lote {$currentBatch} processado com sucesso");
                        Log::info("⏱️ Lote {$currentBatch} processado em " . (time() - $startTime) . "s");
                    } else {
                        throw new \Exception("Resposta inválida do modelo");
                    }
                } catch (\Exception $e) {
                    $modelStats[$model]['failure_count']++;
                    $triedModels[] = $model;

                    if (strpos($e->getMessage(), 'Rate limit') !== false) {
                        Log::warning("⚠️ Rate limit para modelo {$model}");
                        // Armazena o timestamp do rate limit no cache por 24 horas
                        Cache::put("ai_model_rate_limits.{$model}", time(), 86400);
                        // Remove o modelo da lista de disponíveis
                        $availableModels = array_diff($availableModels, [$model]);
                        
                        if (empty($availableModels)) {
                            Log::error("❌ Todos os modelos estão em rate limit. Usando fallback para o lote restante.");
                            $processedTransactions = array_merge($processedTransactions, $this->generateIntelligentFallback($batch));
                            break 2;
                        }
                    } elseif (strpos($e->getMessage(), 'is not a valid model ID') !== false) {
                        Log::error("❌ Modelo {$model} não é mais válido. Removendo da lista de modelos disponíveis.");
                        // Remove o modelo inválido da lista de disponíveis
                        $availableModels = array_diff($availableModels, [$model]);
                        // Armazena no cache para evitar tentativas futuras
                        Cache::put("ai_model_invalid.{$model}", true, 86400 * 7); // Cache por 7 dias
                        
                        if (empty($availableModels)) {
                            Log::error("❌ Todos os modelos estão inválidos. Usando fallback para o lote restante.");
                            $processedTransactions = array_merge($processedTransactions, $this->generateIntelligentFallback($batch));
                            break 2;
                        }
                    } else {
                        Log::error("❌ Erro com modelo {$model}: " . $e->getMessage());
                    }

                    if ($retryCount < $maxRetries) {
                        $delay = pow(2, $retryCount); // Backoff exponencial
                        Log::info("🔄 Tentativa {$retryCount} de {$maxRetries}. Aguardando {$delay}s antes da próxima tentativa...");
                        sleep($delay);
                    }
                }
            }

            if (!$success) {
                Log::error("❌ Falha ao processar lote {$currentBatch} após {$maxRetries} tentativas. Usando fallback.");
                $processedTransactions = array_merge($processedTransactions, $this->generateIntelligentFallback($batch));
            }

            // Pequena pausa entre lotes para evitar sobrecarga
            usleep(500000); // 0.5 segundos

            // Verifica timeout global
            if (time() - $startTime > $maxTimeout) {
                Log::error("❌ Timeout global atingido após {$maxTimeout}s");
                break;
            }
        }

        return $processedTransactions;
    }

    private function selectBestModel($modelStats, $availableModels, $excludeModels = [])
    {
        $bestScore = -1;
        $bestModelIndex = 0;
        
        foreach ($availableModels as $index => $model) {
            // Pular modelos excluídos
            if (in_array($model, $excludeModels)) {
                continue;
            }
            
            $stats = $modelStats[$model];
            $successRate = $stats['success_count'] / max(1, $stats['success_count'] + $stats['failure_count']);
            $timeSinceLastUse = time() - $stats['last_used'];
            
            // Score baseado em sucesso e tempo desde último uso
            $score = ($successRate * 0.7) + (min(1, $timeSinceLastUse / 60) * 0.3);
            
            if ($score > $bestScore) {
                $bestScore = $score;
                $bestModelIndex = $index;
            }
        }
        
        return $bestModelIndex;
    }

    private function processBatchWithAI($batch, $model, $apiToken = null, $provider = 'google')
    {
        try {
            $prompt = $this->prepareUserPrompt($batch);
            
            // Se não forneceu API token explicitamente, tenta buscar do banco de dados
            if (!$apiToken) {
                $config = \App\Models\ModelApiKey::where('model', $model)
                    ->where('is_active', true)
                    ->first();
                    
                if ($config) {
                    $apiToken = $config->api_token;
                    $provider = $config->provider;
                } else {
                    throw new \Exception("Configuração não encontrada para o modelo {$model}");
                }
            }
            
            Log::info('Enviando requisição para ' . ucfirst($provider) . ' AI', [
                'provider' => $provider,
                'model' => $model,
                'tamanho_lote' => count($batch),
                'tamanho_prompt' => strlen($prompt)
            ]);

            // Baseado no provedor, usa o endpoint correto
            switch ($provider) {
                case 'google':
                case 'gemini':
                    return $this->processWithGemini($batch, $model, $apiToken, $prompt);
                
                case 'openai':
                    return $this->processWithOpenAI($batch, $model, $apiToken, $prompt);
                    
                case 'anthropic':
                    return $this->processWithAnthropic($batch, $model, $apiToken, $prompt);
                    
                case 'openrouter':
                    return $this->processWithOpenRouter($batch, $model, $apiToken, $prompt);
                    
                default:
                    // Tentar usar AIService como fallback
                    try {
                        $aiService = new \App\Services\AIService($provider, $model, $apiToken);
                        $response = $aiService->analyze($prompt);
                        $transactions = $this->extractOpenRouterJsonOutput($response);
                        
                        if (empty($transactions)) {
                            Log::warning("Resposta do AIService para {$provider} não contém transações válidas");
                            return null;
                        }
                        
                        return $transactions;
                    } catch (\Exception $e) {
                        Log::error("Erro ao usar AIService para {$provider}: " . $e->getMessage());
                        throw new \Exception("Provedor {$provider} não suportado: " . $e->getMessage());
                    }
            }
            
        } catch (\GuzzleHttp\Exception\ConnectException $e) {
            Log::error('Erro de conexão com a IA', [
                'erro' => $e->getMessage(),
                'provider' => $provider,
                'modelo' => $model
            ]);
            throw new \Exception('Erro de conexão com a IA: ' . $e->getMessage());
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            Log::error('Erro na requisição para a IA', [
                'erro' => $e->getMessage(),
                'provider' => $provider,
                'modelo' => $model
            ]);
            throw new \Exception('Erro na requisição para a IA: ' . $e->getMessage());
        } catch (\Exception $e) {
            Log::error('Erro ao processar lote com IA', [
                'erro' => $e->getMessage(),
                'provider' => $provider,
                'modelo' => $model,
                'tamanho_lote' => count($batch)
            ]);
            throw $e;
        }
    }

    // Métodos específicos para cada provedor
    private function processWithGemini($batch, $model, $apiToken, $prompt)
    {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $apiToken,
            'Content-Type' => 'application/json',
            'HTTP-Referer' => config('app.url'),
            'X-Title' => 'OnliFin'
        ])->post('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent', [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $this->getSystemPrompt()],
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature' => 0.2,
                'maxOutputTokens' => 4000
            ]
        ]);

        if (!$response->successful()) {
            $error = $response->json();
            Log::error('Erro ao chamar API do Google AI', [
                'erro' => $error,
                'status' => $response->status(),
                'modelo' => $model
            ]);

            // Verifica se é um erro de autenticação
            if ($response->status() === 401 || $response->status() === 403) {
                throw new \Exception('Erro de autenticação com a API do Google AI. Verifique a chave de API configurada.');
            }

            throw new \Exception($error['error']['message'] ?? 'Erro desconhecido na API');
        }

        $content = $response->json()['candidates'][0]['content']['parts'][0]['text'] ?? null;
        
        if (!$content) {
            Log::error('Resposta vazia do Google AI', [
                'modelo' => $model,
                'resposta' => $response->json()
            ]);
            throw new \Exception('Resposta vazia do modelo');
        }

        Log::info('Resposta recebida do Google AI', [
            'preview_conteudo' => substr($content, 0, 500) . '...',
            'tamanho_conteudo' => strlen($content),
            'modelo' => $model
        ]);

        $transactions = $this->extractOpenRouterJsonOutput($content);
        
        if (empty($transactions)) {
            Log::warning('Não foi possível extrair transações da resposta, usando fallback inteligente', [
                'preview_conteudo' => substr($content, 0, 500) . '...',
                'modelo' => $model
            ]);
            
            return null;
        }

        return $transactions;
    }

    private function processWithOpenAI($batch, $model, $apiToken, $prompt)
    {
        // Implementação do processamento com OpenAI
        $aiService = new \App\Services\AIService('openai', $model, $apiToken);
        $response = $aiService->analyze($prompt);
        
        // Extrai o JSON da resposta
        $transactions = $this->extractOpenRouterJsonOutput($response);
        
        if (empty($transactions)) {
            Log::warning('Não foi possível extrair transações da resposta OpenAI');
            return null;
        }
        
        return $transactions;
    }

    private function processWithAnthropic($batch, $model, $apiToken, $prompt)
    {
        // Implementação do processamento com Anthropic
        $aiService = new \App\Services\AIService('anthropic', $model, $apiToken);
        $response = $aiService->analyze($prompt);
        
        // Extrai o JSON da resposta
        $transactions = $this->extractOpenRouterJsonOutput($response);
        
        if (empty($transactions)) {
            Log::warning('Não foi possível extrair transações da resposta Anthropic');
            return null;
        }
        
        return $transactions;
    }

    private function processWithOpenRouter($batch, $model, $apiToken, $prompt)
    {
        // Implementação do processamento com OpenRouter
        $aiService = new \App\Services\AIService('openrouter', $model, $apiToken);
        $response = $aiService->analyze($prompt);
        
        // Extrai o JSON da resposta
        $transactions = $this->extractOpenRouterJsonOutput($response);
        
        if (empty($transactions)) {
            Log::warning('Não foi possível extrair transações da resposta OpenRouter');
            return null;
        }
        
        return $transactions;
    }

    private function generateIntelligentFallback($batch)
    {
        $result = [];
        
        foreach ($batch as $index => $transaction) {
            $description = strtolower($transaction['description']);
            $amount = $transaction['amount'];
            $type = $transaction['type'];
            
            // Categorização inteligente baseada em palavras-chave
            $category = $this->determineCategoryFromDescription($description, $type);
            
            $result[] = [
                'id' => $index,
                'type' => $type,
                'category_id' => null,
                'suggested_category' => $category,
                'cliente' => $type === 'income' ? $this->extractClienteFromDescription($description) : null,
                'fornecedor' => $type === 'expense' ? $this->extractFornecedorFromDescription($description) : null,
                'notes' => 'Categorizado automaticamente (fallback)'
            ];
        }
        
        return $result;
    }

    private function determineCategoryFromDescription($description, $type)
    {
        // Lista de palavras-chave para cada categoria
        $categories = [
            'Alimentação' => ['mercado', 'padaria', 'restaurante', 'lanche', 'supermercado', 'feira', 'açougue'],
            'Transporte' => ['uber', 'taxi', 'combustível', 'posto', 'ônibus', 'metro', 'estacionamento'],
            'Moradia' => ['aluguel', 'condomínio', 'luz', 'água', 'gás', 'internet', 'telefone'],
            'Saúde' => ['farmacia', 'drogaria', 'médico', 'hospital', 'plano de saúde', 'dentista'],
            'Educação' => ['escola', 'curso', 'faculdade', 'material escolar', 'livraria'],
            'Lazer' => ['cinema', 'shopping', 'parque', 'viagem', 'hotel', 'passagem'],
            'Salário' => ['salário', 'renda', 'proventos', 'pagamento'],
            'Investimentos' => ['aplicação', 'investimento', 'renda fixa', 'ações', 'fundo'],
            'Impostos' => ['imposto', 'taxa', 'contribuição', 'tributo'],
            'Outros' => []
        ];
        
        // Se for receita, priorizar categorias de receita
        if ($type === 'income') {
            $incomeCategories = ['Salário', 'Investimentos'];
            foreach ($incomeCategories as $category) {
                foreach ($categories[$category] as $keyword) {
                    if (strpos($description, $keyword) !== false) {
                        return $category;
                    }
                }
            }
            return 'Receita Diversa';
        }
        
        // Para despesas, verificar todas as categorias
        foreach ($categories as $category => $keywords) {
            foreach ($keywords as $keyword) {
                if (strpos($description, $keyword) !== false) {
                    return $category;
                }
            }
        }
        
        return 'Despesa Diversa';
    }

    private function extractClienteFromDescription($description)
    {
        // Extrair nome do cliente da descrição
        $parts = explode('-', $description);
        if (count($parts) > 1) {
            return trim($parts[1]);
        }
        return null;
    }

    private function extractFornecedorFromDescription($description)
    {
        // Extrair nome do fornecedor da descrição
        $parts = explode('-', $description);
        if (count($parts) > 1) {
            return trim($parts[1]);
        }
        return null;
    }

    private function prepareUserPrompt($batch)
    {
        $prompt = "Analise as seguintes transações bancárias e categorize-as corretamente:\n\n";
        
        foreach ($batch as $index => $transaction) {
            $prompt .= sprintf(
                "Transação %d:\n" .
                "Data: %s\n" .
                "Descrição: %s\n" .
                "Valor: R$ %.2f\n" .
                "Tipo: %s\n\n",
                $index + 1,
                $transaction['date'],
                $transaction['description'],
                abs($transaction['amount']),
                $transaction['amount'] >= 0 ? 'receita' : 'despesa'
            );
        }
        
        $prompt .= "Por favor, retorne um JSON com as seguintes informações para cada transação:\n" .
                  "- id: número da transação (1, 2, 3, etc)\n" .
                  "- type: 'income' para receitas, 'expense' para despesas\n" .
                  "- category_id: ID da categoria (se conhecida)\n" .
                  "- suggested_category: nome da categoria sugerida (se não houver ID)\n\n" .
                  "Exemplo de formato esperado:\n" .
                  "{\n" .
                  "  \"transactions\": [\n" .
                  "    {\n" .
                  "      \"id\": 1,\n" .
                  "      \"type\": \"expense\",\n" .
                  "      \"category_id\": 123,\n" .
                  "      \"suggested_category\": \"Alimentação\"\n" .
                  "    }\n" .
                  "  ]\n" .
                  "}";
        
        return $prompt;
    }

    private function extractOpenRouterJsonOutput($response)
    {
        try {
            // Registrar resposta bruta para debug
            Log::debug('Resposta bruta do OpenRouter', [
                'output_preview' => substr($response, 0, 500) . '...',
                'output_length' => strlen($response)
            ]);

            // Tentar extrair JSON de diferentes formatos
            $jsonData = null;
            
            // 1. Tentar extrair JSON entre ```json e ```
            if (preg_match('/```json\s*([\s\S]*?)\s*```/', $response, $matches)) {
                $jsonData = $matches[1];
                Log::info('JSON extraído de bloco markdown');
            }
            
            // 2. Tentar extrair JSON entre { e }
            if (!$jsonData && preg_match('/{[\s\S]*}/', $response, $matches)) {
                $jsonData = $matches[0];
                Log::info('JSON extraído de chaves');
            }
            
            // 3. Se não encontrou JSON, tentar usar a resposta inteira
            if (!$jsonData) {
                $jsonData = $response;
                Log::info('Usando resposta inteira como JSON');
            }

            // Limpar o JSON
            $jsonData = trim($jsonData);
            $jsonData = preg_replace('/[\x00-\x1F\x7F]/u', '', $jsonData);
            
            // Corrigir campo raiz se necessário
            $jsonData = str_replace('"transaction":', '"transactions":', $jsonData);
            
            // Registrar JSON limpo
            Log::debug('JSON limpo', [
                'preview' => substr($jsonData, 0, 500) . '...',
                'length' => strlen($jsonData)
            ]);

            // Decodificar JSON
            $data = json_decode($jsonData, true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                Log::error('Erro ao decodificar JSON', [
                    'error' => json_last_error_msg(),
                    'json' => substr($jsonData, 0, 500) . '...'
                ]);
                return null;
            }

            // Verificar se tem o campo transactions
            if (isset($data['transactions'])) {
                Log::info('Encontrado objeto JSON com campo transactions');
                return $data['transactions'];
            }

            // Se não tem transactions, verificar se é um array de transações
            if (is_array($data) && isset($data[0]['id'])) {
                Log::info('Encontrado array de transações');
                return $data;
            }

            // Se não encontrou o formato esperado, tentar extrair transações diretamente
            if (is_array($data)) {
                foreach ($data as $key => $value) {
                    if (is_array($value) && isset($value[0]['id'])) {
                        Log::info('Encontrado array de transações em subcampo: ' . $key);
                        return $value;
                    }
                }
            }

            Log::warning('Formato de resposta inválido', [
                'data' => substr(json_encode($data), 0, 500) . '...'
            ]);
            return null;

        } catch (\Exception $e) {
            Log::error('Erro ao extrair JSON do OpenRouter', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return null;
        }
    }

    private function isValidJson($string) {
        json_decode($string);
        return json_last_error() === JSON_ERROR_NONE;
    }

    private function getSystemPrompt()
    {
        return "Você é um assistente especializado em análise de transações bancárias. " .
               "Sua tarefa é categorizar transações financeiras de forma precisa e consistente. " .
               "Siga estas regras estritamente:\n\n" .
               "1. Analise cuidadosamente a descrição e o valor de cada transação\n" .
               "2. Identifique o tipo correto (receita ou despesa)\n" .
               "3. Sugira categorias específicas e relevantes\n" .
               "4. Use categorias em português\n" .
               "5. Seja consistente na categorização de transações similares\n" .
               "6. Retorne APENAS o objeto JSON no formato especificado\n" .
               "7. Não inclua texto adicional ou formatação markdown\n" .
               "8. Use o campo 'transactions' (plural) como raiz do JSON\n" .
               "9. Mantenha os IDs das transações conforme fornecido\n" .
               "10. Seja preciso e específico nas categorias sugeridas\n\n" .
               "Categorias comuns incluem:\n" .
               "- Alimentação\n" .
               "- Transporte\n" .
               "- Moradia\n" .
               "- Saúde\n" .
               "- Educação\n" .
               "- Lazer\n" .
               "- Salário\n" .
               "- Investimentos\n" .
               "- Impostos\n" .
               "- Outros";
    }

    /**
     * Cria uma resposta mock para quando a análise com IA falha
     * 
     * @param array $transactions Transações originais
     * @return array Resposta simulada no formato esperado
     */
    private function getMockAIResponse($transactions)
    {
        Log::info('⚙️ Gerando resposta simulada para ' . count($transactions) . ' transações');
        $result = [];
        
        foreach ($transactions as $index => $transaction) {
            $description = strtolower($transaction['description'] ?? '');
            $amount = $transaction['amount'] ?? 0;
            $type = ($amount >= 0) ? 'income' : 'expense';
            
            // Determinar categoria baseada em palavras-chave simples
            $category = $this->determineCategoryFromDescription($description, $type);
            
            $result[] = [
                'id' => $index,
                'type' => $type,
                'category_id' => null,
                'suggested_category' => $category,
                'cliente' => $type === 'income' ? $this->extractClienteFromDescription($description) : null,
                'fornecedor' => $type === 'expense' ? $this->extractFornecedorFromDescription($description) : null,
                'notes' => 'Categorizado automaticamente (mock)'
            ];
        }
        
        Log::info('✅ Resposta simulada gerada com sucesso');
        return $result;
    }

    /**
     * Carrega todas as configurações de IA disponíveis
     * @return array Configurações de IA ordenadas por prioridade
     */
    private function loadAllActiveConfigurations()
    {
        try {
            // Buscar todas as configurações ativas
            $configs = \App\Models\ModelApiKey::where('is_active', true)
                ->get();
                
            if ($configs->isEmpty()) {
                Log::warning('Nenhuma configuração de IA ativa encontrada');
                return [];
            }
            
            // Definir prioridade dos provedores (menor número = maior prioridade)
            $providerPriority = [
                'gemini' => 1,
                'google' => 1, // Mesma prioridade que Gemini
                'anthropic' => 2,
                'openai' => 3,
                'openrouter' => 4,
                'deepseek' => 5
            ];
            
            // Converter para array e adicionar um campo de prioridade
            $configsArray = $configs->map(function($config) use ($providerPriority) {
                $priority = $providerPriority[$config->provider] ?? 99; // Alta prioridade para provedores desconhecidos
                return [
                    'id' => $config->id,
                    'provider' => $config->provider,
                    'model' => $config->model,
                    'api_token' => $config->api_token,
                    'priority' => $priority
                ];
            })->toArray();
            
            // Ordenar por prioridade (menor primeiro)
            usort($configsArray, function($a, $b) {
                if ($a['priority'] === $b['priority']) {
                    return 0; // Mesma prioridade
                }
                return ($a['priority'] < $b['priority']) ? -1 : 1;
            });
            
            Log::info('Configurações de IA carregadas e ordenadas por prioridade', [
                'total' => count($configsArray),
                'principais' => array_slice(array_map(function($config) {
                    return $config['provider'] . '/' . $config['model'];
                }, $configsArray), 0, 3)
            ]);
            
            return $configsArray;
        } catch (\Exception $e) {
            Log::error('Erro ao carregar configurações de IA: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Tenta analisar transações usando todas as IAs disponíveis em ordem de prioridade
     * @param array $transactions Transações para analisar
     * @return array Resultado da análise ou resposta simulada em caso de falha
     */
    private function tryAnalysisWithAllAvailableProviders($transactions)
    {
        // Carregar todas as configurações ativas
        $allConfigs = $this->loadAllActiveConfigurations();
        
        if (empty($allConfigs)) {
            Log::warning('Sem configurações de IA ativas. Usando resposta simulada.');
            return $this->getMockAIResponse($transactions);
        }
        
        // Preparar transações em lotes
        $batchSize = 8;
        $batches = array_chunk($transactions, $batchSize);
        $totalBatches = count($batches);
        $processedTransactions = [];
        $successfulProvider = null;
        
        // Para cada configuração, tentar processar todas as transações
        foreach ($allConfigs as $config) {
            Log::info('Tentando processar com ' . $config['provider'] . '/' . $config['model']);
            
            try {
                $allBatchesSuccess = true;
                
                foreach ($batches as $index => $batch) {
                    $currentBatch = $index + 1;
                    Log::info('Processando lote ' . $currentBatch . ' de ' . $totalBatches . ' com ' . $config['provider']);
                    
                    try {
                        $result = $this->processBatchWithAI(
                            $batch, 
                            $config['model'], 
                            $config['api_token'],
                            $config['provider']
                        );
                        
                        if ($result) {
                            $processedTransactions = array_merge($processedTransactions, $result);
                            Log::info('Lote ' . $currentBatch . ' processado com sucesso usando ' . $config['provider']);
                        } else {
                            Log::warning('Resposta de ' . $config['provider'] . ' não contém dados válidos para o lote ' . $currentBatch);
                            $allBatchesSuccess = false;
                            break;
                        }
                    } catch (\Exception $e) {
                        Log::error('Erro ao processar lote ' . $currentBatch . ' com ' . $config['provider'] . ': ' . $e->getMessage());
                        $allBatchesSuccess = false;
                        break;
                    }
                }
                
                // Se todos os lotes foram processados com sucesso, usar este resultado
                if ($allBatchesSuccess) {
                    $successfulProvider = $config['provider'];
                    Log::info('Todas as transações processadas com sucesso usando ' . $config['provider']);
                    return $processedTransactions;
                } else {
                    // Limpar transações processadas parcialmente para tentar outro provedor
                    $processedTransactions = [];
                }
                
            } catch (\Exception $e) {
                Log::error('Falha completa ao tentar ' . $config['provider'] . ': ' . $e->getMessage());
                // Continuar com o próximo provedor
                continue;
            }
        }
        
        // Se chegou aqui, nenhum provedor conseguiu processar todos os lotes
        Log::warning('Nenhum provedor conseguiu processar todas as transações. Usando resposta simulada.');
        return $this->getMockAIResponse($transactions);
    }
}