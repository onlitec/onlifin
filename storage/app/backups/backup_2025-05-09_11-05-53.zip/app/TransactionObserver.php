<?php

namespace App\Observers;

use App\Models\Transaction;
use App\Models\Account;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;

class TransactionObserver
{
    /**
     * Handle the Transaction "created" event.
     */
    public function created(Transaction $transaction): void
    {
        $user = Auth::user();
        $message = "Usuário {$user->name} (ID: {$user->id}) criou uma nova transação: " .
                  "{$transaction->type} de R$ " . number_format($transaction->amount / 100, 2, ',', '.') . 
                  " na categoria {$transaction->category->name} na conta {$transaction->account->name} " .
                  "em {$transaction->date->format('d/m/Y')}";
        
        Log::info($message, [
            'action' => 'create',
            'user_id' => $user->id,
            'transaction_id' => $transaction->id,
            'amount' => $transaction->amount,
            'category' => $transaction->category->name,
            'account' => $transaction->account->name,
            'date' => $transaction->date->format('Y-m-d H:i:s')
        ]);

        // Atualizar saldo da conta se a transação estiver paga
        if ($transaction->status === 'paid') {
            $this->updateAccountBalance($transaction);
        }
    }

    /**
     * Handle the Transaction "updated" event.
     */
    public function updated(Transaction $transaction): void
    {
        $user = Auth::user();
        $message = "Usuário {$user->name} (ID: {$user->id}) atualizou a transação ID: {$transaction->id}";
        
        Log::info($message, [
            'action' => 'update',
            'user_id' => $user->id,
            'transaction_id' => $transaction->id,
            'changes' => $transaction->getChanges(),
            'original' => $transaction->getOriginal()
        ]);

        $originalStatus = $transaction->getOriginal('status');
        $newStatus = $transaction->status;

        $originalAmount = (int) $transaction->getOriginal('amount');
        $newAmount = $transaction->amount;

        $originalAccountId = $transaction->getOriginal('account_id');
        $newAccountId = $transaction->account_id;

        $originalType = $transaction->getOriginal('type');
        $newType = $transaction->type;

        $accountChanged = $originalAccountId != $newAccountId;

        // Reverter efeito original se estava pago
        if ($originalStatus === 'paid') {
            $originalAccount = Account::find($originalAccountId);
            if ($originalAccount) {
                $this->adjustAccountBalance($originalAccount, $originalAmount, $originalType, true); // Reverter
            }
        }

        // Aplicar novo efeito se está pago
        if ($newStatus === 'paid') {
            $newAccount = $accountChanged ? Account::find($newAccountId) : ($originalAccount ?? Account::find($newAccountId));
            if ($newAccount) {
                $this->adjustAccountBalance($newAccount, $newAmount, $newType, false); // Aplicar
            }
        }
    }

    /**
     * Handle the Transaction "deleted" event.
     */
    public function deleted(Transaction $transaction): void
    {
        $user = Auth::user();
        $message = "Usuário {$user->name} (ID: {$user->id}) excluiu a transação ID: {$transaction->id}";
        
        // Capturar informações de categoria e conta de forma segura antes de gravar no log
        $categoryName = $transaction->category ? $transaction->category->name : 'N/A';
        $accountName = $transaction->account ? $transaction->account->name : 'N/A';
        
        Log::info($message, [
            'action' => 'delete',
            'user_id' => $user->id,
            'transaction_id' => $transaction->id,
            'transaction_data' => [
                'type' => $transaction->type,
                'amount' => $transaction->amount,
                'category' => $categoryName,
                'account' => $accountName,
                'date' => $transaction->date->format('Y-m-d H:i:s')
            ]
        ]);

        // Reverter o saldo da conta se a transação estava paga
        if ($transaction->status === 'paid' && $transaction->account) {
            $this->adjustAccountBalance($transaction->account, $transaction->amount, $transaction->type, true); // Reverter
        }
    }

    /**
     * Handle the Transaction "restored" event.
     */
    public function restored(Transaction $transaction): void
    {
        $user = Auth::user();
        $message = "Usuário {$user->name} (ID: {$user->id}) restaurou a transação ID: {$transaction->id}";
        
        Log::info($message, [
            'action' => 'restore',
            'user_id' => $user->id,
            'transaction_id' => $transaction->id
        ]);
    }

    /**
     * Handle the Transaction "force deleted" event.
     */
    public function forceDeleted(Transaction $transaction): void
    {
        $user = Auth::user();
        $message = "Usuário {$user->name} (ID: {$user->id}) excluiu permanentemente a transação ID: {$transaction->id}";
        
        Log::info($message, [
            'action' => 'force_delete',
            'user_id' => $user->id,
            'transaction_id' => $transaction->id
        ]);
    }

    /**
     * Helper method to update account balance based on a transaction.
     */
    protected function updateAccountBalance(Transaction $transaction): void
    {
        $account = $transaction->account;
        if ($account) {
            $this->adjustAccountBalance($account, $transaction->amount, $transaction->type, false); // Aplicar
        }
    }

    /**
     * Helper method to adjust account balance.
     *
     * @param Account $account
     * @param int $amount Amount in cents
     * @param string $type 'income' or 'expense'
     * @param bool $reverse If true, reverses the operation (e.g., for deletion or reverting old state)
     */
    protected function adjustAccountBalance(Account $account, int $amount, string $type, bool $reverse): void
    {
        // Converter amount de centavos para decimal (dividir por 100)
        $amountDecimal = $amount / 100;
        
        if ($type === 'income') {
            $account->current_balance += ($reverse ? -$amountDecimal : $amountDecimal);
        } elseif ($type === 'expense') {
            $account->current_balance -= ($reverse ? -$amountDecimal : $amountDecimal);
        }
        
        $account->save();
        
        // Verificar se a conta tem alguma transação antes de tentar acessar
        $latestTransaction = $account->transactions()->latest()->first();
        $transactionInfo = $latestTransaction ? "devido à transação ID {$latestTransaction->id}" : "via operação manual";
        
        Log::info("Saldo da conta ID {$account->id} atualizado para {$account->current_balance} {$transactionInfo}", [
            'account_id' => $account->id,
            'new_balance' => $account->current_balance,
            'amount_adjusted' => $amountDecimal, // Log o valor já convertido
            'type' => $type,
            'reversed' => $reverse,
            'transaction_id' => $latestTransaction ? $latestTransaction->id : null
        ]);
    }
}
