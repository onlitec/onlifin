<?php

namespace App\Services;

use App\Models\ReplicateSetting;
use App\Models\ModelApiKey;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class AIService
{
    private $settings;
    private $apiToken;
    private $provider;
    private $model;
    private $systemPrompt;

    // Lista de modelos disponíveis
    private const OPENAI_MODELS = [
        'gpt-3.5-turbo' => 'GPT-3.5 Turbo',
        'gpt-4-turbo-preview' => 'GPT-4 Turbo',
        'gpt-4' => 'GPT-4'
    ];

    private const ANTHROPIC_MODELS = [
        'claude-3-opus-20240229' => 'Claude 3 Opus',
        'claude-3-sonnet-20240229' => 'Claude 3 Sonnet'
    ];

    private const GEMINI_MODELS = [
        'gemini-2.0-flash-exp:free' => 'Gemini 2.0 Flash (Free)',
        'gemini-1.5-flash' => 'Gemini 1.5 Flash',
        'gemini-1.5-pro' => 'Gemini 1.5 Pro',
        'gemini-pro' => 'Gemini Pro',
        'gemini-pro-vision' => 'Gemini Pro Vision'
    ];

    private const MICROSOFT_MODELS = [
        'microsoft/phi-4-reasoning:free' => 'Microsoft Phi 4 Reasoning Plus (Free)',
        'microsoft/mai-ds-r1:free' => 'Microsoft MAI DS R1 (Free)'
    ];

    private const QWEN_MODELS = [
        'qwen/qwen3-0.6b-04-28:free' => 'Qwen 3 0.6B (Free)',
        'qwen/qwen3-1.7b:free' => 'Qwen 3 1.7B (Free)',
        'qwen/qwen3-4b:free' => 'Qwen 3 4B (Free)',
        'qwen/qwen3-8b:free' => 'Qwen 3 8B (Free)',
        'qwen/qwen3-14b:free' => 'Qwen 3 14B (Free)',
        'qwen/qwen3-30b-a3b:free' => 'Qwen 3 30B A3B (Free)',
        'qwen/qwen3-32b:free' => 'Qwen 3 32B (Free)',
        'qwen/qwen3-235b-a22b:free' => 'Qwen 3 235B A22B (Free)',
        'qwen/qwen2.5-vl-32b-instruct:free' => 'Qwen 2.5 VL 32B Instruct (Free)'
    ];

    private const OPENGVLAB_MODELS = [
        'opengvlab/internvl3-14b:free' => 'InternVL 3 14B (Free)',
        'opengvlab/internvl3-2b:free' => 'InternVL 3 2B (Free)'
    ];

    private const DEEPSEEK_MODELS = [
        'deepseek/deepseek-prover-v2:free' => 'DeepSeek Prover V2 (Free)',
        'deepseek/deepseek-chat-v3-0324:free' => 'DeepSeek Chat V3 (Free)',
        'deepseek/deepseek-chat:free' => 'DeepSeek Chat (Free)'
    ];

    private const TNGTECH_MODELS = [
        'tngtech/deepseek-r1t-chimera:free' => 'DeepSeek R1T Chimera (Free)'
    ];

    private const THUDM_MODELS = [
        'thudm/glm-z1-9b:free' => 'GLM Z1 9B (Free)',
        'thudm/glm-4-9b:free' => 'GLM 4 9B (Free)',
        'thudm/glm-z1-32b:free' => 'GLM Z1 32B (Free)',
        'thudm/glm-4-32b:free' => 'GLM 4 32B (Free)'
    ];

    private const SHISA_MODELS = [
        'shisa-ai/shisa-v2-llama3.3-70b:free' => 'Shisa V2 Llama 3.3 70B (Free)'
    ];

    private const NVIDIA_MODELS = [
        'nvidia/llama-3.3-nemotron-super-49b-v1:free' => 'Llama 3.3 Nemotron Super 49B V1 (Free)'
    ];

    private const META_MODELS = [
        'meta-llama/llama-4-maverick:free' => 'Llama 4 Maverick (Free)',
        'meta-llama/llama-4-scout:free' => 'Llama 4 Scout (Free)',
        'meta-llama/llama-3.3-70b-instruct:free' => 'Llama 3.3 70B Instruct (Free)'
    ];

    private const MISTRAL_MODELS = [
        'mistralai/mistral-small-3.1-24b-instruct:free' => 'Mistral Small 3.1 24B Instruct (Free)'
    ];

    /**
     * Construtor que suporta três formas de inicialização:
     * 1. Com objeto ReplicateSetting (modo compatibilidade)
     * 2. Com parâmetros provider, model e apiToken fornecidos manualmente
     * 3. Com parâmetros provider e model, buscando a apiToken específica no banco
     */
    public function __construct($providerOrSettings = null, $model = null, $apiToken = null)
    {
        // Modo 1: Compatibilidade com código existente
        if ($providerOrSettings instanceof ReplicateSetting) {
            $this->settings = $providerOrSettings;
            $this->provider = $providerOrSettings->provider;
            $this->apiToken = $providerOrSettings->api_token;
            $this->model = $this->validateModel($providerOrSettings->model_version);
            $this->systemPrompt = $providerOrSettings->system_prompt;
            return;
        }
        
        // Modo 2 e 3: Inicialização manual
        $this->provider = $providerOrSettings ?: config('ai.provider', 'openai');
        $this->model = $model ?: 'gemini-2.0-flash'; // Valor padrão
        $this->apiToken = $apiToken;
        
        // Se não foi fornecida uma API token, tentar buscar uma específica para este modelo
        if (!$this->apiToken) {
            $this->loadModelSpecificToken();
        }
        
        // Se ainda não tiver token, carregar da configuração geral
        if (!$this->apiToken) {
            $this->loadConfig();
        }
    }
    
    /**
     * Carrega a configuração geral do provedor
     */
    private function loadConfig()
    {
        try {
            $settings = ReplicateSetting::where('provider', $this->provider)
                ->where('is_active', true)
                ->first();
                
            if ($settings) {
                $this->settings = $settings;
                $this->apiToken = $settings->api_token;
                if (!$this->model) {
                    $this->model = $this->validateModel($settings->model_version);
                }
                $this->systemPrompt = $settings->system_prompt;
                
                // Log para debug
                Log::info('Prompt do sistema carregado:', [
                    'provider' => $this->provider,
                    'model' => $this->model,
                    'prompt_length' => strlen($this->systemPrompt ?? ''),
                    'prompt_preview' => substr($this->systemPrompt ?? '', 0, 100) . '...'
                ]);
            } else {
                Log::warning("Configuração não encontrada para o provedor {$this->provider}", [
                    'provider' => $this->provider,
                    'model' => $this->model,
                    'has_settings' => false,
                    'reason' => 'No active configuration found in database'
                ]);
            }
        } catch (\Exception $e) {
            Log::error("Erro ao carregar configuração: {$e->getMessage()}");
        }
    }
    
    /**
     * Carrega token específico para o modelo atual
     */
    private function loadModelSpecificToken()
    {
        try {
            $modelKey = ModelApiKey::where('provider', $this->provider)
                ->where('model', $this->model)
                ->where('is_active', true)
                ->first();
                
            if ($modelKey) {
                Log::info("Usando chave API específica para o modelo {$this->model}");
                $this->apiToken = $modelKey->api_token;
                $this->systemPrompt = $modelKey->system_prompt ?: ($this->systemPrompt ?? null);
                return true;
            }
            
            return false;
        } catch (\Exception $e) {
            Log::error("Erro ao carregar chave específica para o modelo: {$e->getMessage()}");
            return false;
        }
    }

    /**
     * Valida e retorna o modelo apropriado
     */
    private function validateModel($model)
    {
        switch ($this->provider) {
            case 'openai':
                if (!isset(self::OPENAI_MODELS[$model])) {
                    Log::warning("Modelo OpenAI '$model' não disponível, usando gpt-3.5-turbo");
                    return 'gpt-3.5-turbo';
                }
                break;
            case 'anthropic':
                if (!isset(self::ANTHROPIC_MODELS[$model])) {
                    Log::warning("Modelo Anthropic '$model' não disponível, usando claude-3-sonnet-20240229");
                    return 'claude-3-sonnet-20240229';
                }
                break;
            case 'gemini':
                if (!isset(self::GEMINI_MODELS[$model])) {
                    Log::warning("Modelo Gemini '$model' não disponível, usando gemini-2.0-flash-exp:free");
                    return 'gemini-2.0-flash-exp:free';
                }
                break;
            case 'microsoft':
                if (!isset(self::MICROSOFT_MODELS[$model])) {
                    Log::warning("Modelo Microsoft '$model' não disponível, usando microsoft/phi-4-reasoning:free");
                    return 'microsoft/phi-4-reasoning:free';
                }
                break;
            case 'qwen':
                if (!isset(self::QWEN_MODELS[$model])) {
                    Log::warning("Modelo Qwen '$model' não disponível, usando qwen/qwen3-14b:free");
                    return 'qwen/qwen3-14b:free';
                }
                break;
            case 'opengvlab':
                if (!isset(self::OPENGVLAB_MODELS[$model])) {
                    Log::warning("Modelo OpenGVLab '$model' não disponível, usando opengvlab/internvl3-14b:free");
                    return 'opengvlab/internvl3-14b:free';
                }
                break;
            case 'deepseek':
                if (!isset(self::DEEPSEEK_MODELS[$model])) {
                    Log::warning("Modelo DeepSeek '$model' não disponível, usando deepseek/deepseek-chat:free");
                    return 'deepseek/deepseek-chat:free';
                }
                break;
            case 'tngtech':
                if (!isset(self::TNGTECH_MODELS[$model])) {
                    Log::warning("Modelo TNG Tech '$model' não disponível, usando tngtech/deepseek-r1t-chimera:free");
                    return 'tngtech/deepseek-r1t-chimera:free';
                }
                break;
            case 'thudm':
                if (!isset(self::THUDM_MODELS[$model])) {
                    Log::warning("Modelo THUDM '$model' não disponível, usando thudm/glm-4-32b:free");
                    return 'thudm/glm-4-32b:free';
                }
                break;
            case 'shisa':
                if (!isset(self::SHISA_MODELS[$model])) {
                    Log::warning("Modelo Shisa '$model' não disponível, usando shisa-ai/shisa-v2-llama3.3-70b:free");
                    return 'shisa-ai/shisa-v2-llama3.3-70b:free';
                }
                break;
            case 'nvidia':
                if (!isset(self::NVIDIA_MODELS[$model])) {
                    Log::warning("Modelo NVIDIA '$model' não disponível, usando nvidia/llama-3.3-nemotron-super-49b-v1:free");
                    return 'nvidia/llama-3.3-nemotron-super-49b-v1:free';
                }
                break;
            case 'meta':
                if (!isset(self::META_MODELS[$model])) {
                    Log::warning("Modelo Meta '$model' não disponível, usando meta-llama/llama-3.3-70b-instruct:free");
                    return 'meta-llama/llama-3.3-70b-instruct:free';
                }
                break;
            case 'mistral':
                if (!isset(self::MISTRAL_MODELS[$model])) {
                    Log::warning("Modelo Mistral '$model' não disponível, usando mistralai/mistral-small-3.1-24b-instruct:free");
                    return 'mistralai/mistral-small-3.1-24b-instruct:free';
                }
                break;
            default:
                Log::warning("Provedor '{$this->provider}' não reconhecido, usando gemini-2.0-flash-exp:free");
                return 'gemini-2.0-flash-exp:free';
        }
        
        return $model;
    }

    /**
     * Testa a conexão com o provedor de IA
     */
    public function test()
    {
        if (!ReplicateSetting::isConfigured() || empty($this->apiToken)) {
            Log::warning("Configuração ausente ou inválida para o provedor {$this->provider}. Não prosseguindo com o teste.", [
                'provider' => $this->provider,
                'has_config' => false,
                'reason' => 'Missing API key or inactive setting'
            ]);
            return ['status' => 'error', 'message' => 'Configuração não encontrada. Verifique as configurações.'];
        }
        // Chamar o método de teste específico com base no provedor
        switch ($this->provider) {
            case 'openai':
                return $this->testOpenAI();
            case 'anthropic':
                return $this->testAnthropic();
            case 'gemini':
                return $this->testGemini();
            case 'grok':
                return $this->testGrok();
            case 'copilot':
                return $this->testCopilot();
            case 'tongyi':
                return $this->testTongyi();
            case 'deepseek':
                return $this->testDeepseek();
            default:
                return ['status' => 'error', 'message' => 'Provedor não suportado.'];
        }
    }

    /**
     * Analisa um texto usando o provedor configurado
     */
    public function analyze($text)
    {
        return match($this->provider) {
            'openai' => $this->analyzeWithOpenAI($text),
            'anthropic' => $this->analyzeWithAnthropic($text),
            'gemini' => $this->analyzeWithGemini($text),
            'grok' => $this->analyzeWithGrok($text),
            'copilot' => $this->analyzeWithCopilot($text),
            'tongyi' => $this->analyzeWithTongyi($text),
            'deepseek' => $this->analyzeWithDeepseek($text),
            default => throw new \Exception('Provedor de IA não suportado')
        };
    }

    /**
     * Testa a conexão com a OpenAI
     */
    private function testOpenAI()
    {
        if (!ReplicateSetting::isConfigured() || empty($this->apiToken)) {
            Log::warning("Configuração ausente ou inválida para o provedor {$this->provider}. Não prosseguindo com o teste.", [
                'provider' => $this->provider,
                'has_config' => false,
                'reason' => 'Missing API key or inactive setting'
            ]);
            return ['status' => 'error', 'message' => 'Configuração não encontrada. Verifique as configurações.'];
        }
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiToken,
                'Content-Type' => 'application/json',
            ])->post('https://api.openai.com/v1/chat/completions', [
                'model' => $this->model,
                'messages' => [
                    ['role' => 'system', 'content' => 'Você é um assistente útil.'],
                    ['role' => 'user', 'content' => 'Teste de conexão']
                ],
                'max_tokens' => 50
            ]);

            if (!$response->successful()) {
                $error = $response->json('error.message') ?? 'Erro desconhecido';
                throw new \Exception('Erro ao testar conexão com OpenAI: ' . $error);
            }

            return true;  // Retorna true para indicar sucesso
        } catch (\Exception $e) {
            Log::error('Erro ao testar conexão com OpenAI: ' . $e->getMessage(), [
                'model' => $this->model
            ]);
            throw $e;  // Repassa o erro para o controller
        }
    }

    /**
     * Testa a conexão com a Anthropic
     */
    private function testAnthropic()
    {
        if (!ReplicateSetting::isConfigured() || empty($this->apiToken)) {
            Log::warning("Configuração ausente ou inválida para o provedor {$this->provider}. Não prosseguindo com o teste.", [
                'provider' => $this->provider,
                'has_config' => false,
                'reason' => 'Missing API key or inactive setting'
            ]);
            return ['status' => 'error', 'message' => 'Configuração não encontrada. Verifique as configurações.'];
        }
        try {
            Log::info('Iniciando teste de conexão com Anthropic', [
                'model' => $this->model
            ]);

            $response = Http::withHeaders([
                'x-api-key' => $this->apiToken,
                'anthropic-version' => '2024-02-15',
                'Content-Type' => 'application/json',
            ])->post('https://api.anthropic.com/v1/messages', [
                'model' => $this->model,
                'max_tokens' => 50,
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => 'Teste de conexão'
                    ]
                ]
            ]);

            Log::info('Resposta da Anthropic', [
                'status' => $response->status(),
                'body' => $response->json()
            ]);

            if (!$response->successful()) {
                $error = $response->json();
                Log::error('Erro detalhado Anthropic:', [
                    'status' => $response->status(),
                    'error' => $error,
                    'headers' => $response->headers(),
                    'model' => $this->model
                ]);
                
                // Se o erro for relacionado ao modelo, tente com claude-3-sonnet
                if (isset($error['error']['type']) && $error['error']['type'] === 'authentication_error') {
                    throw new \Exception('Erro de autenticação: Verifique se sua chave API está correta');
                }
                
                if (isset($error['error']['message'])) {
                    throw new \Exception($error['error']['message']);
                }
                
                throw new \Exception('Erro desconhecido ao conectar com Anthropic');
            }

            return true;  // Retorna true para indicar sucesso
        } catch (\Exception $e) {
            Log::error('Exceção ao conectar com Anthropic:', [
                'error' => $e->getMessage(),
                'model' => $this->model,
                'trace' => $e->getTraceAsString()
            ]);
            throw $e;
        }
    }

    /**
     * Testa a conexão com o Google Gemini
     * 
     * Agora utilizamos a classe GeminiTest que já foi testada e funciona corretamente
     */
    private function testGemini()
    {
        if (empty($this->apiToken)) {
            Log::warning("Chave API ausente para o provedor {$this->provider}. Não prosseguindo com o teste.", [
                'provider' => $this->provider,
                'has_config' => false,
                'reason' => 'Missing API key'
            ]);
            return ['status' => 'error', 'message' => 'Chave API não encontrada. Verifique as configurações.'];
        }
        try {
            // Usar o modelo gemini 2.0 flash que sabemos que funciona 
            $model = 'gemini-2.0-flash';
            
            // Log detalhado para debug
            Log::info('Iniciando teste com Gemini', [
                'model' => $model,
                'token_length' => strlen($this->apiToken),
                'token_preview' => substr($this->apiToken, 0, 5) . '...'
            ]);
            
            // Usar a classe GeminiTest que implementa exatamente o mesmo código
            // que testamos e funciona perfeitamente
            $result = GeminiTest::testConnection($this->apiToken, $model);
            
            Log::info('Teste com Gemini concluído', [
                'result' => $result
            ]);
            
            return $result;
            
        } catch (\Exception $e) {
            Log::error('Falha ao testar Gemini', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            throw $e;
        }
    }

    /**
     * Testa a conexão com o Grok
     */
    private function testGrok()
    {
        if (!ReplicateSetting::isConfigured() || empty($this->apiToken)) {
            Log::warning("Configuração ausente ou inválida para o provedor {$this->provider}. Não prosseguindo com o teste.", [
                'provider' => $this->provider,
                'has_config' => false,
                'reason' => 'Missing API key or inactive setting'
            ]);
            return ['status' => 'error', 'message' => 'Configuração não encontrada. Verifique as configurações.'];
        }
        try {
            Log::info('Iniciando teste de conexão com Grok', [
                'model' => $this->model
            ]);

            // Como não temos a API oficial do Grok, vamos simular um teste bem-sucedido
            // Quando a API oficial estiver disponível, este código deve ser atualizado
            return true;  // Retorna true para indicar sucesso
        } catch (\Exception $e) {
            Log::error('Erro ao testar conexão com Grok: ' . $e->getMessage(), [
                'model' => $this->model
            ]);
            throw $e;  // Repassa o erro para o controller
        }
    }

    /**
     * Testa a conexão com o GitHub Copilot
     */
    private function testCopilot()
    {
        if (!ReplicateSetting::isConfigured() || empty($this->apiToken)) {
            Log::warning("Configuração ausente ou inválida para o provedor {$this->provider}. Não prosseguindo com o teste.", [
                'provider' => $this->provider,
                'has_config' => false,
                'reason' => 'Missing API key or inactive setting'
            ]);
            return ['status' => 'error', 'message' => 'Configuração não encontrada. Verifique as configurações.'];
        }
        try {
            Log::info('Iniciando teste de conexão com Copilot', [
                'model' => $this->model
            ]);

            // Como não temos a API oficial do Copilot, vamos simular um teste bem-sucedido
            // Quando a API oficial estiver disponível, este código deve ser atualizado
            return true;  // Retorna true para indicar sucesso
        } catch (\Exception $e) {
            Log::error('Erro ao testar conexão com Copilot: ' . $e->getMessage(), [
                'model' => $this->model
            ]);
            throw $e;  // Repassa o erro para o controller
        }
    }

    /**
     * Testa a conexão com o Tongyi (Qwen)
     */
    private function testTongyi()
    {
        if (!ReplicateSetting::isConfigured() || empty($this->apiToken)) {
            Log::warning("Configuração ausente ou inválida para o provedor {$this->provider}. Não prosseguindo com o teste.", [
                'provider' => $this->provider,
                'has_config' => false,
                'reason' => 'Missing API key or inactive setting'
            ]);
            return ['status' => 'error', 'message' => 'Configuração não encontrada. Verifique as configurações.'];
        }
        try {
            Log::info('Iniciando teste de conexão com Tongyi', [
                'model' => $this->model
            ]);

            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiToken,
                'Content-Type' => 'application/json',
            ])->post('https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation', [
                'model' => $this->model,
                'input' => [
                    'prompt' => 'Teste de conexão'
                ],
                'parameters' => [
                    'max_tokens' => 50
                ]
            ]);

            if (!$response->successful()) {
                $error = $response->json('message') ?? 'Erro desconhecido';
                throw new \Exception('Erro ao testar conexão com Tongyi: ' . $error);
            }

            return true;  // Retorna true para indicar sucesso
        } catch (\Exception $e) {
            Log::error('Erro ao testar conexão com Tongyi: ' . $e->getMessage(), [
                'model' => $this->model
            ]);
            throw $e;  // Repassa o erro para o controller
        }
    }

    /**
     * Testa a conexão com o Deepseek
     */
    private function testDeepseek()
    {
        if (!ReplicateSetting::isConfigured() || empty($this->apiToken)) {
            Log::warning("Configuração ausente ou inválida para o provedor {$this->provider}. Não prosseguindo com o teste.", [
                'provider' => $this->provider,
                'has_config' => false,
                'reason' => 'Missing API key or inactive setting'
            ]);
            return ['status' => 'error', 'message' => 'Configuração não encontrada. Verifique as configurações.'];
        }
        try {
            Log::info('Iniciando teste de conexão com Deepseek', [
                'model' => $this->model
            ]);

            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiToken,
                'Content-Type' => 'application/json',
            ])->post('https://api.deepseek.com/v1/chat/completions', [
                'model' => $this->model,
                'messages' => [
                    ['role' => 'system', 'content' => 'Você é um assistente útil.'],
                    ['role' => 'user', 'content' => 'Teste de conexão']
                ],
                'max_tokens' => 50
            ]);

            if (!$response->successful()) {
                $error = $response->json('error.message') ?? 'Erro desconhecido';
                throw new \Exception('Erro ao testar conexão com Deepseek: ' . $error);
            }

            return true;  // Retorna true para indicar sucesso
        } catch (\Exception $e) {
            Log::error('Erro ao testar conexão com Deepseek: ' . $e->getMessage(), [
                'model' => $this->model
            ]);
            throw $e;  // Repassa o erro para o controller
        }
    }

    /**
     * Analisa texto usando OpenAI
     */
    private function analyzeWithOpenAI($text)
    {
        $systemPrompt = $this->settings->system_prompt ?? 
            'Você é um assistente especializado em análise de extratos bancários e transações financeiras.';

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiToken,
            'Content-Type' => 'application/json',
        ])->post('https://api.openai.com/v1/chat/completions', [
            'model' => $this->model,
            'messages' => [
                ['role' => 'system', 'content' => $systemPrompt],
                ['role' => 'user', 'content' => $text]
            ],
            'temperature' => 0.3,
            'max_tokens' => 500
        ]);

        if (!$response->successful()) {
            throw new \Exception('Erro ao analisar com OpenAI: ' . $response->json('error.message'));
        }

        return $response->json('choices.0.message.content');
    }

    /**
     * Analisa texto usando Anthropic
     */
    private function analyzeWithAnthropic($text)
    {
        $systemPrompt = $this->settings->system_prompt ?? 
            'Você é um assistente especializado em análise de extratos bancários e transações financeiras.';

        $response = Http::withHeaders([
            'x-api-key' => $this->apiToken,
            'anthropic-version' => '2023-06-01',
            'Content-Type' => 'application/json',
        ])->post('https://api.anthropic.com/v1/messages', [
            'model' => $this->model,
            'system' => $systemPrompt,
            'messages' => [
                ['role' => 'user', 'content' => $text]
            ],
            'max_tokens' => 500
        ]);

        if (!$response->successful()) {
            throw new \Exception('Erro ao analisar com Anthropic: ' . $response->json('error.message'));
        }

        return $response->json('content.0.text');
    }
    
    /**
     * Analisa texto usando Google Gemini
     */
    private function analyzeWithGemini($text)
    {
        $systemPrompt = $this->settings->system_prompt ?? 
            'Você é um assistente especializado em análise de extratos bancários e transações financeiras.';

        // Combina o prompt do sistema com o texto do usuário
        $fullPrompt = $systemPrompt . "\n\n" . $text;

        $response = Http::withHeaders([
            'x-goog-api-key' => $this->apiToken,
            'Content-Type' => 'application/json',
        ])->post('https://generativelanguage.googleapis.com/v1beta/models/' . $this->model . ':generateContent', [
            'contents' => [
                'parts' => [
                    ['text' => $fullPrompt]
                ]
            ],
            'generationConfig' => [
                'temperature' => 0.3,
                'maxOutputTokens' => 500
            ]
        ]);

        if (!$response->successful()) {
            throw new \Exception('Erro ao analisar com Gemini: ' . ($response->json('error.message') ?? 'Erro desconhecido'));
        }

        return $response->json('candidates.0.content.parts.0.text');
    }
    
    /**
     * Analisa texto usando Grok
     */
    private function analyzeWithGrok($text)
    {
        $systemPrompt = $this->settings->system_prompt ?? 
            'Você é um assistente especializado em análise de extratos bancários e transações financeiras.';

        // Como não temos a API oficial do Grok, vamos simular uma resposta
        // Quando a API oficial estiver disponível, este código deve ser atualizado
        return "Resultado da análise do Grok: Esta é uma simulação de resposta, pois a API oficial do Grok ainda não está disponível.";
    }
    
    /**
     * Analisa texto usando GitHub Copilot
     */
    private function analyzeWithCopilot($text)
    {
        $systemPrompt = $this->settings->system_prompt ?? 
            'Você é um assistente especializado em análise de extratos bancários e transações financeiras.';

        // Como não temos a API oficial do Copilot, vamos simular uma resposta
        // Quando a API oficial estiver disponível, este código deve ser atualizado
        return "Resultado da análise do Copilot: Esta é uma simulação de resposta, pois a API oficial do Copilot ainda não está disponível.";
    }
    
    /**
     * Analisa texto usando Tongyi (Qwen)
     */
    private function analyzeWithTongyi($text)
    {
        $systemPrompt = $this->settings->system_prompt ?? 
            'Você é um assistente especializado em análise de extratos bancários e transações financeiras.';

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiToken,
            'Content-Type' => 'application/json',
        ])->post('https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation', [
            'model' => $this->model,
            'input' => [
                'prompt' => $systemPrompt . "\n\n" . $text
            ],
            'parameters' => [
                'temperature' => 0.3,
                'max_tokens' => 500
            ]
        ]);

        if (!$response->successful()) {
            throw new \Exception('Erro ao analisar com Tongyi: ' . ($response->json('message') ?? 'Erro desconhecido'));
        }

        return $response->json('output.text');
    }
    
    /**
     * Analisa texto usando Deepseek
     */
    private function analyzeWithDeepseek($text)
    {
        $systemPrompt = $this->settings->system_prompt ?? 
            'Você é um assistente especializado em análise de extratos bancários e transações financeiras.';

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiToken,
            'Content-Type' => 'application/json',
        ])->post('https://api.deepseek.com/v1/chat/completions', [
            'model' => $this->model,
            'messages' => [
                ['role' => 'system', 'content' => $systemPrompt],
                ['role' => 'user', 'content' => $text]
            ],
            'temperature' => 0.3,
            'max_tokens' => 500
        ]);

        if (!$response->successful()) {
            throw new \Exception('Erro ao analisar com Deepseek: ' . ($response->json('error.message') ?? 'Erro desconhecido'));
        }

        return $response->json('choices.0.message.content');
    }
} 