<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\View;
use Livewire\Livewire;
use App\Models\User;
use App\Models\Transaction;
use App\Observers\UserObserver;
use App\Observers\TransactionObserver;
use App\Livewire\Transactions\Income;
use App\Livewire\Transactions\Expenses;
use Carbon\Carbon;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Configurar URL base para assets
        if (app()->environment('local')) {
            // Usar o domínio solicitado para todas as URLs
            $domain = request()->getHost();
            $scheme = request()->getScheme();
            $port = request()->getPort();
            
            if ($port && $port != 80 && $port != 443) {
                $baseUrl = "{$scheme}://{$domain}:{$port}";
            } else {
                $baseUrl = "{$scheme}://{$domain}";
            }
            
            \Illuminate\Support\Facades\URL::forceRootUrl($baseUrl);
            \Illuminate\Support\Facades\URL::forceScheme($scheme);
            
            // Adicionar cabeçalhos CORS para recursos estáticos
            \Illuminate\Support\Facades\Response::macro('staticFile', function ($file) {
                $response = \Illuminate\Support\Facades\Response::file($file);
                $response->header('Access-Control-Allow-Origin', '*');
                return $response;
            });
            
            // Não usar Vite para Livewire (versão simplificada)
            config(['livewire.asset_url' => $baseUrl]);
        }
        
        // Configurar codificação UTF-8 para toda a aplicação
        mb_internal_encoding('UTF-8');
        
        // Registrar provider de configuração de IA
        $this->app->singleton('ai.config', function () {
            return new \App\Services\AIConfigService();
        });
        
        // Middlewares
        $this->app['router']->pushMiddlewareToGroup('web', \App\Http\Middleware\HandleUTF8Encoding::class);

        // Layout padrão para todas as views
        View::composer('*', function ($view) {
            // Somente aplica o layout se outro não foi definido e não for um layout/componente
            if (!str_contains($view->getName(), 'layouts.') && 
                !str_contains($view->getName(), 'components.') &&
                !$view->offsetExists('layout')) {
                $view->with('layout', 'layouts.app');
            }
        });

        Blade::component('components.application-logo', 'application-logo');
        User::observe(UserObserver::class);
        Transaction::observe(TransactionObserver::class);

        // Configurando o Carbon para português
        Carbon::setLocale('pt_BR');

        // Registrando componentes Livewire
        Livewire::component('transactions.income', Income::class);
        Livewire::component('transactions.expenses', Expenses::class);
        Livewire::component('partials.delete-transaction-button', \App\Livewire\Partials\DeleteTransactionButton::class);
        Livewire::component('settings.users.list-users', \App\Livewire\Settings\Users\ListUsers::class);
        Livewire::component('settings.users.create', \App\Livewire\Settings\Users\Create::class);
        Livewire::component('settings.users.edit', \App\Livewire\Settings\Users\Edit::class);
        Livewire::component('settings.users.delete', \App\Livewire\Settings\Users\Delete::class);
        Livewire::component('settings.users.create-user', \App\Livewire\Settings\Users\CreateUser::class);
        Livewire::component('settings.users.edit-user', \App\Livewire\Settings\Users\EditUser::class);
        Livewire::component('settings.roles.list-roles', \App\Livewire\Settings\Roles\ListRoles::class);
        Livewire::component('settings.roles.create', \App\Livewire\Settings\Roles\Create::class);
        Livewire::component('settings.roles.edit', \App\Livewire\Settings\Roles\Edit::class);
        Livewire::component('settings.roles.delete', \App\Livewire\Settings\Roles\Delete::class);
        Livewire::component('notification-settings-modal', \App\Livewire\NotificationSettingsModal::class);
        Livewire::component('wire-elements-modal', \LivewireUI\Modal\Modal::class);
        Livewire::component('settings.whatsapp-config', \App\Livewire\Settings\WhatsAppConfig::class);
        Livewire::component('settings.logs', \App\Livewire\Settings\Logs::class);

        // Registrar canal de WhatsApp
        \Illuminate\Support\Facades\Notification::extend('whatsapp', function ($app) {
            return new \App\Channels\WhatsAppChannel();
        });
    }
}
