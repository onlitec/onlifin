<?php

namespace App\Console\Commands;

use App\Models\Account;
use App\Models\Transaction;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CheckAccountBalance extends Command
{
    protected $signature = 'check:account {account?} {--fix : Fix the balance if discrepancy is found}';
    protected $description = 'Check account balance against transactions and fix if needed';

    public function handle()
    {
        $accountName = $this->argument('account');
        $shouldFix = $this->option('fix');
        
        if ($accountName) {
            // Check specific account
            $account = Account::where('name', 'like', "%{$accountName}%")->first();
            
            if (!$account) {
                $this->error("Account with name '{$accountName}' not found!");
                return 1;
            }
            
            $this->checkAccount($account, $shouldFix);
        } else {
            // Check all accounts
            $accounts = Account::all();
            $this->info("Checking " . $accounts->count() . " accounts...");
            
            foreach ($accounts as $account) {
                $this->checkAccount($account, $shouldFix);
                $this->line('--------------------------------------------------');
            }
        }
        
        return 0;
    }
    
    private function checkAccount(Account $account, bool $shouldFix)
    {
        $this->info("Account: {$account->name} (ID: {$account->id})");
        $this->line("Type: {$account->type}");
        $this->line("Current Balance in DB: " . number_format($account->current_balance, 2, ',', '.'));
        $this->line("Initial Balance: " . number_format($account->initial_balance, 2, ',', '.'));
        
        // Calculate expected balance from transactions
        $transactionsBalance = $account->transactions()
            ->where('status', 'paid')
            ->sum(DB::raw('CASE WHEN type = "income" THEN amount ELSE -amount END'));
            
        // Convert from cents to reais
        $transactionsBalanceInReal = $transactionsBalance / 100;
        
        // Expected balance = initial + transactions
        $expectedBalance = $account->initial_balance + $transactionsBalanceInReal;
        
        $this->line("Total from Transactions: " . number_format($transactionsBalanceInReal, 2, ',', '.'));
        $this->line("Expected Balance: " . number_format($expectedBalance, 2, ',', '.'));
        
        if (abs($account->current_balance - $expectedBalance) > 0.01) {
            $this->warn("⚠️ Discrepancy found: " . number_format($account->current_balance - $expectedBalance, 2, ',', '.'));
            
            if ($shouldFix) {
                $oldBalance = $account->current_balance;
                $newBalance = $account->recalculateBalance();
                
                $this->info("✅ Balance fixed: " . number_format($oldBalance, 2, ',', '.') . " -> " . number_format($newBalance, 2, ',', '.'));
            } else {
                $this->line("Run with --fix to correct the balance");
            }
        } else {
            $this->info("✅ Balance is correct!");
        }
        
        // Get recent transactions
        $recentTransactions = Transaction::where('account_id', $account->id)
            ->orderBy('date', 'desc')
            ->limit(5)
            ->get();
            
        if ($recentTransactions->count() > 0) {
            $this->line("\nRecent transactions:");
            $headers = ['ID', 'Type', 'Amount', 'Status', 'Date'];
            $rows = [];
            
            foreach ($recentTransactions as $transaction) {
                $rows[] = [
                    $transaction->id,
                    $transaction->type,
                    number_format($transaction->amount / 100, 2, ',', '.'),
                    $transaction->status,
                    $transaction->date->format('Y-m-d')
                ];
            }
            
            $this->table($headers, $rows);
        }
    }
} 