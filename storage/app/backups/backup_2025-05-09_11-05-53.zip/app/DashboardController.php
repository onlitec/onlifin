<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\Account;
use App\Models\Category;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $userId = auth()->id();
        $period = $request->get('period', 'current_month');
        
        // Define o período baseado na seleção
        $startDate = now()->startOfMonth();
        $endDate = now()->endOfMonth();
        $previousStartDate = now()->subMonthNoOverflow()->startOfMonth();
        $previousEndDate = now()->subMonthNoOverflow()->endOfMonth();

        switch ($period) {
            case 'last_month':
                $startDate = $previousStartDate;
                $endDate = $previousEndDate;
                $previousStartDate = now()->subMonthsNoOverflow(2)->startOfMonth();
                $previousEndDate = now()->subMonthsNoOverflow(2)->endOfMonth();
                break;
            case 'current_year':
                $startDate = now()->startOfYear();
                $endDate = now()->endOfYear();
                $previousStartDate = now()->subYearNoOverflow()->startOfYear();
                $previousEndDate = now()->subYearNoOverflow()->endOfYear();
                break;
            case 'last_year':
                $startDate = now()->subYearNoOverflow()->startOfYear();
                $endDate = now()->subYearNoOverflow()->endOfYear();
                $previousStartDate = now()->subYearsNoOverflow(2)->startOfYear();
                $previousEndDate = now()->subYearsNoOverflow(2)->endOfYear();
                break;
            case 'all_time':
                // Buscar a data da primeira transação para definir o início
                $firstTransactionDate = Transaction::where('user_id', $userId)->min('date');
                $startDate = $firstTransactionDate ? Carbon::parse($firstTransactionDate)->startOfDay() : now()->startOfMonth();
                $endDate = now()->endOfDay(); // Até hoje
                $previousStartDate = null; // Não aplicável para todo o período
                $previousEndDate = null;
                break;
            // default 'current_month' já está definido
        }

        // --- DADOS PARA CARDS DE RESUMO ---
        
        // Saldo Atual Total (soma de todas as contas)
        // $currentBalance = Account::where('user_id', $userId)->sum('current_balance');
        // Correção: buscar todas as contas e somar o valor do accessor current_balance
        $accounts = Account::where('user_id', $userId)->get();
        $currentBalance = $accounts->sum('current_balance'); // Não multiplicar por 100, o valor já está em reais
        
        // Totais do período selecionado (Apenas transações pagas)
        $queryPeriod = Transaction::where('user_id', $userId)
            ->where('status', 'paid')
            ->whereBetween('date', [$startDate, $endDate]);
            
        $totalIncomePeriod = (clone $queryPeriod)->where('type', 'income')->sum('amount');
        $totalExpensesPeriod = (clone $queryPeriod)->where('type', 'expense')->sum('amount');
        $balancePeriod = $totalIncomePeriod - $totalExpensesPeriod;
        
        // Variação Percentual (se aplicável)
        $incomeVariation = 0;
        $expensesVariation = 0;
        $balanceVariation = 0;
        if ($previousStartDate && $previousEndDate) {
             $queryPreviousPeriod = Transaction::where('user_id', $userId)
                 ->where('status', 'paid')
                 ->whereBetween('date', [$previousStartDate, $previousEndDate]);

            $previousIncome = (clone $queryPreviousPeriod)->where('type', 'income')->sum('amount');
            $previousExpenses = (clone $queryPreviousPeriod)->where('type', 'expense')->sum('amount');
            $previousBalance = $previousIncome - $previousExpenses;

            $incomeVariation = $previousIncome != 0 ? (($totalIncomePeriod - $previousIncome) / abs($previousIncome)) * 100 : ($totalIncomePeriod > 0 ? 100 : 0);
            $expensesVariation = $previousExpenses != 0 ? (($totalExpensesPeriod - $previousExpenses) / abs($previousExpenses)) * 100 : ($totalExpensesPeriod > 0 ? 100 : 0);
            $balanceVariation = $previousBalance != 0 ? (($balancePeriod - $previousBalance) / abs($previousBalance)) * 100 : ($balancePeriod != 0 ? 100 : 0);
        }
        
        // --- DADOS PARA GRÁFICOS --- 

        // 1. Despesas por Categoria (Período Selecionado)
        $expensesByCategory = Transaction::where('transactions.user_id', $userId)
            ->where('transactions.type', 'expense')
            ->where('status', 'paid')
            ->whereBetween('date', [$startDate, $endDate])
            ->join('categories', 'transactions.category_id', '=', 'categories.id')
            ->select(
                'categories.id as id',
                'categories.name as name', 
                DB::raw('SUM(transactions.amount) as total'),
                DB::raw('ROUND((SUM(transactions.amount) / (SELECT SUM(amount) FROM transactions WHERE user_id = ' . $userId . ' AND type = "expense" AND status = "paid" AND date BETWEEN "' . $startDate->format('Y-m-d') . '" AND "' . $endDate->format('Y-m-d') . '")) * 100, 1) as percentage')
            )
            ->groupBy('categories.id', 'categories.name')
            ->orderBy('total', 'desc')
            ->limit(10)
            ->get();

        // Preparar dados para Chart.js (Despesas)
        $expenseChartLabels = $expensesByCategory->pluck('name');
        $expenseChartData = $expensesByCategory->pluck('total');

        // 2. Receitas por Categoria (Período Selecionado)
        $incomeByCategory = Transaction::where('transactions.user_id', $userId)
            ->where('transactions.type', 'income')
            ->where('status', 'paid')
            ->whereBetween('date', [$startDate, $endDate])
            ->join('categories', 'transactions.category_id', '=', 'categories.id')
            ->select(
                'categories.id as id',
                'categories.name as name', 
                DB::raw('SUM(transactions.amount) as total'),
                DB::raw('ROUND((SUM(transactions.amount) / (SELECT SUM(amount) FROM transactions WHERE user_id = ' . $userId . ' AND type = "income" AND status = "paid" AND date BETWEEN "' . $startDate->format('Y-m-d') . '" AND "' . $endDate->format('Y-m-d') . '")) * 100, 1) as percentage')
            )
            ->groupBy('categories.id', 'categories.name')
            ->orderBy('total', 'desc')
            ->limit(10)
            ->get();
        
        // Preparar dados para Chart.js (Receitas)
        $incomeChartLabels = $incomeByCategory->pluck('name');
        $incomeChartData = $incomeByCategory->pluck('total');
        
        // 3. Saldo ao Longo do Tempo (Ex: Últimos 30 dias - pode ser ajustado pelo período)
        //   -> Calcular saldo diário pode ser pesado. Fazer para o mês atual como exemplo?
        $balanceOverTimeLabels = [];
        $balanceOverTimeData = [];
        // $runningBalance = Account::where('user_id', $userId)->sum('opening_balance'); // Coluna não existe
        // Calcular saldo inicial somando todas as transações ANTES do início do período do gráfico (mês atual)
        $startOfMonth = now()->startOfMonth();
        $runningBalance = Transaction::where('user_id', $userId)
                               ->where('status', 'paid')
                               ->where('date', '<', $startOfMonth)
                               ->sum(DB::raw('CASE WHEN type = \'income\' THEN amount ELSE -amount END'));
                               
        // Para simplificar, vamos calcular o fluxo do mês atual
        $today = now();
        $transactionsThisMonth = Transaction::where('user_id', $userId)
                                ->where('status', 'paid')
                                ->whereBetween('date', [$startOfMonth, $today])
                                ->orderBy('date')
                                ->select('date', 'amount', 'type')
                                ->get()
                                ->groupBy(fn($date) => Carbon::parse($date->date)->format('d/m')); // Agrupa por dia
        
        $currentDate = $startOfMonth->copy();
        while($currentDate->lte($today)) {
            $dayKey = $currentDate->format('d/m');
            $balanceOverTimeLabels[] = $dayKey;
            if(isset($transactionsThisMonth[$dayKey])) {
                foreach($transactionsThisMonth[$dayKey] as $t) {
                    $runningBalance += ($t->type === 'income' ? $t->amount : -$t->amount);
                }
            }
            $balanceOverTimeData[] = $runningBalance / 100; // Saldo no final do dia em Reais
            $currentDate->addDay();
        }

        // 4. NOVO: Previsão de Saldo (próximos 30 dias)
        $balanceForecastLabels = [];
        $balanceForecastData = [];
        
        // Último saldo conhecido (atual)
        $lastKnownBalance = end($balanceOverTimeData) ?: ($currentBalance / 100);
        
        // Próximos 30 dias
        $forecastStartDate = now()->addDay(); // Começar amanhã
        $forecastEndDate = now()->addDays(30); // Próximos 30 dias
        
        // Buscar transações futuras (programadas/pendentes)
        $futurePendingTransactions = Transaction::where('user_id', $userId)
            ->where('status', 'pending')
            ->whereBetween('date', [$forecastStartDate, $forecastEndDate])
            ->orderBy('date')
            ->select('date', 'amount', 'type')
            ->get()
            ->groupBy(fn($date) => Carbon::parse($date->date)->format('d/m'));
        
        // Projetar o saldo para os próximos 30 dias
        $forecastDate = $forecastStartDate->copy();
        $forecastBalance = $lastKnownBalance;
        
        while($forecastDate->lte($forecastEndDate)) {
            $dayKey = $forecastDate->format('d/m');
            $balanceForecastLabels[] = $dayKey;
            
            // Adicionar transações pendentes programadas para este dia
            if(isset($futurePendingTransactions[$dayKey])) {
                foreach($futurePendingTransactions[$dayKey] as $t) {
                    $forecastBalance += ($t->type === 'income' ? $t->amount : -$t->amount) / 100;
                }
            }
            
            $balanceForecastData[] = $forecastBalance;
            $forecastDate->addDay();
        }
        
        // 5. NOVO: Despesas por Conta Bancária
        $expensesByAccount = Transaction::where('transactions.user_id', $userId)
            ->where('transactions.type', 'expense')
            ->where('status', 'paid')
            ->whereBetween('date', [$startDate, $endDate])
            ->join('accounts', 'transactions.account_id', '=', 'accounts.id')
            ->select('accounts.name as account_name', DB::raw('SUM(transactions.amount) as total_amount'))
            ->groupBy('accounts.name')
            ->orderBy('total_amount', 'desc')
            ->get();
            
        // Preparar dados para Chart.js (Despesas por Conta)
        $accountExpenseLabels = $expensesByAccount->pluck('account_name');
        $accountExpenseData = $expensesByAccount->pluck('total_amount')->map(fn($amount) => $amount / 100);

        // 6. NOVO: Receitas vs Despesas ao Longo do Período
        $incomeExpenseTrendLabels = [];
        $incomeTrendData = [];
        $expenseTrendData = [];

        // Determinar a granularidade (diária ou mensal) baseado na duração do período
        $periodDurationInDays = $startDate->diffInDays($endDate);
        $granularityFormat = 'Y-m-d'; // Default: Diário
        $dbDateFormat = '%Y-%m-%d';
        if ($periodDurationInDays > 62) { // Se > ~2 meses, agrupar por mês
            $granularityFormat = 'Y-m';
            $dbDateFormat = '%Y-%m';
        }

        // Buscar transações pagas no período
        $periodTransactions = Transaction::where('user_id', $userId)
            ->where('status', 'paid')
            ->whereBetween('date', [$startDate, $endDate])
            ->select(
                DB::raw("DATE_FORMAT(date, '$dbDateFormat') as period_key"),
                'type',
                DB::raw('SUM(amount) as total')
            )
            ->groupBy('period_key', 'type')
            ->orderBy('period_key')
            ->get();

        // Agrupar por período (dia ou mês)
        $groupedTransactions = $periodTransactions->groupBy('period_key');

        // Iterar sobre o período para preencher os dados
        $trendDate = $startDate->copy();
        $endDateLoop = $endDate->copy(); // Usar cópia para não modificar o original

        while ($trendDate->lte($endDateLoop)) {
            $currentKey = $trendDate->format($granularityFormat);
            $incomeExpenseTrendLabels[] = $granularityFormat === 'Y-m-d' ? $trendDate->format('d/m') : $trendDate->format('m/Y'); // Formato do label

            $dailyIncome = 0;
            $dailyExpense = 0;

            if (isset($groupedTransactions[$currentKey])) {
                foreach ($groupedTransactions[$currentKey] as $transaction) {
                    if ($transaction->type === 'income') {
                        $dailyIncome = $transaction->total / 100; // Converter para Reais
                    } elseif ($transaction->type === 'expense') {
                        $dailyExpense = $transaction->total / 100; // Converter para Reais
                    }
                }
            }

            $incomeTrendData[] = $dailyIncome;
            $expenseTrendData[] = $dailyExpense;

            // Avançar para o próximo período
            if ($granularityFormat === 'Y-m-d') {
                $trendDate->addDay();
            } else {
                $trendDate->addMonthNoOverflow()->startOfMonth(); // Ir para o início do próximo mês
                 // Prevenir loop infinito se startDate e endDate estiverem no mesmo mês > 62 dias (caso raro)
                if ($trendDate->gt($endDateLoop) && $trendDate->format('Y-m') === $endDateLoop->format('Y-m')) {
                   break;
                }
            }
        }

        // --- DADOS ADICIONAIS (Transações recentes, pendentes, etc.) --- 
        // Manter ou remover as buscas por transações de hoje/amanhã/pendentes?
        // Por enquanto, vamos manter.
        $todayIncomes = Transaction::with(['category', 'account'])->where('user_id', $userId)->where('type', 'income')->whereDate('date', now()->toDateString())->orderBy('status', 'asc')->orderBy('date')->get();
        $todayExpenses = Transaction::with(['category', 'account'])->where('user_id', $userId)->where('type', 'expense')->whereDate('date', now()->toDateString())->orderBy('status', 'asc')->orderBy('date')->get();
        
        // NOVO: Buscar pendentes de hoje e amanhã
        $today = now()->toDateString();
        $tomorrow = now()->addDay()->toDateString();
        
        $pendingExpensesToday = Transaction::with(['category', 'account'])
            ->where('user_id', $userId)
            ->where('type', 'expense')
            ->where('status', 'pending')
            ->whereDate('date', $today)
            ->orderBy('date')
            ->get();
            
        $pendingExpensesTomorrow = Transaction::with(['category', 'account'])
            ->where('user_id', $userId)
            ->where('type', 'expense')
            ->where('status', 'pending')
            ->whereDate('date', $tomorrow)
            ->orderBy('date')
            ->get();
            
        $pendingIncomesToday = Transaction::with(['category', 'account'])
            ->where('user_id', $userId)
            ->where('type', 'income')
            ->where('status', 'pending')
            ->whereDate('date', $today)
            ->orderBy('date')
            ->get();
            
        $pendingIncomesTomorrow = Transaction::with(['category', 'account'])
            ->where('user_id', $userId)
            ->where('type', 'income')
            ->where('status', 'pending')
            ->whereDate('date', $tomorrow)
            ->orderBy('date')
            ->get();
        
        // Remover buscas antigas que serão substituídas ou não são mais necessárias para esta view
        // $nextWeek = now()->addDays(7)->toDateString();
        // $pendingIncomes = Transaction::with(['category', 'account'])->where('user_id', $userId)->where('type', 'income')->where('status', 'pending')->whereBetween('date', [now()->toDateString(), $nextWeek])->orderBy('date')->get();
        // $pendingExpenses = Transaction::with(['category', 'account'])->where('user_id', $userId)->where('type', 'expense')->where('status', 'pending')->whereBetween('date', [now()->toDateString(), $nextWeek])->orderBy('date')->get();

        // Criar array para cores de categorias
        $categoryColors = ['blue', 'green', 'red', 'purple', 'yellow', 'indigo', 'pink', 'teal'];

        // Buscar transações recentes para a nova aba transações
        $recentTransactions = Transaction::with(['category', 'account'])
            ->where('user_id', $userId)
            ->orderBy('date', 'desc')
            ->limit(10)
            ->get();

        // Atribuir $expensesByCategory à variável $expenseCategories que é esperada na view
        $expenseCategories = $expensesByCategory;

        $incomeByCategory = Transaction::where('transactions.user_id', $userId)
            ->where('transactions.type', 'income')
            ->where('status', 'paid')
            ->whereBetween('date', [$startDate, $endDate])
            ->join('categories', 'transactions.category_id', '=', 'categories.id')
            ->select(
                'categories.id as id',
                'categories.name as name', 
                DB::raw('SUM(transactions.amount) as total'),
                DB::raw('ROUND((SUM(transactions.amount) / (SELECT SUM(amount) FROM transactions WHERE user_id = ' . $userId . ' AND type = "income" AND status = "paid" AND date BETWEEN "' . $startDate->format('Y-m-d') . '" AND "' . $endDate->format('Y-m-d') . '")) * 100, 1) as percentage')
            )
            ->groupBy('categories.id', 'categories.name')
            ->orderBy('total', 'desc')
            ->limit(10)
            ->get();

        // Atribuir $incomeByCategory à variável $incomeCategories que é esperada na view
        $incomeCategories = $incomeByCategory;
        
        // NOVO: Buscar todas as contas do usuário para exibir no dashboard
        $userAccounts = Account::where('user_id', $userId)
            ->orderBy('name')
            ->get();

        // Passar todos os dados para a view
        return view('dashboard', compact(
            'period',
            'currentBalance',
            'totalIncomePeriod',
            'totalExpensesPeriod',
            'balancePeriod',
            'incomeVariation',
            'expensesVariation',
            'balanceVariation',
            'expenseChartLabels',
            'expenseChartData',
            'incomeChartLabels',
            'incomeChartData',
            'balanceOverTimeLabels',
            'balanceOverTimeData',
            'balanceForecastLabels',
            'balanceForecastData',
            'accountExpenseLabels',
            'accountExpenseData',
            'todayIncomes',
            'todayExpenses',
            // 'pendingIncomes', // Removido
            // 'pendingExpenses', // Removido
            // NOVO: Dados do gráfico de tendência
            'incomeExpenseTrendLabels',
            'incomeTrendData',
            'expenseTrendData',
            // NOVO: Pendentes hoje/amanhã
            'pendingExpensesToday',
            'pendingExpensesTomorrow',
            'pendingIncomesToday',
            'pendingIncomesTomorrow',
            'categoryColors',
            'recentTransactions',
            'expenseCategories',
            'incomeCategories',
            'userAccounts'
        ));
    }
} 