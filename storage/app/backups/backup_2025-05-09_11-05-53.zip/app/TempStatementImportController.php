<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Models\Category;
use App\Models\Account;
use App\Models\Transaction;
use App\Services\AIConfigService;
use DateTime;
// use Endeken\OFX\Ofx; // Remover ou comentar este, se não for usado em outro lugar
use App\Models\AiCallLog;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class TempStatementImportController extends Controller
{
    /**
     * Mostra o formulário de upload de extratos
     */
    public function index()
    {
        $accounts = Account::where('active', true)
            ->where('user_id', auth()->id())
            ->orderBy('name')
            ->get();
            
        // Verifica se a IA está configurada no banco de dados
        $aiConfigService = new AIConfigService();
        $aiConfig = $aiConfigService->getAIConfig();
        $aiConfigured = $aiConfig['is_configured'];
            
        return view('transactions.import', compact('accounts', 'aiConfig', 'aiConfigured'));
    }

    /**
     * Processa o upload do extrato
     */
    public function upload(Request $request)
    {
        // Ajuste: Log mais descritivo
        Log::info('Recebida requisição em /statements/upload', ['ajax' => $request->ajax(), 'method' => $request->method(), 'input' => $request->except('statement_file')]);

        // Apenas requisições AJAX POST são esperadas para o novo fluxo
        if ($request->ajax() && $request->isMethod('post')) {
            Log::info('Processando requisição AJAX POST para salvar extrato');
            
            $validator = Validator::make($request->all(), [
                'statement_file' => 'required|file|mimes:pdf,csv,ofx,qif,qfx,xls,xlsx,txt|max:10240',
                'account_id' => 'required|exists:accounts,id',
            ]);

            if ($validator->fails()) {
                Log::error('Validação falhou para salvar extrato AJAX', ['errors' => $validator->errors()->all()]);
                return response()->json(['success' => false, 'message' => $validator->errors()->first()], 422);
            }

            try {
                $file = $request->file('statement_file');
                $extension = strtolower($file->getClientOriginalExtension());
                $accountId = $request->input('account_id');

                // Salvar em uma pasta que indica que está pronto para análise
                $path = $file->store('temp_uploads'); 
                Log::info('Extrato armazenado para análise posterior', ['path' => $path, 'account_id' => $accountId, 'extension' => $extension]);

                if (!Storage::exists($path)) {
                    Log::error('Arquivo não encontrado após armazenamento para análise');
                    return response()->json(['success' => false, 'message' => 'Erro ao armazenar o extrato.'], 500);
                }

                // Retorna sucesso e os dados necessários para o botão "Analisar com IA"
                return response()->json([
                    'success' => true, 
                    'message' => 'Extrato enviado com sucesso! Clique em Analisar para continuar.',
                    'filePath' => $path,       // Caminho do arquivo salvo
                    'accountId' => $accountId, // ID da conta selecionada
                    'extension' => $extension  // Extensão do arquivo
                ]);

            } catch (\Exception $e) {
                Log::error('Erro durante o salvamento do extrato AJAX', [
                    'message' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
                return response()->json(['success' => false, 'message' => 'Erro interno ao salvar o extrato.'], 500);
            }
        }

        // Se não for AJAX POST, pode ser um acesso direto ou um erro de fluxo
        Log::warning('Acesso inesperado ao método upload', ['method' => $request->method(), 'ajax' => $request->ajax()]);
        return response()->json(['success' => false, 'message' => 'Requisição inválida.'], 400);
        
        // O antigo fluxo de fallback (não-AJAX) foi removido, pois o novo design depende do JS.
        // Se precisar de um fallback sem JS, teria que ser reimplementado de outra forma.
    }

    /**
     * Analisa o extrato após o upload
     */
    public function analyze()
    {
        // Recupera os dados do upload da sessão
        $uploadData = session('upload_data');
        if (!$uploadData) {
            Log::error('Dados de upload não encontrados na sessão');
            return redirect()->route('statements.upload')
                ->withErrors(['error' => 'Dados do upload não encontrados. Por favor, tente novamente.']);
        }

        $path = $uploadData['file_path'];
        $extension = $uploadData['extension'];
        $account_id = $uploadData['account_id'];
        $use_ai = $uploadData['use_ai'];

        Log::info('Iniciando análise do arquivo', $uploadData);

        try {
            // Extrai transações do arquivo
            $transactions = $this->extractTransactions($path, $extension);
            
            if (empty($transactions)) {
                Log::warning('Nenhuma transação extraída do arquivo', ['path' => $path, 'extensão' => $extension]);
                
                // Mesmo sem transações, salva os dados do upload na sessão
                session(['import_data' => [
                    'file_path' => $path,
                    'account_id' => $account_id,
                    'use_ai' => $use_ai,
                    'transactions' => [],
                    'analysis' => []
                ]]);
                
                // Redireciona para a página de mapeamento com aviso
                return redirect()->route('statements.mapping', [
                    'path' => $path,
                    'account_id' => $account_id,
                    'extension' => $extension,
                    'use_ai' => $use_ai
                ])->with('warning', 'Não foi possível extrair transações do arquivo. Verifique se o arquivo está no formato correto ou tente com outro arquivo.');
            }

            Log::info('Transações extraídas com sucesso', ['total' => count($transactions)]);

            // Análise das transações
            $analysis = $this->analyzeTransactions($transactions);

            // **** NOVO LOG: Antes de salvar na sessão ****
            Log::debug('DEBUG: Dados a serem salvos na sessão', [
                'keys' => ['file_path', 'account_id', 'use_ai', 'transactions', 'analysis'],
                'transaction_count' => count($transactions),
                'analysis_keys' => isset($analysis) ? array_keys($analysis) : 'null',
                'transaction_preview' => array_slice($transactions, 0, 2), // Logar as primeiras 2 transações
                'analysis_preview' => isset($analysis) ? array_slice($analysis, 0, 2, true) : null // Logar as primeiras 2 chaves da análise
            ]);
            // **** FIM DO NOVO LOG ****

            // Armazena dados na sessão para uso na próxima página
            session(['import_data' => [
                'file_path' => $path,
                'account_id' => $account_id,
                'use_ai' => $use_ai,
                'transactions' => $transactions,
                'analysis' => $analysis
            ]]);

            // Redireciona para a página de mapeamento com os parâmetros necessários
            return redirect()->route('statements.mapping', [
                'path' => $path,
                'account_id' => $account_id,
                'extension' => $extension,
                'use_ai' => $use_ai
            ])->with('success', 'Arquivo carregado e analisado com sucesso.');
            
        } catch (\Exception $e) {
            Log::error('Erro ao analisar arquivo', [
                'path' => $path, 
                'extension' => $extension, 
                'erro' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return redirect()->route('statements.upload')
                ->withErrors(['statement_file' => 'Erro ao analisar o arquivo: ' . $e->getMessage()]);
        }
    }

    /**
     * Mostra a tela de mapeamento de transações
     */
    public function showMapping(Request $request)
    {
        // Validar parâmetros essenciais da URL
        $validator = Validator::make($request->all(), [
            'path' => 'required|string',
            'account_id' => 'required|exists:accounts,id',
            'extension' => 'required|string|in:pdf,csv,ofx,qif,qfx,xls,xlsx,txt',
            'use_ai' => 'required|in:0,1',
        ]);

        if ($validator->fails()) {
            Log::error('Parâmetros inválidos para showMapping', ['errors' => $validator->errors()->all(), 'request' => $request->all()]);
            return redirect()->route('statements.import')
                ->with('error', 'Link de mapeamento inválido ou expirado. Por favor, tente a importação novamente. Erro: ' . $validator->errors()->first());
        }

        $path = $request->path;
        $accountId = $request->account_id;
        $extension = $request->extension;
        $useAI = $request->use_ai === '1'; // Converter para boolean
        $autoSave = $request->boolean('auto_save') ?? false; // Manter auto_save se usado

        Log::info('Iniciando showMapping', [
            'path' => $path, 'account_id' => $accountId, 'extension' => $extension, 'use_ai' => $useAI
        ]);

        // ****** MODO DEBUG PARA TESTAR SEM ARQUIVO ******
        $isDebugMode = ($path === 'debug_test');
        
        // **** NOVO LOG: Logo após iniciar e antes de verificar debug mode ****
        Log::debug('DEBUG: Dados brutos recuperados da sessão', ['import_data' => session('import_data')]);
        // **** FIM DO NOVO LOG ****
        
        if ($isDebugMode) {
            Log::info('🧪 MODO DEBUG ATIVADO: Usando transações simuladas para teste da IA');
            
            $account = Account::findOrFail($accountId);
            // Verificar permissão do usuário
            if ($account->user_id !== auth()->id()) {
                Log::warning('Tentativa de acesso não autorizado ao mapeamento (modo debug)', ['user_id' => auth()->id(), 'account_id' => $accountId]);
                abort(403, 'Acesso não autorizado a esta conta.');
            }
            
            // Simular transações extraídas para teste
            $extractedTransactions = [
                ['date' => '2024-07-26', 'description' => 'PAGAMENTO SALARIO', 'amount' => 550000, 'type' => 'income'],
                ['date' => '2024-07-25', 'description' => 'NETFLIX SERVICOS INTERNET', 'amount' => -3990, 'type' => 'expense'],
                ['date' => '2024-07-24', 'description' => 'SUPERMERCADO TAUSTE', 'amount' => -24550, 'type' => 'expense'],
                ['date' => '2024-07-23', 'description' => 'PAGAMENTO DIVIDENDOS AÇÕES', 'amount' => 12500, 'type' => 'income'],
                ['date' => '2024-07-22', 'description' => 'FARMACIA DROGA RAIA', 'amount' => -7850, 'type' => 'expense'],
                ['date' => '2024-07-21', 'description' => 'POSTO DE GASOLINA SHELL', 'amount' => -18920, 'type' => 'expense'],
            ];
        } else {
            // Verificar se o arquivo existe no storage (na pasta de uploads temporários)
            if (!Storage::exists($path)) {
                Log::error('Arquivo temporário não encontrado em showMapping', ['path' => $path]);
                return redirect()->route('statements.import')
                    ->with('error', 'Arquivo temporário não encontrado. Por favor, faça o upload novamente.');
            }
            
            $account = Account::findOrFail($accountId);
            // Verificar permissão do usuário
            if ($account->user_id !== auth()->id()) {
                Log::warning('Tentativa de acesso não autorizado ao mapeamento', ['user_id' => auth()->id(), 'account_id' => $accountId]);
                abort(403, 'Acesso não autorizado a esta conta.');
            }
            
            // Extrair transações do arquivo baseado no formato
            $extractedTransactions = [];
            try {
                // Usar os métodos de extração agora presentes neste controller
                if (in_array($extension, ['ofx', 'qfx'])) {
                    Log::info('Extraindo de OFX/QFX', ['path' => $path]);
                    $extractedTransactions = $this->extractTransactionsFromOFX($path);
                } elseif ($extension === 'csv') {
                    Log::info('Extraindo de CSV', ['path' => $path]);
                    $extractedTransactions = $this->extractTransactionsFromCSV($path);
                } elseif ($extension === 'pdf') { // Adicionar PDF se o método existir
                    if (method_exists($this, 'extractTransactionsFromPDF')) {
                        Log::info('Extraindo de PDF', ['path' => $path]);
                        $extractedTransactions = $this->extractTransactionsFromPDF($path);
                    } else {
                        Log::warning('Método extractTransactionsFromPDF não existe');
                        // Tente métodos de extração alternativos se disponíveis
                    }
                } // Adicionar outros formatos conforme necessário
                
                Log::info('Transações extraídas com sucesso', ['count' => count($extractedTransactions)]);
            } catch (\Exception $e) {
                Log::error('Erro ao extrair transações', [
                    'path' => $path, 
                    'extension' => $extension, 
                    'message' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
                
                // Se não conseguir extrair, use transações de exemplo
                $extractedTransactions = $this->getExampleTransactions();
                
                // Informar ao usuário sobre o problema
                session()->flash('warning', 'Não foi possível extrair todas as transações do arquivo. Exibindo exemplos. ' . $e->getMessage());
            }
        }
        // ****** FIM DO CÓDIGO MODIFICADO ******

        // Se não há transações, mostrar mensagem e transações vazias
        if (empty($extractedTransactions)) {
            Log::warning('Nenhuma transação extraída', ['path' => $path, 'extension' => $extension]);
            session()->flash('warning', 'Não foi possível extrair transações do arquivo. Verifique o formato do arquivo.');
        }

        // Analisar transações usando a IA se solicitado
        $aiAnalysis = null;
        if ($useAI) {
            try {
                // Diagnóstico adicional
                Log::info('Chamando análise com IA para ' . count($extractedTransactions) . ' transações');
                
                // A análise com IA será sempre realizada através de analyzeTransactionsWithAI
                $aiAnalysis = $this->analyzeTransactionsWithAI($transactions);
                
                if ($aiAnalysis) {
                    Log::info('Análise com IA concluída com sucesso', [
                        'transactions_analyzed' => count($aiAnalysis['transactions'] ?? [])
                    ]);
                } else {
                    Log::warning('Análise com IA retornou nulo');
                }
            } catch (\Exception $e) {
                Log::error('Erro na análise com IA', [
                    'message' => $e->getMessage(),
                    'trace' => $e->getTraceAsString()
                ]);
                
                session()->flash('error', 'Ocorreu um erro durante a análise com IA: ' . $e->getMessage());
            }
        }
        
        // Aplicar categorização às transações se a análise de IA for bem-sucedida
        if ($aiAnalysis) {
            $extractedTransactions = $this->applyCategorizationToTransactions($extractedTransactions, $aiAnalysis);
        }
        
        // Verificar se a resposta da IA está em um formato diferente e precisa ser adaptada
        if ($aiAnalysis && isset($aiAnalysis['categories']) && !isset($aiAnalysis['transactions'])) {
            // Formato diferente detectado, fazer adaptação aqui
            Log::warning('Formato de resposta da IA não padrão detectado. Adaptando...');
            // Código de adaptação...
        }

        // Categorias disponíveis para o usuário
        $categories = Category::where('user_id', auth()->id())
            ->orderBy('name')
            ->get()
            ->groupBy('type');
        
        // Verifica se a IA está configurada no banco de dados
        $aiConfigService = new AIConfigService();
        $aiConfig = $aiConfigService->getAIConfig();
        $aiConfigured = $aiConfig['is_configured'];
        
        // Determinar se deve mostrar instruções para primeira importação
        $hasImportedBefore = Transaction::where('user_id', auth()->id())
                                         ->where('created_at', '>', now()->subDays(90))
                                         ->where('status', 'paid')
                                         ->exists();
        
        // Preparar dados para a view
        $viewData = [
            'account' => $account,
            'transactions' => $extractedTransactions,
            'categories' => $categories,
            'path' => $path,
            'extension' => $extension,
            'aiConfigured' => $aiConfigured,
            'hasImportedBefore' => $hasImportedBefore,
            'usedAI' => $useAI && !empty($aiAnalysis),
            'autoSave' => $autoSave,
            'isDebugMode' => $isDebugMode // Nova flag para informar a view que estamos em modo debug
        ];
        
        // **** NOVO LOG: Testar json_encode manualmente ****
        $jsonTransactions = json_encode($extractedTransactions);
        $jsonError = json_last_error_msg();
        Log::debug('DEBUG: Resultado do json_encode manual', [
            'json_error' => $jsonError,
            'output_length' => ($jsonError === 'No error' && $jsonTransactions !== false) ? strlen($jsonTransactions) : 0,
            'output_preview' => ($jsonError === 'No error' && $jsonTransactions !== false) ? substr($jsonTransactions, 0, 500) . '...' : 'Falha na codificação',
            'original_count' => count($extractedTransactions)
        ]);
        // **** FIM DO NOVO LOG ****

        // DEBUG: Logar a contagem final de transações ANTES de retornar a view
        Log::info('Preparando dados para a view mapping', [
            'final_transaction_count' => count($extractedTransactions), // << Verificar esta contagem
            'view_data_keys' => array_keys($viewData)
        ]);

        // **** NOVO: Armazenar transações em uma chave de sessão temporária ****
        // Isso permitirá recuperá-las via AJAX em uma rota separada
        session(['temp_transactions' => $extractedTransactions]);
        
        // Incluir uma flag indicando que as transações devem ser carregadas via AJAX
        $viewData['load_via_ajax'] = true;

        return view('transactions.mapping', $viewData);
    }

    /**
     * Endpoint AJAX para retornar as transações armazenadas na sessão temporária
     */
    public function getTransactions()
    {
        // Recuperar transações da sessão
        $transactions = session('temp_transactions', []);
        
        // Remover da sessão após recuperar (opcional)
        // session()->forget('temp_transactions');
        
        // Retornar como JSON
        return response()->json(['transactions' => $transactions]);
    }

    /**
     * Analisa as transações usando IA com a configuração do banco de dados
     */
    private function analyzeTransactionsWithAI($transactions)
    {
        // Tempo de início da operação para medir performance
        $startTime = microtime(true);
        
        // **** ADD DEBUG LOG HERE ****
        Log::debug('⚡️ Entrando em analyzeTransactionsWithAI', [
            'parameter_type' => gettype($transactions),
            'is_parameter_array' => is_array($transactions),
            'parameter_count' => is_array($transactions) ? count($transactions) : 'N/A'
        ]);
        // **** END DEBUG LOG ****
        
        // Diagnóstico extra
        Log::info('🔍 [DIAGNÓSTICO IA] Método analyzeTransactionsWithAI INICIADO', [
            'total_transacoes' => count($transactions ?? []),
            'usuario_id' => auth()->id(),
            'memory_usage' => memory_get_usage(true) / 1024 / 1024 . ' MB',
            'exemplo_transacao' => isset($transactions[0]) ? json_encode($transactions[0]) : null
        ]);
        
        // Se não houver transações, retornar nulo imediatamente
        if (empty($transactions)) {
            Log::info('🚧 Nenhuma transação para analisar com IA');
            return null;
        }
        
        Log::info('🤖 INICIANDO ANÁLISE COM IA', [
            'total_transacoes' => count($transactions),
            'usuario_id' => auth()->id(),
            'exemplo_transacao' => isset($transactions[0]) ? json_encode($transactions[0]) : null
        ]);
        
        // Verificar se a IA está configurada no banco de dados
        $aiConfigService = new AIConfigService();
        if (!$aiConfigService->isAIConfigured()) {
            Log::warning('⚠️ Nenhuma IA configurada no banco de dados - usando resposta simulada');
            return $this->getMockAIResponse($transactions);
        }
        
        try {
            // Obter configurações da IA do banco de dados
            $aiConfig = $aiConfigService->getAIConfig();
            $aiProvider = $aiConfig['provider'];
            Log::info('🔍 Usando provedor IA: ' . $aiProvider);

            // Buscar o objeto ModelApiKey completo para a configuração principal
            $config = \App\Models\ModelApiKey::where('provider', $aiProvider)
                ->where('is_active', true)
                ->first();

            // Se não encontrou, tentar buscar configuração por modelo também
            if (!$config && isset($aiConfig['model_name'])) {
                $config = \App\Models\ModelApiKey::where('provider', $aiProvider)
                    ->where('model', $aiConfig['model_name'])
                    ->where('is_active', true)
                    ->first();
            }

            // Se ainda não encontrou, buscar qualquer configuração ativa
            if (!$config) {
                $config = \App\Models\ModelApiKey::where('is_active', true)->first();
                
                if ($config) {
                    Log::warning('⚠️ Usando IA alternativa: ' . $config->provider . '/' . $config->model);
                    $aiProvider = $config->provider; // Atualizar o provider para o encontrado
                }
            }

            if (!$config || empty($config->api_key) || empty($config->system_prompt)) {
                Log::error('❗ Erro Crítico: Configuração ativa principal inválida ou incompleta.', [
                    'provider' => $aiProvider,
                    'model' => $aiConfig['model_name'] ?? 'N/A',
                    'config_found' => !!$config,
                    'api_key_present' => !empty($config->api_key ?? ''),
                    'prompt_present' => !empty($config->system_prompt ?? '')
                ]);
                // Se a config principal falhar aqui, tentar o fallback geral
                Log::warning('Configuração principal inválida, iniciando fallback geral...');
                return $this->tryAnalysisWithAllAvailableProviders($transactions, $config); // Passa $config mesmo que incompleto para filtragem
            }

            // Adicionar log para diagnóstico
            Log::debug('🔧 Configuração para o provider ' . $aiProvider, [
                'config_id' => $config->id, // Log o ID
                'api_key_length' => strlen($config->api_key),
                'api_key_start' => substr($config->api_key, 0, 5) . '...',
                'model' => $config->model,
                'system_prompt_length' => strlen($config->system_prompt)
            ]);

            // **** ROTEAMENTO BASEADO NO PROVEDOR ****
            $resultado = null;
            Log::info('💬 Iniciando roteamento para análise de transações com ' . $aiProvider);

            switch (strtolower($config->provider)) { // Converter para lowercase para garantir
                case 'google': // Adicionar caso google
                case 'gemini':
                    Log::info('✅ [DEBUG PROVIDER] Caso google/gemini encontrado');
                    try {
                        $resultado = $this->analyzeTransactionsWithGemini($transactions, $config); // Passa o objeto
                        // Se falhar ou retornar null, tentar fallback
                        if (!$resultado) {
                            Log::warning('⚠️ Resultado nulo do analyzeTransactionsWithGemini. Tentando fallback geral...');
                            return $this->tryAnalysisWithAllAvailableProviders($transactions, $config); // Passar $config
                        }
                    } catch (\Exception $e) { // Use base Exception
                        Log::error('❌ Erro no método analyzeTransactionsWithGemini: ' . $e->getMessage());
                        // Tentar fallback geral em caso de exceção
                        return $this->tryAnalysisWithAllAvailableProviders($transactions, $config); // Passar $config
                    }
                    break;
                
                case 'grok':
                    Log::info('✅ [DEBUG PROVIDER] Caso grok encontrado');
                    // Supondo que exista um método analyzeTransactionsWithGrok
                    try {
                        $resultado = $this->analyzeTransactionsWithGrok($transactions, $config); // Passa o objeto
                        if (!$resultado) {
                            Log::warning('⚠️ Resultado nulo do analyzeTransactionsWithGrok. Tentando fallback geral...');
                            return $this->tryAnalysisWithAllAvailableProviders($transactions, $config); // Passar $config
                        }
                    } catch (\Exception $e) { // Use base Exception
                         Log::error('❌ Erro no método analyzeTransactionsWithGrok: ' . $e->getMessage());
                         return $this->tryAnalysisWithAllAvailableProviders($transactions, $config); // Passar $config
                    }
                    break;
                    
                case 'openrouter':
                    Log::info('✅ [DEBUG PROVIDER] Caso openrouter encontrado');
                    try {
                        $resultado = $this->analyzeTransactionsWithOpenRouter($transactions, $config); // Passa o objeto
                         if (!$resultado) {
                            Log::warning('⚠️ Resultado nulo do analyzeTransactionsWithOpenRouter. Tentando fallback geral...');
                            return $this->tryAnalysisWithAllAvailableProviders($transactions, $config); // Passar $config
                        }
                    } catch (\Exception $e) { // Use base Exception
                        Log::error('❌ Erro no método analyzeTransactionsWithOpenRouter: ' . $e->getMessage());
                        return $this->tryAnalysisWithAllAvailableProviders($transactions, $config); // Passar $config
                    }
                    break;
                    
                case 'openai':
                case 'anthropic':
                case 'deepseek':
                    Log::info('✅ [DEBUG PROVIDER] Caso ' . $config->provider . ' encontrado');
                    Log::warning('⚠️ Provedor ' . $config->provider . ' ainda não tem implementação específica, usando OpenRouter como fallback');
                    try {
                        $resultado = $this->analyzeTransactionsWithOpenRouter($transactions, $config); // Usar OpenRouter para outros provedores
                        if (!$resultado) {
                            Log::warning('⚠️ Resultado nulo do fallback para OpenRouter. Tentando alternativas...');
                            return $this->tryAnalysisWithAllAvailableProviders($transactions, $config);
                        }
                    } catch (\Exception $e) {
                        Log::error('❌ Erro no método de fallback: ' . $e->getMessage());
                        return $this->tryAnalysisWithAllAvailableProviders($transactions, $config);
                    }
                    break;

                default:
                    Log::warning('⚠️ Provedor de IA configurado ("' . $aiProvider . '") não é suportado diretamente. Tentando fallback geral...');
                    // Tentar o fallback geral que testa todos os provedores
                    return $this->tryAnalysisWithAllAvailableProviders($transactions, $config); // Passar $config
            }
            
            // **** FIM DO ROTEAMENTO ****

            // Verificar se o resultado é válido (seja da IA real ou do mock)
            if ($resultado && isset($resultado['transactions']) && !empty($resultado['transactions'])) {
                $duration = round(microtime(true) - $startTime, 2);
                
                // Verifica se a resposta é do mock ou da IA real
                $usouMock = false;
                
                // Se possui campo específico que só existe no mock, considera como mock
                if (isset($resultado['is_mock_response']) && $resultado['is_mock_response'] === true) {
                    $usouMock = true;
                } 
                // Ou se não tem campos que seriam esperados em uma resposta real
                elseif (isset($resultado['transactions'][0]) && 
                         !isset($resultado['transactions'][0]['cliente']) && 
                         !isset($resultado['transactions'][0]['fornecedor']) && 
                         !isset($resultado['transactions'][0]['notes'])) {
                    $usouMock = true;
                }
                
                // Mensagem de log apropriada baseada na detecção real de uso de mock
                $logMessage = $usouMock 
                    ? '⚠️ Análise concluída usando resposta simulada (fallback)' 
                    : '🎉 Análise com ' . $aiProvider . ' concluída com sucesso';
                
                Log::info($logMessage, [
                    'provedor_usado' => $aiProvider, // Informa qual provedor foi tentado
                    'tempo_execucao' => $duration . 's',
                    'total_transacoes_analisadas' => count($resultado['transactions']),
                    'exemplo_resultado' => isset($resultado['transactions'][0]) ? json_encode($resultado['transactions'][0]) : null
                ]);
                return $resultado;
            } else {
                Log::warning('⚠️ Resposta vazia ou inválida do método de análise (incluindo mock). Nenhuma categorização será aplicada.', ['provedor' => $aiProvider]);
                return null; // Retornar null se nem o mock funcionou ou a análise falhou totalmente
            }
            
        } catch (\Exception $e) {
            // Logar exceção geral e registrar no banco se possível
            Log::error('❌ Exceção GERAL ao processar requisição IA', ['mensagem' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);
            $logData['error_message'] = 'Exceção Geral: ' . substr($e->getMessage(), 0, 800);
            $logData['duration_ms'] = isset($logData['duration_ms']) ? $logData['duration_ms'] : (int) round((microtime(true) - $startTime) * 1000);
            // Tenta salvar o log mesmo com a exceção geral
            try { \App\Models\AiCallLog::create($logData); } catch (\Exception $logEx) { Log::error('Falha ao salvar log de erro da IA', ['log_exception' => $logEx->getMessage()]); }
            return null;
        }
    }
    
    /**
     * Método específico para análise com Gemini
     */
    private function analyzeTransactionsWithGemini($transactions, $apiConfig) // $apiConfig é agora ModelApiKey object
    {
        $startTime = microtime(true);
        $logData = [
            'user_id' => auth()->id(),
            'provider' => $apiConfig->provider ?? 'gemini',
            'model' => $apiConfig->model ?? 'unknown-model',
            'transactions' => count($transactions)
        ];
        
        // **** DEBUG LOG ****
        Log::info('▶️ Entrando em analyzeTransactionsWithGemini', [
            'transactions_count' => count($transactions),
            'provider' => $apiConfig->provider ?? 'gemini',
            'model' => $apiConfig->model ?? 'unknown-model'
        ]);
        // **** END DEBUG ****
        
        try {
            // Preparar o prompt principal e de usuário
            $prompt = $this->preparePromptForAI($transactions, $apiConfig->system_prompt);
            
            // Montar URL da API
            $formattedModelName = strtolower(str_replace(' ', '-', $apiConfig->model));
            $url = "https://generativelanguage.googleapis.com/v1beta/models/{$formattedModelName}:generateContent?key={$apiConfig->api_token}";
            
            // Log da API sem a chave
            $safeUrl = str_replace($apiConfig->api_token, '[API_KEY_HIDDEN]', $url);
            Log::debug('🔗 API URL: ' . $safeUrl);
            
            // Preparar dados da requisição
            $requestData = [
                'contents' => [
                    [
                        'parts' => [
                            [
                                'text' => $prompt['system'] . "\n\n" . $prompt['user']
                            ]
                        ]
                    ]
                ],
                'generationConfig' => [
                    'temperature' => 0.2,
                    'topK' => 40,
                    'topP' => 0.8,
                    'maxOutputTokens' => 8000
                ]
            ];
            
            // Fazer requisição à API
            Log::debug('📤 Enviando requisição para Gemini...');
            $response = \Illuminate\Support\Facades\Http::withHeaders([
                'Content-Type' => 'application/json'
            ])->timeout(90)->post($url, $requestData);
            
            // Verificar e processar resposta
            if ($response->successful()) {
                Log::info('✅ Resposta recebida do Gemini com sucesso');
                $responseData = $response->json();
                
                if (!isset($responseData['candidates'][0]['content']['parts'][0]['text'])) {
                    Log::error('❌ Formato de resposta inesperado do Gemini', [
                        'response' => json_encode($responseData)
                    ]);
                    return null;
                }
                
                // Extrai o texto da resposta
                $aiResponse = $responseData['candidates'][0]['content']['parts'][0]['text'];
                Log::debug('📥 Resposta recebida do Gemini', [
                    'response_length' => strlen($aiResponse),
                    'response_preview' => substr($aiResponse, 0, 300) . '...'
                ]);
                
                // Extrair resultado JSON da resposta
                $extractedTransactions = $this->extractGeminiJsonOutput($aiResponse, $transactions);
                
                // Se não conseguir extrair, tenta converter para JSON válido
                if (!$extractedTransactions) {
                    Log::warning('⚠️ Erro no formato JSON da resposta. Tentando reparar...');
                    $extractedTransactions = $this->convertToValidJson($aiResponse, $transactions);
                }
                
                if ($extractedTransactions) {
                    // Calcula tempo de execução
                    $endTime = microtime(true);
                    $executionTime = $endTime - $startTime;
                    
                    Log::info('✨ Análise com Gemini concluída com sucesso', [
                        'execution_time' => number_format($executionTime, 2) . 's',
                        'transactions_analyzed' => count($extractedTransactions['transactions'])
                    ]);
                    
                    return $extractedTransactions;
                } else {
                    Log::error('❌ Falha ao extrair dados da resposta do Gemini', [
                        'response_preview' => substr($aiResponse, 0, 500)
                    ]);
                    return null;
                }
                
            } else {
                // Falha na API
                Log::error('❌ Erro na API do Gemini', [
                    'status' => $response->status(),
                    'response' => $response->body(),
                    'url' => $safeUrl
                ]);
                return null;
            }
            
        } catch (\Exception $e) {
            Log::error('❌ Exceção geral no método analyzeTransactionsWithGemini', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'transactions_count' => count($transactions)
            ]);
            return null;
        }
    }
    
    /**
     * Analisa transações usando OpenRouter como provedor
     * @param array $transactions Lista de transações para analisar
     * @param \App\Models\ModelApiKey $config Configuração de API contendo as credenciais
     * @return array|null Resultados da análise ou null em caso de falha
     */
    private function analyzeTransactionsWithOpenRouter($transactions, $config)
    {
        Log::info('🔄 Iniciando análise com OpenRouter', [
            'model' => $config->model, 
            'num_transactions' => count($transactions)
        ]);
        
        try {
            // Preparar prompt para OpenRouter
            $prompt = $this->preparePromptForAI($transactions, $config->system_prompt);
            
            // **** DEBUG LOG ****
            Log::debug('Prompt preparado para OpenRouter', [
                'prompt_start' => substr($prompt['system'], 0, 100) . '...',
                'prompt_user_start' => substr($prompt['user'], 0, 100) . '...',
                'transactions_count' => count($transactions)
            ]);
            // **** END DEBUG ****
            
            // Determinar endpoint
            $endpoint = 'https://openrouter.ai/api/v1/chat/completions';
            
            // Usar configuração para endpoint se for um objeto OpenRouterConfig convertido
            if (isset($config->endpoint) && !empty($config->endpoint)) {
                $endpoint = rtrim($config->endpoint, '/') . '/chat/completions';
            }
            
            Log::debug('Enviando solicitação para OpenRouter', [
                'endpoint' => $endpoint,
                'model' => $config->model
            ]);
            
            // Montar mensagens para API
            $messages = [
                ['role' => 'system', 'content' => $prompt['system']],
                ['role' => 'user', 'content' => $prompt['user']]
            ];
            
            // Fazer requisição à API
            $response = \Illuminate\Support\Facades\Http::withHeaders([
                'Content-Type' => 'application/json',
                'Authorization' => "Bearer {$config->api_token}"
            ])->timeout(120) // Timeout maior para análises complexas
              ->post($endpoint, [
                'model' => $config->model,
                'messages' => $messages,
                'temperature' => 0.2, // Temperatura baixa para respostas mais previsíveis
                'response_format' => ['type' => 'json_object']
            ]);
            
            // **** DEBUG LOG ****
            Log::debug('Resposta recebida do OpenRouter', [
                'status' => $response->status(),
                'header' => $response->headers(),
                'body_preview' => substr($response->body(), 0, 500) . '...',
            ]);
            // **** END DEBUG ****
            
            // Analisar resposta
            if ($response->successful()) {
                // Extrair texto da resposta
                $responseData = $response->json();
                $aiResponse = null;
                
                if (isset($responseData['choices'][0]['message']['content'])) {
                    $aiResponse = $responseData['choices'][0]['message']['content'];
                    Log::info('Resposta recebida do OpenRouter com sucesso', [
                        'response_length' => strlen($aiResponse)
                    ]);
                } else {
                    Log::error('Resposta do OpenRouter não contém o formato esperado', [
                        'response' => $responseData
                    ]);
                    return null;
                }
                
                // Processar resposta JSON
                try {
                    $parsedResponse = json_decode($aiResponse, true);
                    
                    // Verificar se a resposta contém o formato esperado
                    if (is_array($parsedResponse) && isset($parsedResponse['transactions']) && is_array($parsedResponse['transactions'])) {
                        Log::info('Análise com OpenRouter concluída com sucesso');
                        return $parsedResponse;
                    } else {
                        Log::error('Resposta do OpenRouter não está no formato esperado', [
                            'received' => $parsedResponse
                        ]);
                        return null;
                    }
                } catch (\Exception $e) {
                    Log::error('Erro ao processar resposta JSON do OpenRouter', [
                        'error' => $e->getMessage(),
                        'response' => $aiResponse
                    ]);
                    return null;
                }
                
            } else {
                // Falha na requisição
                Log::error('Falha na requisição ao OpenRouter', [
                    'status' => $response->status(),
                    'error' => $response->body()
                ]);
                return null;
            }
            
        } catch (\Exception $e) {
            // Capturar qualquer exceção
            Log::error('Exceção durante análise com OpenRouter', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return null;
        }
    }
    
    /**
     * Analisa transações usando o modelo Grok da xAI
     * @param array $transactions Lista de transações para analisar
     * @param \App\Models\ModelApiKey $config Configuração de API contendo as credenciais
     * @return array|null Resultados da análise ou null em caso de falha
     */
    private function analyzeTransactionsWithGrok($transactions, $config)
    {
        Log::info('🔄 Iniciando análise com Grok', [
            'model' => $config->model, 
            'num_transactions' => count($transactions)
        ]);
        
        try {
            // Preparar prompt para Grok
            $prompt = $this->preparePromptForAI($transactions, $config->system_prompt);
            
            // O Grok usa a mesma API que a OpenAI
            $endpoint = 'https://api.groq.com/v1/chat/completions';
            
            Log::debug('Enviando solicitação para Grok', [
                'endpoint' => $endpoint,
                'model' => $config->model
            ]);
            
            // Montar mensagens para API
            $messages = [
                ['role' => 'system', 'content' => $prompt['system']],
                ['role' => 'user', 'content' => $prompt['user']]
            ];
            
            // Fazer requisição à API
            $response = \Illuminate\Support\Facades\Http::withHeaders([
                'Content-Type' => 'application/json',
                'Authorization' => "Bearer {$config->api_token}"
            ])->timeout(120) // Timeout maior para análises complexas
              ->post($endpoint, [
                'model' => $config->model,
                'messages' => $messages,
                'temperature' => 0.2, // Temperatura baixa para respostas mais previsíveis
                'response_format' => ['type' => 'json_object']
            ]);
            
            // **** DEBUG LOG ****
            Log::debug('Resposta recebida do Grok', [
                'status' => $response->status(),
                'header' => $response->headers(),
                'body_preview' => substr($response->body(), 0, 500) . '...',
            ]);
            // **** END DEBUG ****
            
            // Analisar resposta
            if ($response->successful()) {
                // Extrair texto da resposta
                $responseData = $response->json();
                $aiResponse = null;
                
                if (isset($responseData['choices'][0]['message']['content'])) {
                    $aiResponse = $responseData['choices'][0]['message']['content'];
                    Log::info('Resposta recebida do Grok com sucesso', [
                        'response_length' => strlen($aiResponse)
                    ]);
                } else {
                    Log::error('Resposta do Grok não contém o formato esperado', [
                        'response' => $responseData
                    ]);
                    return null;
                }
                
                // Processar resposta JSON
                try {
                    $parsedResponse = json_decode($aiResponse, true);
                    
                    // Verificar se a resposta contém o formato esperado
                    if (is_array($parsedResponse) && isset($parsedResponse['transactions']) && is_array($parsedResponse['transactions'])) {
                        Log::info('Análise com Grok concluída com sucesso');
                        return $parsedResponse;
                    } else {
                        Log::error('Resposta do Grok não está no formato esperado', [
                            'received' => $parsedResponse
                        ]);
                        return null;
                    }
                } catch (\Exception $e) {
                    Log::error('Erro ao processar resposta JSON do Grok', [
                        'error' => $e->getMessage(),
                        'response' => $aiResponse
                    ]);
                    return null;
                }
                
            } else {
                // Falha na requisição
                Log::error('Falha na requisição ao Grok', [
                    'status' => $response->status(),
                    'error' => $response->body()
                ]);
                return null;
            }
            
        } catch (\Exception $e) {
            // Capturar qualquer exceção
            Log::error('Exceção durante análise com Grok', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return null;
        }
    }

    /**
     * Extrai o JSON da saída do OpenRouter
     * 
     * @param string $output Saída da IA
     * @param array $transactions Transações originais
     * @return array Transações categorizadas
     */
    private function extractOpenRouterJsonOutput($output, $transactions)
    {
        // Logar a resposta bruta para análise
        Log::debug('Resposta bruta do OpenRouter', [
            'output_preview' => substr($output, 0, 1000) . (strlen($output) > 1000 ? '...' : ''),
            'output_length' => strlen($output),
            'is_json' => json_decode($output) !== null ? 'sim' : 'não'
        ]);
        
        // Verificar se a resposta é um objeto JSON válido
        if (empty($output) || $output === 'null' || $output === '{}') {
            Log::warning('⚠️ Resposta do OpenRouter está vazia ou nula');
            return $this->createFallbackResponse($transactions);
        }
        
        // Verificar se a resposta é um objeto JSON com campo "format"
        $decodedOutput = json_decode($output, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            // Se já é um objeto com "transactions", retornar imediatamente
            if (isset($decodedOutput['transactions']) && is_array($decodedOutput['transactions'])) {
                Log::info('✅ Encontrado objeto JSON com campo transactions diretamente na resposta');
                return $decodedOutput;
            }
            
            // Se tiver "format", tentar extrair
            if (isset($decodedOutput['format'])) {
                Log::debug('DEBUG: Resposta contém campo format', $decodedOutput);
                
                // Se o format é um array que contém "transactions", criar uma resposta com as transações originais
                if (is_array($decodedOutput['format']) && in_array('transactions', $decodedOutput['format'])) {
                    Log::info('✅ Criando resposta com transações originais');
                    return $this->createFallbackResponse($transactions);
                }
                
                // Tenta decodificar o conteúdo do campo format se ele contiver um JSON em string
                $formatContent = json_decode($decodedOutput['format'], true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($formatContent)) {
                    // Se format contém um array válido, usa este como o conteúdo
                    Log::info('✅ Extraído conteúdo do campo format como array');
                    return ['transactions' => $formatContent];
                } else if (is_string($decodedOutput['format'])) {
                    // Se format é uma string que contém "transactions", tentar extrair dados
                    if (strpos($decodedOutput['format'], 'transactions') !== false) {
                        // Tenta extrair o JSON da string
                        $jsonStr = $this->sanitizeAndRepairJson($decodedOutput['format']);
                        $jsonData = json_decode($jsonStr, true);
                        if (json_last_error() === JSON_ERROR_NONE && isset($jsonData['transactions'])) {
                            Log::info('✅ Extraído JSON de string format');
                            return $jsonData;
                        }
                    }
                }
            }
        }
        
        // Se chegou aqui, não conseguiu extrair dados válidos
        Log::warning('⚠️ Não foi possível extrair dados válidos da resposta do OpenRouter');
        return $this->createFallbackResponse($transactions);
    }

    private function createFallbackResponse($transactions)
    {
        $fallbackTransactions = [];
        foreach ($transactions as $index => $transaction) {
            $fallbackTransactions[] = [
                'id' => $index,
                'type' => $transaction['type'] ?? 'expense',
                'suggested_category' => $transaction['type'] == 'income' ? 'Receita' : 'Despesa',
                'cliente' => $transaction['type'] == 'income' ? $this->extractClienteFromDescription($transaction['description']) : '',
                'fornecedor' => $transaction['type'] == 'expense' ? $this->extractFornecedorFromDescription($transaction['description']) : '',
                'notes' => 'Extraído automaticamente (fallback)'
            ];
        }
        return ['transactions' => $fallbackTransactions];
    }

    private function extractNotesFromDescription($description)
    {
        $notes = [];
        
        // Extrair tipo de transação
        if (preg_match('/(PIX|TED|DOC|TEF|Cartão|Débito|Crédito)/i', $description, $matches)) {
            $notes[] = 'Tipo: ' . $matches[1];
        }
        
        // Extrair número do cartão (últimos 4 dígitos)
        if (preg_match('/\*\s*(\d{4})/', $description, $matches)) {
            $notes[] = 'Cartão final: ' . $matches[1];
        }
        
        // Extrair CPF/CNPJ
        if (preg_match('/(\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}|\d{3}\.\d{3}\.\d{3}-\d{2})/', $description, $matches)) {
            $notes[] = 'CPF/CNPJ: ' . $matches[1];
        }
        
        // Extrair código de referência
        if (preg_match('/Ref:\s*(\d+)/i', $description, $matches)) {
            $notes[] = 'Ref: ' . $matches[1];
        }
        
        // Se não encontrou nenhuma informação específica, usar a descrição completa
        if (empty($notes)) {
            $notes[] = $description;
        }
        
        return implode(' | ', $notes);
    }
    
    /**
     * Sanitiza e corrige JSON mal formado
     *
     * @param string $jsonStr String JSON para corrigir
     * @return string JSON corrigido
     */
    private function sanitizeAndRepairJson($jsonStr)
    {
        // Remover qualquer marcação de código Markdown (```json) no início e fim
        $jsonStr = preg_replace('/^```(?:json)?[\r\n]*/m', '', $jsonStr);
        $jsonStr = preg_replace('/[\r\n]*```$/m', '', $jsonStr);
        
        // Abordagem mais direta: extrair o bloco de array JSON com regex
        if (preg_match('/(\[\s*\{.*\}\s*\])/s', $jsonStr, $matches)) {
            $jsonStr = $matches[1];
            Log::debug('Extraído array JSON diretamente via regex');
        }
        
        // 2. Remover comentários JavaScript (tanto // quanto /* */)
        $jsonStr = preg_replace('/\/\/.*?[\r\n]/s', '', $jsonStr); // Remove comentários de linha
        $jsonStr = preg_replace('/\/\*.*?\*\//s', '', $jsonStr);   // Remove comentários de bloco
        
        // 3. Remover caracteres de controle problemáticos
        $jsonStr = preg_replace('/[\x00-\x1F\x7F]/u', '', $jsonStr);
        
        // 4. Corrigir problemas comuns de JSON
        $jsonStr = preg_replace('/,\s*(\}|\])/', '$1', $jsonStr); // Remove vírgulas antes de fechamento
        $jsonStr = preg_replace('/}\s*{/', '},{', $jsonStr); // Adiciona vírgula entre objetos se faltando
        
        // 5. Corrigir possíveis aspas simples usadas como aspas duplas
        $jsonStr = preg_replace("/'([^']+)'/", '"$1"', $jsonStr);
        
        // 6. Garantir que o JSON comece com [ e termine com ]
        if (!preg_match('/^\s*\[/', $jsonStr)) {
            $jsonStr = '[' . $jsonStr;
        }
        if (!preg_match('/\]\s*$/', $jsonStr)) {
            $jsonStr = $jsonStr . ']';
        }
        
        // 7. Garantir que nomes de propriedades tenham aspas duplas
        $jsonStr = preg_replace('/([{,])\s*([a-zA-Z0-9_]+)\s*:/', '$1"$2":', $jsonStr);
        
        return $jsonStr;
    }
    
    /**
     * Método de último recurso para criar JSON válido a partir da resposta
     *
     * @param string $output Saída original da API
     * @param array $transactions Transações originais
     * @return string JSON válido
     */
    private function convertToValidJson($output, $transactions)
    {
        $result = [];
        
        // Tenta encontrar padrões estruturados em linhas
        $lines = explode("\n", $output);
        $currentTransaction = null;
        $index = 0;
        
        foreach ($lines as $line) {
            $line = trim($line);
            
            // Detectar início de uma nova transação
            if (preg_match('/Transação\s+(\d+)|ID\s*[:=]\s*(\d+)|Transaction\s+(\d+)|id\s*[:=]\s*(\d+)/i', $line, $matches)) {
                // Salvar a transação anterior se existir
                if ($currentTransaction !== null && !empty($currentTransaction)) {
                    $result[] = $currentTransaction;
                }
                
                // Iniciar nova transação
                $currentTransaction = [
                    'id' => $index,
                    'type' => 'expense',
                    'category_id' => null,
                    'suggested_category' => 'Despesa Diversa'
                ];
                
                $index++;
            }
            
            // Extrair campos específicos
            if ($currentTransaction !== null) {
                // Categoria
                if (preg_match('/categoria\s*[:=]\s*"?([^"]+)"?/i', $line, $matches)) {
                    $currentTransaction['suggested_category'] = trim($matches[1]);
                }
                
                // Tipo
                if (preg_match('/tipo\s*[:=]\s*"?([^"]+)"?/i', $line, $matches)) {
                    $type = strtolower(trim($matches[1]));
                    $currentTransaction['type'] = (strpos($type, 'receita') !== false || 
                                                strpos($type, 'income') !== false) 
                                                ? 'income' : 'expense';
                }
                
                // Cliente
                if (preg_match('/cliente\s*[:=]\s*"?([^"]+)"?/i', $line, $matches)) {
                    $currentTransaction['cliente'] = trim($matches[1]);
                }
                
                // Fornecedor
                if (preg_match('/fornecedor\s*[:=]\s*"?([^"]+)"?/i', $line, $matches)) {
                    $currentTransaction['fornecedor'] = trim($matches[1]);
                }
                
                // Notas
                if (preg_match('/notas\s*[:=]\s*"?([^"]+)"?|observa(?:ções|coes)\s*[:=]\s*"?([^"]+)"?/i', $line, $matches)) {
                    $currentTransaction['notes'] = trim($matches[1] ?? $matches[2]);
                }
            }
        }
        
        // Adicionar a última transação se existir
        if ($currentTransaction !== null && !empty($currentTransaction)) {
            $result[] = $currentTransaction;
        }
        
        // Se não conseguiu extrair nada, tenta com regex mais amplo
        if (empty($result) && preg_match_all('/\{[^{}]*\"id\"[^{}]*\}/i', $output, $matches)) {
            foreach ($matches[0] as $jsonObj) {
                $cleaned = $this->sanitizeAndRepairJson('{' . $jsonObj . '}');
                $obj = json_decode($cleaned, true);
                if ($obj !== null) {
                    $result[] = $obj;
                }
            }
        }
        
        // Se ainda estiver vazio, retornar um array vazio como JSON
        if (empty($result)) {
            $result = [];
        }
        
        return json_encode($result);
    }

    /**
     * Extrai JSON do output do Gemini
     * @param string $output
     * @param array $transactions
     * @return array
     */
    private function extractGeminiJsonOutput($output, $transactions)
    {
        // Try to extract just the JSON part
        $pattern = '/\[\s*\{.*?\}\s*\]/s';
        if (preg_match($pattern, $output, $matches)) {
            $jsonStr = $matches[0];
        } else {
            $jsonStr = $output; // Try with the full response
        }

        // Clean up and decode
        $jsonStr = preg_replace('/[\x00-\x1F\x7F]/u', '', $jsonStr);
        $decoded = json_decode($jsonStr, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            Log::error('Error decoding JSON from Gemini: ' . json_last_error_msg(), [
                'json_extract' => substr($jsonStr, 0, 500) . (strlen($jsonStr) > 500 ? '...' : '')
            ]);
            return [];
        }

        // Ensure we have categories for all transactions
        if (empty($decoded) || !is_array($decoded)) {
            Log::error('Invalid response format from Gemini (not an array)');
            return [];
        }

        // If we have fewer categories than transactions, fill with mock
        if (count($decoded) < count($transactions)) {
            Log::warning('Gemini returned fewer categories than transactions', [
                'expected' => count($transactions),
                'received' => count($decoded)
            ]);
            
            // Fill the rest with default categories
            $mockResponse = $this->getMockAIResponse(array_slice($transactions, count($decoded)));
            $decoded = array_merge($decoded, $mockResponse);
        }

        return $decoded;
    }

    /**
     * Método específico para análise com xAI Grok

    /**
     * Extrai transações de arquivos OFX
     */
    protected function extractTransactionsFromOFX($filePath)
    {
        $transactions = [];
        try {
            $fullPath = storage_path('app/' . $filePath);
            if (!Storage::disk('local')->exists($filePath)) { // Usar Storage facade corretamente
                Log::error('Arquivo OFX não encontrado no storage', ['path' => $filePath, 'fullPath' => $fullPath]);
                throw new \Exception("Arquivo OFX não encontrado: " . $filePath);
            }
            
            // Ler conteúdo do arquivo usando Storage
            $content = Storage::disk('local')->get($filePath);
            if (empty($content)) {
                Log::error('Arquivo OFX vazio', ['path' => $filePath]);
                return [];
            }

            // **** NOVO: Detectar e converter encoding para UTF-8 ****
            $encoding = mb_detect_encoding($content, ['UTF-8', 'ISO-8859-1', 'Windows-1252'], true);
            if ($encoding && $encoding !== 'UTF-8') {
                $content = mb_convert_encoding($content, 'UTF-8', $encoding);
                Log::info('Convertido encoding de OFX para UTF-8', ['original' => $encoding, 'path' => $filePath]);
            } elseif (!$encoding) {
                 Log::warning('Não foi possível detectar o encoding do arquivo OFX. Tentando continuar com o conteúdo original.', ['path' => $filePath]);
            }
            // **** FIM DA ADIÇÃO ****

            // Pré-processamento: remover padrões de colchetes em datas (ex: [0:GMT])
            $content = preg_replace('/\[.*?\]/', '', $content);

            // Tentar usar a biblioteca Endeken\OFX se disponível (melhor que regex)
            if (class_exists(\Endeken\OFX\OFX::class)) {
                 Log::info('Usando biblioteca Endeken\\OFX para parse', ['path' => $filePath]);
                try {
                    // Chamar o método estático parse() ao invés de instanciar a classe
                    $ofxData = \Endeken\OFX\OFX::parse($content);
                    
                    if ($ofxData === null) {
                        throw new \Exception("Falha ao parsear OFX: retornou null");
                    }
                    
                    // Iterar sobre as contas no arquivo OFX
                    foreach ($ofxData->bankAccounts as $bankAccount) {
                        $statement = $bankAccount->statement;
                        Log::info('Processando conta OFX', ['bankId' => $bankAccount->routingNumber, 'accountId' => $bankAccount->accountNumber, 'transacoes' => count($statement->transactions)]);

                        foreach ($statement->transactions as $ofxTransaction) {
                            $transaction = [];
                            $transaction['date'] = $ofxTransaction->date->format('Y-m-d');
                            $transaction['amount'] = (float) $ofxTransaction->amount; // Valor já vem como float
                            
                            // **** APLICAR utf8_decode AQUI ****
                            $rawDescription = trim($ofxTransaction->memo ?: $ofxTransaction->name ?: 'Sem descrição');
                            $transaction['description'] = utf8_decode($rawDescription); // Tentar corrigir double encoding
                            // **** FIM DA ALTERAÇÃO ****
                            
                            $transaction['type'] = $transaction['amount'] >= 0 ? 'income' : 'expense';
                             // A biblioteca já deve retornar o valor com sinal correto
                             // Se type for income, amount deve ser positivo. Se expense, negativo.
                             // Ajustar para guardar valor absoluto e type correto?
                            $transaction['amount'] = abs($transaction['amount']); // Guardar sempre positivo? Verificar saveTransactions

                            // Outros campos úteis se disponíveis:
                            // $transaction['uniqueId'] = $ofxTransaction->uniqueId; 
                            // $transaction['checkNumber'] = $ofxTransaction->checkNumber;
                            
                            $transactions[] = $transaction;
                        }
                    }
                    Log::info('Parse OFX com biblioteca concluído', ['total_transacoes' => count($transactions)]);
                    return $transactions;

                } catch (\Exception $e) {
                     Log::error('Erro ao parsear OFX com biblioteca Endeken\\OFX', [
                        'path' => $filePath, 'message' => $e->getMessage(), 'trace' => $e->getTraceAsString()
                    ]);
                    // Fallback para regex se a biblioteca falhar? Ou retornar erro?
                    // Por segurança, retornar array vazio em caso de erro no parse.
                    return []; 
                }
            } else {
                 Log::warning('Biblioteca Endeken\\OFX não encontrada, usando fallback regex (menos confiável)');
                // Fallback para Regex (lógica original, menos robusta)
                $content = preg_replace('/[\r\n\t]+/', ' ', $content);
                $content = preg_replace('/\s+/', ' ', $content);

                if (preg_match_all('/<STMTTRN>(.*?)<\/STMTTRN>/si', $content, $matches)) {
                    foreach ($matches[1] as $transactionContent) {
                        $transaction = [];
                        if (preg_match('/<DTPOSTED>(\d{8})/', $transactionContent, $dateMatch)) {
                            $transaction['date'] = substr($dateMatch[1], 0, 4) . '-' . substr($dateMatch[1], 4, 2) . '-' . substr($dateMatch[1], 6, 2);
                        }
                        if (preg_match('/<TRNAMT>([-\d\.]+)/', $transactionContent, $amountMatch)) {
                            $transaction['amount'] = (float) str_replace(',', '.', $amountMatch[1]);
                        }
                        if (preg_match('/<MEMO>(.*?)<\//si', $transactionContent, $memoMatch)) {
                            $transaction['description'] = trim($memoMatch[1]);
                        } elseif (preg_match('/<NAME>(.*?)<\//si', $transactionContent, $nameMatch)) { // Adicionar fallback NAME
                            $transaction['description'] = trim($nameMatch[1]);
                        } else {
                             $transaction['description'] = 'Sem descrição';
                        }

                        if (isset($transaction['date']) && isset($transaction['amount'])) {
                             $transaction['type'] = $transaction['amount'] >= 0 ? 'income' : 'expense';
                             $transaction['amount'] = abs($transaction['amount']); // Guardar absoluto?
                            $transactions[] = $transaction;
                        }
                    }
                }
            }
        } catch (\Exception $e) {
             Log::error("Erro GERAL ao extrair de OFX", [
                'path' => $filePath ?? 'N/A', 'message' => $e->getMessage(), 'trace' => $e->getTraceAsString()
            ]);
        }
        return $transactions;
    }

    /**
     * Analisa as transações e sugere categorias
     */
    private function analyzeTransactions($transactions)
    {
        $analysis = [
            'income' => [],
            'expense' => [],
            'total' => count($transactions)
        ];

        foreach ($transactions as $transaction) {
            $analysis[$transaction['type']][] = $transaction;
        }

        // Contagem de categorias
        $categoryCounts = [
            'income' => count($analysis['income']),
            'expense' => count($analysis['expense'])
        ];

        return [
            'income' => $analysis['income'],
            'expense' => $analysis['expense'],
            'total' => $analysis['total'],
            'category_counts' => $categoryCounts
        ];
    }

    /**
     * Extrai transações de um arquivo CSV
     */
    private function extractTransactionsFromCSV($path)
    {
        $transactions = [];
        try {
            if (!Storage::disk('local')->exists($path)) {
                 Log::error('Arquivo CSV não encontrado no storage', ['path' => $path]);
                throw new \Exception("Arquivo CSV não encontrado: " . $path);
            }
            $content = Storage::disk('local')->get($path);
            
            // Detectar encoding (simples)
            $encoding = mb_detect_encoding($content, ['UTF-8', 'ISO-8859-1', 'Windows-1252'], true);
            if ($encoding && $encoding !== 'UTF-8') {
                $content = mb_convert_encoding($content, 'UTF-8', $encoding);
                 Log::info('Convertido encoding de CSV para UTF-8', ['original' => $encoding]);
            }

            // Normalizar quebras de linha
            $content = str_replace(["\r\n", "\r"], "\n", $content);
            $lines = explode("\n", trim($content));

            if (empty($lines)) return [];

            // Heurística para detectar delimitador e cabeçalho
            $delimiters = [';', ',', '\t', '|'];
            $bestDelimiter = ',';
            $maxCols = 0;

            // Tentar detectar delimitador na primeira linha (ou segunda se a primeira for cabeçalho)
            $sampleLine = count($lines) > 1 ? $lines[1] : $lines[0]; // Usa segunda linha se existir
            foreach ($delimiters as $d) {
                $cols = substr_count($sampleLine, $d);
                if ($cols > $maxCols) {
                    $maxCols = $cols;
                    $bestDelimiter = $d;
                }
            }
             Log::info('Delimitador CSV detectado', ['delimiter' => $bestDelimiter == '\t' ? 'TAB' : $bestDelimiter]);

            // Remover cabeçalho se parecer um (não contém números formatados como moeda)
             $firstLineData = str_getcsv($lines[0], $bestDelimiter);
            $isHeader = true;
            foreach($firstLineData as $field) {
                if(preg_match('/^\s*-?[\d,.]+\s*$/', trim($field))) { // Verifica se campo contém apenas número/moeda
                    $isHeader = false; 
                    break;
                }
            }
            if ($isHeader && count($lines) > 1) {
                 Log::info('Cabeçalho CSV detectado e removido', ['header' => $lines[0]]);
                array_shift($lines);
            } else {
                 Log::info('Não foi detectado cabeçalho CSV ou arquivo tem apenas uma linha');
            }
            
            // Mapeamento de colunas (tentativa automática)
            $dateCol = -1; $descCol = -1; $amountCol = -1; $typeCol = -1;
            if ($isHeader) {
                 $headerFields = array_map('trim', array_map('strtolower', $firstLineData));
                 // Procurar por nomes comuns
                $dateKeywords = ['data', 'date'];
                $descKeywords = ['descricao', 'descrição', 'description', 'historico', 'histórico', 'memo'];
                $amountKeywords = ['valor', 'montante', 'amount', 'value', 'crédito', 'débito']; // Pode ser ambíguo
                $creditKeywords = ['credito', 'crédito', 'credit'];
                $debitKeywords = ['debito', 'débito', 'debit'];

                 foreach($headerFields as $index => $field) {
                     if ($dateCol == -1 && in_array($field, $dateKeywords)) $dateCol = $index;
                     if ($descCol == -1 && in_array($field, $descKeywords)) $descCol = $index;
                     // Se houver colunas separadas para crédito/débito
                     if ($amountCol == -1 && in_array($field, $creditKeywords)) { $amountCol = $index; $typeCol = 'credit'; }
                     if ($amountCol == -1 && in_array($field, $debitKeywords)) { $amountCol = $index; $typeCol = 'debit'; }
                     // Se houver coluna única de valor
                     if ($amountCol == -1 && in_array($field, $amountKeywords)) $amountCol = $index;
                 }
            }

            // Se não conseguiu mapear pelo header, tenta por posição (suposição)
            if ($dateCol == -1) $dateCol = 0;
            if ($descCol == -1) $descCol = 1;
            if ($amountCol == -1) $amountCol = $maxCols; // Última coluna
            
            Log::info('Mapeamento de colunas CSV', ['date' => $dateCol, 'desc' => $descCol, 'amount' => $amountCol, 'typeLogic' => $typeCol]);

            foreach ($lines as $index => $line) {
                if (empty(trim($line))) continue;
                
                $fields = str_getcsv($line, $bestDelimiter);
                if (count($fields) <= max($dateCol, $descCol, $amountCol)) continue; // Pular linhas mal formatadas

                try {
                    $dateStr = $fields[$dateCol] ?? '';
                    $description = trim($fields[$descCol] ?? 'Sem descrição');
                    $amountStr = $fields[$amountCol] ?? '0';

                    // Limpar e converter valor
                    $amountStr = preg_replace('/[^\d,\.\-]/', '', $amountStr); // Permitir sinal negativo
                    $amountStr = str_replace('.', '', $amountStr); // Remover separador de milhar (ponto)
                    $amountStr = str_replace(',', '.', $amountStr); // Trocar vírgula decimal por ponto
                    $amount = (float) $amountStr;

                    // Formatar data
                    $date = $this->formatDate($dateStr); // Usa o método formatDate já existente

                    // Determinar tipo
                    $type = 'expense'; // Padrão
                     if ($typeCol == 'credit' && $amount > 0) { // Coluna de crédito específica
                         $type = 'income';
                     } elseif ($typeCol == 'debit' && $amount > 0) { // Coluna de débito específica (valor absoluto)
                         $type = 'expense';
                         // $amount = -$amount; // Guardar negativo? Não, usar 'type'
                     } elseif ($typeCol == -1) { // Coluna única de valor
                         $type = ($amount >= 0) ? 'income' : 'expense';
                         // $amount = abs($amount); // Guardar absoluto? Sim, se usar type
                     }
                     $amount = abs($amount); // Guardar sempre valor absoluto

                    $transactions[] = [
                        'date' => $date,
                        'description' => $description ?: 'Sem descrição',
                        'amount' => $amount, // Valor absoluto
                        'type' => $type
                    ];
                } catch(\Exception $e) {
                    Log::warning('Erro ao processar linha CSV', ['linha_num' => $index + ($isHeader ? 2 : 1), 'linha' => $line, 'erro' => $e->getMessage()]);
                }
            }
            
             Log::info('Extração CSV concluída', ['total_transacoes' => count($transactions)]);
            return $transactions;

        } catch (\Exception $e) {
            Log::error('Erro GERAL ao extrair transações do arquivo CSV', ['path' => $path, 'message' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);
            return [];
        }
    }
    
    /**
     * Formata diferentes formatos de data para o padrão ISO (Y-m-d)
     */
    private function formatDate($dateStr)
    {
        // Formatos comuns no Brasil: dd/mm/yyyy ou dd-mm-yyyy
        if (preg_match('/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})$/', $dateStr, $matches)) {
            $day = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
            $month = str_pad($matches[2], 2, '0', STR_PAD_LEFT);
            $year = $matches[3];
            
            // Se ano com 2 dígitos, assumir 2000+
            if (strlen($year) == 2) {
                $year = '20' . $year;
            }
            
            return "$year-$month-$day";
        }
        
        // Formato ISO: yyyy-mm-dd
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $dateStr)) {
            return $dateStr;
        }
        
        // Outros formatos: tenta converter com DateTime
        try {
            $date = new DateTime($dateStr);
            return $date->format('Y-m-d');
        } catch (\Exception $e) {
            // Se falhar, retorna a data atual
            return date('Y-m-d');
        }
    }
    
    /**
     * Detecta o tipo de transação (receita/despesa) com base no valor e na descrição
     * 
     * @param float $amount Valor da transação
     * @param string $description Descrição da transação
     * @return string 'income' ou 'expense'
     */
    private function detectTransactionType($amount, $description)
    {
        // Normaliza a descrição (remove acentos, converte para minúsculas)
        $normalizedDesc = mb_strtolower($description, 'UTF-8');
        
        // Palavras-chave comuns em despesas
        $expenseKeywords = [
            'compra', 'pagamento', 'debito', 'débito', 'saque', 'tarifa', 'taxa',
            'fatura', 'boleto', 'conta', 'supermercado', 'mercado', 'farmacia', 'farmácia',
            'restaurante', 'uber', '99', 'ifood', 'netflix', 'spotify', 'amazon',
            'combustivel', 'combustível', 'posto', 'estacionamento', 'pedágio', 'pedagio',
            'pix enviado', 'pix para', 'transferencia para', 'transferência para'
        ];
        
        // Palavras-chave comuns em receitas
        $incomeKeywords = [
            'salario', 'salário', 'pagto', 'pgto', 'deposito', 'depósito', 'credito', 'crédito',
            'reembolso', 'rendimento', 'juros', 'dividendo', 'lucro', 'prêmio', 'premio',
            'pix recebido', 'pix de', 'transferencia de', 'transferência de', 'ted de', 'doc de'
        ];
        
        // Verifica se a descrição contém alguma palavra-chave de despesa
        foreach ($expenseKeywords as $keyword) {
            if (strpos($normalizedDesc, $keyword) !== false) {
                return 'expense';
            }
        }
        
        // Verifica se a descrição contém alguma palavra-chave de receita
        foreach ($incomeKeywords as $keyword) {
            if (strpos($normalizedDesc, $keyword) !== false) {
                return 'income';
            }
        }
        
        // Se não encontrou palavras-chave, usa o valor como critério
        // Valores negativos são despesas, positivos são receitas
        return ($amount < 0) ? 'expense' : 'income';
    }
    
    /**
     * Retorna transações de exemplo para teste
     */
    private function getExampleTransactions()
    {
        // Dados de exemplo para teste
        return [
            [
                'date' => date('Y-m-d', strtotime('-3 days')),
                'description' => 'Exemplo: Salário',
                'amount' => 3500.00,
                'type' => 'income'
            ],
            [
                'date' => date('Y-m-d', strtotime('-2 days')),
                'description' => 'Exemplo: Supermercado',
                'amount' => 250.75,
                'type' => 'expense'
            ],
            [
                'date' => date('Y-m-d', strtotime('-1 day')),
                'description' => 'Exemplo: Assinatura Streaming',
                'amount' => 39.90,
                'type' => 'expense'
            ],
            [
                'date' => date('Y-m-d'),
                'description' => 'Exemplo: PIX Recebido',
                'amount' => 100.00,
                'type' => 'income'
            ]
        ];
    }
    
    /**
     * Salva as transações importadas no banco de dados
     */
    public function saveTransactions(Request $request)
    {
        // Validar os dados enviados
         $validator = Validator::make($request->all(), [
            'account_id' => 'required|exists:accounts,id',
            'file_path' => 'required|string', // Path do arquivo temporário
            'transactions' => 'required|array',
            'transactions.*.date' => 'required|date_format:Y-m-d', // Garantir formato
            'transactions.*.description' => 'required|string|max:255',
            'transactions.*.amount' => 'required|numeric', // Validar como numérico
            'transactions.*.type' => 'required|in:income,expense',
            'transactions.*.category_id' => ['nullable', function ($attribute, $value, $fail) {
                if ($value === null || $value === '') {
                    return; // Null é permitido
                }
                if (is_string($value) && strpos($value, 'new_') === 0) {
                    return; // Nova categoria é permitida
                }
                if (!is_numeric($value) || !Category::where('id', $value)->where('user_id', auth()->id())->exists()) {
                    $fail("A categoria selecionada ($value) é inválida para o campo $attribute.");
                }
            }],
            'transactions.*.suggested_category' => 'nullable|string|max:100' // Nome da nova categoria sugerida
        ]);

        if ($validator->fails()) {
             Log::error('Validação falhou ao salvar transações', ['errors' => $validator->errors()->all()]);
             // Retornar JSON para requisição AJAX
             if ($request->wantsJson()) {
                 return response()->json(['success' => false, 'message' => $validator->errors()->first(), 'errors' => $validator->errors()], 422);
             }
            // Fallback para requisição não-AJAX (manter redirect?)
            return redirect()->back() 
                    ->withErrors($validator)
                    ->withInput(); 
        }
        
        $account = Account::findOrFail($request->account_id);
        if ($account->user_id !== auth()->id()) {
             Log::warning('Tentativa de salvar transações em conta não autorizada', ['user_id' => auth()->id(), 'account_id' => $request->account_id]);
             if ($request->wantsJson()) {
                 return response()->json(['success' => false, 'message' => 'Acesso não autorizado.'], 403);
             }
            abort(403, 'Você não tem permissão para salvar transações nesta conta.');
        }
        
        Log::info('💾 Iniciando salvamento de transações importadas', [
            'conta' => $account->name,
            'total_transacoes_recebidas' => count($request->transactions),
            'file_path' => $request->file_path,
            'is_ajax' => $request->wantsJson()
        ]);
        
        DB::beginTransaction();
        
        try {
            $savedCount = 0;
            $failedCount = 0;
            $createdCategoryIds = []; // Rastrear novas categorias criadas
            
            foreach ($request->transactions as $index => $transactionData) {
                try {
                    $transactionData = array_merge([
                        'date' => null, 'description' => null, 'amount' => 0, 
                        'type' => null, 'category_id' => null, 'suggested_category' => null
                    ], $transactionData);

                    $amount = (float) $transactionData['amount'];
                    $amountCents = (int) round($amount * 100);
                    $amountCents = abs($amountCents); // Assumindo que o banco guarda valor absoluto

                    $transaction = new Transaction();
                    $transaction->user_id = auth()->id();
                    $transaction->account_id = $account->id;
                    $transaction->date = $transactionData['date'];
                    $transaction->description = $transactionData['description'];
                    $transaction->amount = $amountCents; 
                    $transaction->type = $transactionData['type'];
                    $transaction->status = 'paid'; // Definir status como pago
                    
                    // Processar e limpar os campos de cliente e fornecedor para garantir que contenham apenas os nomes
                    if (!empty($transactionData['cliente'])) {
                        // Salvar original para log
                        $transactionData['_cliente_original'] = $transactionData['cliente'];
                        
                        // Padrões comuns de descrições de transações nas descrições de clientes
                        $descriptionPatterns = [
                            '/^(recebida|recebido|transferência recebida|transferencia recebida|pix recebido|recebimento)\s*(de|via|pelo|por|do)?\s*(pix|ted|doc|transferência|transferencia|cartão|cartao)?\s*(-|:|\s+)/i',
                            '/^(pagamento|pix|ted|doc)\s*(recebido|recebida)?\s*(-|:|\s+)/i',
                            '/^(compra|venda|pagamento|crédito|credito)\s*(aprovada|aprovado|cancelada|cancelado|estornada|estornado)?\s*(-|:|\s+)/i'
                        ];
                        
                        $hasDescriptionPrefix = false;
                        foreach ($descriptionPatterns as $pattern) {
                            if (preg_match($pattern, $transactionData['cliente'], $matches)) {
                                $hasDescriptionPrefix = true;
                                $prefix = trim($matches[0]);
                                
                                // Extrair descrição e nome
                                $remainingText = trim(substr($transactionData['cliente'], strlen($prefix)));
                                
                                // Adicionar prefixo às notas
                                $descriptionForNotes = trim(rtrim($prefix, '-: '));
                                if (!empty($descriptionForNotes)) {
                                    if (empty($transactionData['notes'])) {
                                        $transactionData['notes'] = $descriptionForNotes;
                                    } else if (strpos($transactionData['notes'], $descriptionForNotes) === false) {
                                        $transactionData['notes'] = $descriptionForNotes . ' | ' . $transactionData['notes'];
                                    }
                                }
                                
                                // Atualizar campo cliente para conter apenas o nome
                                $transactionData['cliente'] = $remainingText;
                                break;
                            }
                        }
                        
                        // Se não encontrou um padrão comum, tentar o padrão genérico com " - "
                        if (!$hasDescriptionPrefix && strpos($transactionData['cliente'], ' - ') !== false) {
                            $parts = explode(' - ', $transactionData['cliente'], 2);
                            
                            // Verificar se a primeira parte parece uma descrição de transação
                            $firstPartLower = strtolower($parts[0]);
                            if (strpos($firstPartLower, 'pix') !== false || 
                                strpos($firstPartLower, 'transferência') !== false || 
                                strpos($firstPartLower, 'transferencia') !== false || 
                                strpos($firstPartLower, 'receb') !== false || 
                                strpos($firstPartLower, 'pagamento') !== false) {
                                
                                // Adicionar a primeira parte às notas se parecer uma descrição
                                if (empty($transactionData['notes'])) {
                                    $transactionData['notes'] = trim($parts[0]);
                                } else if (strpos($transactionData['notes'], $parts[0]) === false) {
                                    $transactionData['notes'] = trim($parts[0]) . ' | ' . $transactionData['notes'];
                                }
                                
                                // Segunda parte é o nome do cliente
                                $transactionData['cliente'] = trim($parts[1]);
                            }
                        }
                        
                        // Limpar caracteres indesejados e espaços extras
                        $transactionData['cliente'] = trim(preg_replace('/\s+/', ' ', $transactionData['cliente']));
                    }
                    
                    if (!empty($transactionData['fornecedor'])) {
                        // Salvar original para log
                        $transactionData['_fornecedor_original'] = $transactionData['fornecedor'];
                        
                        // Padrões comuns de descrições de transações para fornecedores
                        $descriptionPatterns = [
                            '/^(enviada|enviado|transferência enviada|transferencia enviada|pix enviado|pagamento)\s*(para|via|pelo|por|do)?\s*(pix|ted|doc|transferência|transferencia|cartão|cartao)?\s*(-|:|\s+)/i',
                            '/^(pagamento|compra|pix|ted|doc)\s*(enviado|enviada|realizado|realizada)?\s*(-|:|\s+)/i',
                            '/^(compra|débito|debito|saque)\s*(em|no|na|pelo|com)?\s*(-|:|\s+)/i'
                        ];
                        
                        $hasDescriptionPrefix = false;
                        foreach ($descriptionPatterns as $pattern) {
                            if (preg_match($pattern, $transactionData['fornecedor'], $matches)) {
                                $hasDescriptionPrefix = true;
                                $prefix = trim($matches[0]);
                                
                                // Extrair descrição e nome
                                $remainingText = trim(substr($transactionData['fornecedor'], strlen($prefix)));
                                
                                // Adicionar prefixo às notas
                                $descriptionForNotes = trim(rtrim($prefix, '-: '));
                                if (!empty($descriptionForNotes)) {
                                    if (empty($transactionData['notes'])) {
                                        $transactionData['notes'] = $descriptionForNotes;
                                    } else if (strpos($transactionData['notes'], $descriptionForNotes) === false) {
                                        $transactionData['notes'] = $descriptionForNotes . ' | ' . $transactionData['notes'];
                                    }
                                }
                                
                                // Atualizar campo fornecedor para conter apenas o nome
                                $transactionData['fornecedor'] = $remainingText;
                                break;
                            }
                        }
                        
                        // Se não encontrou um padrão comum, tentar o padrão genérico com " - "
                        if (!$hasDescriptionPrefix && strpos($transactionData['fornecedor'], ' - ') !== false) {
                            $parts = explode(' - ', $transactionData['fornecedor'], 2);
                            
                            // Verificar se a primeira parte parece uma descrição de transação
                            $firstPartLower = strtolower($parts[0]);
                            if (strpos($firstPartLower, 'pix') !== false || 
                                strpos($firstPartLower, 'transferência') !== false || 
                                strpos($firstPartLower, 'transferencia') !== false || 
                                strpos($firstPartLower, 'pagamento') !== false || 
                                strpos($firstPartLower, 'compra') !== false) {
                                
                                // Adicionar a primeira parte às notas se parecer uma descrição
                                if (empty($transactionData['notes'])) {
                                    $transactionData['notes'] = trim($parts[0]);
                                } else if (strpos($transactionData['notes'], $parts[0]) === false) {
                                    $transactionData['notes'] = trim($parts[0]) . ' | ' . $transactionData['notes'];
                                }
                                
                                // Segunda parte é o nome do fornecedor
                                $transactionData['fornecedor'] = trim($parts[1]);
                            }
                        }
                        
                        // Limpar caracteres indesejados e espaços extras
                        $transactionData['fornecedor'] = trim(preg_replace('/\s+/', ' ', $transactionData['fornecedor']));
                    }
                    
                    // Garantir que informações de transação não estão nos nomes
                    if (!empty($transactionData['cliente'])) {
                        $transactionData['cliente'] = trim($transactionData['cliente'], " \t\n\r\0\x0B-");
                    }
                    
                    if (!empty($transactionData['fornecedor'])) {
                        $transactionData['fornecedor'] = trim($transactionData['fornecedor'], " \t\n\r\0\x0B-");
                    }
                    
                    // Log de dados processados para depuração
                    Log::debug('💾 Transação processada antes de salvar', [
                        'index' => $index,
                        'cliente_original' => isset($transactionData['_cliente_original']) ? $transactionData['_cliente_original'] : 'N/A',
                        'cliente_processado' => $transactionData['cliente'] ?? 'null',
                        'fornecedor_original' => isset($transactionData['_fornecedor_original']) ? $transactionData['_fornecedor_original'] : 'N/A',
                        'fornecedor_processado' => $transactionData['fornecedor'] ?? 'null',
                        'notes' => $transactionData['notes'] ?? 'null'
                    ]);
                    
                    // Salvar os campos adicionais de cliente, fornecedor e notes
                    $transaction->cliente = $transactionData['cliente'] ?? null;
                    $transaction->fornecedor = $transactionData['fornecedor'] ?? null;
                    $transaction->notes = $transactionData['notes'] ?? null;
                    
                    $categoryId = $transactionData['category_id'];
                    $newCategoryCreated = false;
                    if ($categoryId !== null && $categoryId !== '') {
                        if (is_string($categoryId) && strpos($categoryId, 'new_') === 0) {
                            $categoryName = $transactionData['suggested_category'] ?? null;
                            if (empty($categoryName)) {
                                 $categoryName = str_replace('_', ' ', substr($categoryId, 4));
                            }
                            $categoryName = trim(ucfirst($categoryName));

                            if (!empty($categoryName)) {
                                $existingCategory = Category::firstOrCreate(
                                    [
                                        'user_id' => auth()->id(),
                                        'name' => $categoryName,
                                        'type' => $transactionData['type']
                                    ],
                                    [
                                        'system' => false 
                                    ]
                                );
                                $transaction->category_id = $existingCategory->id;
                                if($existingCategory->wasRecentlyCreated) {
                                     $newCategoryCreated = true;
                                     $createdCategoryIds[] = $existingCategory->id;
                                }
                                Log::info('Usando/Criando categoria', [
                                    'id' => $existingCategory->id, 'nome' => $categoryName, 'tipo' => $transactionData['type'], 'nova' => $newCategoryCreated
                                ]);
                            } else {
                                 Log::warning('Nome de categoria sugerida vazio', ['index' => $index]);
                                $transaction->category_id = null;
                            }
                        } else {
                            $transaction->category_id = $categoryId;
                        }
                    } else {
                         $transaction->category_id = null;
                    }
                    
                    $transaction->save();
                    $savedCount++;
                    
                } catch (\Exception $e) {
                    $failedCount++;
                    Log::error('Erro ao salvar transação individual', [
                        'index' => $index,
                        'message' => $e->getMessage(),
                        'trace_preview' => substr($e->getTraceAsString(), 0, 500), // Limitar trace no log
                        'transaction_data' => $transactionData 
                    ]);
                }
            }
            
            $filePathToDelete = $request->file_path;
            if (Storage::exists($filePathToDelete)) {
                Storage::delete($filePathToDelete);
                 Log::info('Arquivo temporário deletado', ['path' => $filePathToDelete]);
            } else {
                 Log::warning('Arquivo temporário não encontrado para deletar', ['path' => $filePathToDelete]);
            }
            
            DB::commit();
            
            Log::info('✅ Importação concluída com sucesso', [
                'transacoes_salvas' => $savedCount,
                'transacoes_falhas' => $failedCount,
                'novas_categorias' => count($createdCategoryIds)
            ]);
            
            $message = "Importação concluída! {$savedCount} transações foram importadas.";
            if ($failedCount > 0) {
                 $message .= " {$failedCount} transações apresentaram erro.";
                 $status = 'warning';
            } else {
                 $status = 'success';
            }
            
            // Retornar JSON para AJAX ou Redirect para requisição normal
            if ($request->wantsJson()) {
                 return response()->json([
                     'success' => true,
                     'message' => $message,
                     'status' => $status, // 'success' ou 'warning'
                     'redirect_url' => route('transactions.index') // Informar URL para JS
                 ]);
            }

            return redirect()->route('transactions.index')->with($status, $message);
            
        } catch (\Exception $e) {
            DB::rollBack();
            
            Log::error('Erro GERAL ao processar importação (rollback)', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            $errorMessage = 'Erro geral ao salvar as transações: ' . $e->getMessage();
             if ($request->wantsJson()) {
                 return response()->json(['success' => false, 'message' => $errorMessage], 500);
             }
             
            return redirect()->back()
                ->with('error', $errorMessage)
                ->withInput();
        }
    }

    /**
     * Aplica a categorização da IA às transações extraídas
     * @param array $transactions Transações extraídas do arquivo
     * @param array|null $aiAnalysisResult Resultado da análise da IA
     * @return array Transações com categorias aplicadas
     */
    private function applyCategorizationToTransactions(array $transactions, ?array $aiAnalysisResult): array
    {
        if (empty($aiAnalysisResult) || !isset($aiAnalysisResult['transactions']) || !is_array($aiAnalysisResult['transactions'])) {
            Log::info('Nenhum resultado de análise IA para aplicar.');
            // Retorna as transações originais sem modificação de categoria
            return $transactions;
        }

        Log::info('Aplicando categorização da IA', [
            'transacoes_originais' => count($transactions),
            'resultados_ia' => count($aiAnalysisResult['transactions'])
        ]);

        // Mapear resultados da IA por ID para acesso rápido
        $aiMap = [];
        foreach ($aiAnalysisResult['transactions'] as $analyzed) { 
             if (isset($analyzed['id'])) { // Usa o ID que a IA retornou (deve ser o índice original)
                 $aiMap[$analyzed['id']] = $analyzed;
             }
        }

        // Iterar sobre as transações extraídas e aplicar dados da IA
        foreach ($transactions as $index => &$transaction) { // Usar referência (&) para modificar diretamente
            if (isset($aiMap[$index])) {
                $aiData = $aiMap[$index];
                
                // Aplicar tipo sugerido pela IA se diferente e válido
                if (isset($transaction['type']) && isset($aiData['type']) && in_array($aiData['type'], ['income', 'expense']) && $aiData['type'] !== $transaction['type']) {
                     Log::debug('Atualizando tipo da transação via IA', ['index' => $index, 'original' => $transaction['type'], 'novo' => $aiData['type']]);
                    $transaction['type'] = $aiData['type'];
                } elseif (!isset($transaction['type'])) {
                    Log::warning('Chave [type] ausente na transação original ao aplicar categorização IA.', ['index' => $index, 'transaction_data' => $transaction]);
                }
                
                // Aplicar category_id sugerido pela IA (pode ser null)
                 $transaction['category_id'] = $aiData['category_id'] ?? null;
                 
                 // Aplicar suggested_category (nome para nova categoria)
                 $transaction['suggested_category'] = $aiData['suggested_category'] ?? null;
                 
                 // Aplicar campos adicionais de cliente, fornecedor e notes
                 $transaction['cliente'] = $aiData['cliente'] ?? null;
                 $transaction['fornecedor'] = $aiData['fornecedor'] ?? null;
                 $transaction['notes'] = $aiData['notes'] ?? null;

                 // Logar aplicação
                 if ($transaction['category_id'] || $transaction['suggested_category']) {
                     Log::debug('Categoria IA aplicada', [
                         'index' => $index, 
                         'category_id' => $transaction['category_id'], 
                         'suggested' => $transaction['suggested_category']
                     ]);
                 }
            } else {
                 Log::warning('Resultado da IA não encontrado para transação', ['index' => $index]);
                 // Manter transação sem categoria ou com tipo original
                 $transaction['category_id'] = null;
                 $transaction['suggested_category'] = null;
            }
        }
        unset($transaction); // Quebrar referência do loop

        return $transactions;
    }

    /**
     * Testa a API Gemini com uma consulta simples
     */
    public function testGeminiAPI()
    {
        if (!Auth::check()) {
            return response()->json(['error' => 'Unauthenticated. Please log in.'], 401);
        }
        $apiKey = env('GEMINI_API_KEY');
        Log::debug('Usando API Key mascarada: ' . substr($apiKey, 0, 5) . '*****');
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=' . $apiKey;
        Log::debug('URL de requisição: ' . $url);
        $prompt = "Teste simples: responda com 'OK' se você está funcionando.";
        $response = Http::withHeaders(['Content-Type' => 'application/json'])->post($url, [
            'contents' => [
                ['parts' => [['text' => $prompt]]]
            ]
        ]);
        Log::info('Resposta da API Gemini: ' . $response->body());
        return response()->json(['status' => 'Test completed', 'response' => $response->json()]);
    }

    /**
     * Testa a API Gemini com uma transação de exemplo
     */
    public function testGeminiAPIWithTransactions()
    {
        // Verificar se o usuário está autenticado
        if (!auth()->check()) {
            return response()->json(['error' => 'Unauthenticated. Please log in.'], 401);
        }
        
        // Verificar se o usuário é admin
        if (!auth()->user()->isAdmin()) {
            return redirect()->back()->with('error', 'Acesso não autorizado.');
        }
        
        // Obter transações de exemplo para teste
        $transactions = $this->getExampleTransactions();
        
        try {
            // Obter configuração da IA do banco de dados
            $aiConfigService = new \App\Services\AIConfigService();
            $aiConfig = $aiConfigService->getAIConfig();
            
            if (!$aiConfigService->isAIConfigured()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Nenhuma IA configurada no banco de dados.',
                    'details' => ['provider' => null]
                ]);
            }
            
            // Log informações sobre a API
            $provider = $aiConfig['provider'] ?? 'desconhecido';
            $model = $aiConfig['model'] ?? 'desconhecido';
            $apiKey = $aiConfig['api_key'] ?? null;
            
            Log::debug('Teste de API: ' . $provider, [
                'model' => $model,
                'api_key_masked' => $apiKey ? substr($apiKey, 0, 5) . '*****' : 'não encontrada'
            ]);
            
            // Log de início do teste
            Log::info('🧪 TESTE DE IA INICIADO', [
                'provider' => $provider,
                'model' => $model,
                'total_transacoes' => count($transactions)
            ]);
            
            // Analisar transações com IA
            $result = $this->analyzeTransactionsWithAI($transactions);
            
            if (!$result || empty($result['transactions'])) {
                return response()->json([
                    'success' => false,
                    'message' => 'Não foi possível analisar as transações com a IA configurada.',
                    'details' => [
                        'provider' => $provider,
                        'model' => $model
                    ]
                ]);
            }
            
            // Preparar resultado para exibição
            $detailedResults = [];
            foreach ($result['transactions'] as $index => $transaction) {
                // Obter transação original correspondente
                $originalTransaction = $transactions[$transaction['id']] ?? null;
                
                if ($originalTransaction) {
                    // Aplicar a lógica de separação de descrição/cliente/fornecedor para cada transação
                    // para verificar como seria processada
                    $processedTransaction = $transaction;
                    
                    // Processar cliente se existir
                    if (!empty($transaction['cliente'])) {
                        $processedClient = $transaction['cliente'];
                        $descriptionPatterns = [
                            '/^(recebida|recebido|transferência recebida|transferencia recebida|pix recebido|recebimento)\s*(de|via|pelo|por|do)?\s*(pix|ted|doc|transferência|transferencia|cartão|cartao)?\s*(-|:|\s+)/i',
                            '/^(pagamento|pix|ted|doc)\s*(recebido|recebida)?\s*(-|:|\s+)/i',
                        ];
                        
                        $clientNotes = '';
                        foreach ($descriptionPatterns as $pattern) {
                            if (preg_match($pattern, $processedClient, $matches)) {
                                $prefix = trim($matches[0]);
                                $processedClient = trim(substr($processedClient, strlen($prefix)));
                                $clientNotes = trim(rtrim($prefix, '-: '));
                                break;
                            }
                        }
                        
                        if (empty($clientNotes) && strpos($transaction['cliente'], ' - ') !== false) {
                            $parts = explode(' - ', $transaction['cliente'], 2);
                            if (strpos(strtolower($parts[0]), 'pix') !== false || 
                                strpos(strtolower($parts[0]), 'transferência') !== false || 
                                strpos(strtolower($parts[0]), 'receb') !== false) {
                                $clientNotes = $parts[0];
                                $processedClient = $parts[1];
                            }
                        }
                        
                        $processedTransaction['_cliente_processed'] = trim($processedClient);
                        $processedTransaction['_cliente_notes'] = $clientNotes;
                    }
                    
                    // Processar fornecedor se existir
                    if (!empty($transaction['fornecedor'])) {
                        $processedVendor = $transaction['fornecedor'];
                        $descriptionPatterns = [
                            '/^(enviada|enviado|transferência enviada|transferencia enviada|pix enviado|pagamento)\s*(para|via|pelo|por|do)?\s*(pix|ted|doc|transferência|transferencia|cartão|cartao)?\s*(-|:|\s+)/i',
                            '/^(pagamento|compra|pix|ted|doc)\s*(enviado|enviada|realizado|realizada)?\s*(-|:|\s+)/i',
                        ];
                        
                        $vendorNotes = '';
                        foreach ($descriptionPatterns as $pattern) {
                            if (preg_match($pattern, $processedVendor, $matches)) {
                                $prefix = trim($matches[0]);
                                $processedVendor = trim(substr($processedVendor, strlen($prefix)));
                                $vendorNotes = trim(rtrim($prefix, '-: '));
                                break;
                            }
                        }
                        
                        if (empty($vendorNotes) && strpos($transaction['fornecedor'], ' - ') !== false) {
                            $parts = explode(' - ', $transaction['fornecedor'], 2);
                            if (strpos(strtolower($parts[0]), 'pix') !== false || 
                                strpos(strtolower($parts[0]), 'transferência') !== false || 
                                strpos(strtolower($parts[0]), 'pag') !== false) {
                                $vendorNotes = $parts[0];
                                $processedVendor = $parts[1];
                            }
                        }
                        
                        $processedTransaction['_fornecedor_processed'] = trim($processedVendor);
                        $processedTransaction['_fornecedor_notes'] = $vendorNotes;
                    }
                    
                    $detailedResults[] = [
                        'original' => $originalTransaction,
                        'ai_analysis' => $transaction,
                        'processed' => $processedTransaction
                    ];
                }
            }
            
            return response()->json([
                'success' => true,
                'message' => 'Análise com IA concluída com sucesso',
                'provider_details' => [
                    'provider' => $provider,
                    'model' => $model,
                ],
                'count' => count($result['transactions']),
                'detailed_results' => $detailedResults
            ]);
            
        } catch (\Exception $e) {
            Log::error('❌ Erro no teste de IA', [
                'mensagem' => $e->getMessage(),
                'arquivo' => $e->getFile(),
                'linha' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao testar a API: ' . $e->getMessage(),
                'details' => [
                    'file' => $e->getFile(),
                    'line' => $e->getLine()
                ]
            ], 500);
        }
    }

    /**
     * Testa a análise de transações com IA avançada
     */
    public function testAIAnalysis()
    {
        // Verificar se o usuário está autenticado
        if (!auth()->check()) {
            return response()->json(['error' => 'Unauthenticated. Please log in.'], 401);
        }
        
        // Verificar se o usuário é admin
        if (!auth()->user()->isAdmin()) {
            return redirect()->back()->with('error', 'Acesso não autorizado.');
        }
        
        // Obter transações de exemplo para teste
        $transactions = $this->getExampleTransactions();
        
        try {
            // Obter configuração da IA do banco de dados
            $aiConfigService = new \App\Services\AIConfigService();
            $aiConfig = $aiConfigService->getAIConfig();
            
            if (!$aiConfigService->isAIConfigured()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Nenhuma IA configurada no banco de dados.',
                    'details' => ['provider' => null]
                ]);
            }
            
            // Log informações sobre a API
            $provider = $aiConfig['provider'] ?? 'desconhecido';
            $model = $aiConfig['model'] ?? 'desconhecido';
            $apiKey = $aiConfig['api_key'] ?? null;
            
            Log::debug('Teste de API: ' . $provider, [
                'model' => $model,
                'api_key_masked' => $apiKey ? substr($apiKey, 0, 5) . '*****' : 'não encontrada'
            ]);
            
            // Log de início do teste
            Log::info('🧪 TESTE DE IA INICIADO', [
                'provider' => $provider,
                'model' => $model,
                'total_transacoes' => count($transactions)
            ]);
            
            // Analisar transações com IA
            $result = $this->analyzeTransactionsWithAI($transactions);
            
            if (!$result || empty($result['transactions'])) {
                return response()->json([
                    'success' => false,
                    'message' => 'Não foi possível analisar as transações com a IA configurada.',
                    'details' => [
                        'provider' => $provider,
                        'model' => $model
                    ]
                ]);
            }
            
            // Preparar resultado para exibição
            $detailedResults = [];
            foreach ($result['transactions'] as $index => $transaction) {
                // Obter transação original correspondente
                $originalTransaction = $transactions[$transaction['id']] ?? null;
                
                if ($originalTransaction) {
                    // Aplicar a lógica de separação de descrição/cliente/fornecedor para cada transação
                    // para verificar como seria processada
                    $processedTransaction = $transaction;
                    
                    // Processar cliente se existir
                    if (!empty($transaction['cliente'])) {
                        $processedClient = $transaction['cliente'];
                        $descriptionPatterns = [
                            '/^(recebida|recebido|transferência recebida|transferencia recebida|pix recebido|recebimento)\s*(de|via|pelo|por|do)?\s*(pix|ted|doc|transferência|transferencia|cartão|cartao)?\s*(-|:|\s+)/i',
                            '/^(pagamento|pix|ted|doc)\s*(recebido|recebida)?\s*(-|:|\s+)/i',
                        ];
                        
                        $clientNotes = '';
                        foreach ($descriptionPatterns as $pattern) {
                            if (preg_match($pattern, $processedClient, $matches)) {
                                $prefix = trim($matches[0]);
                                $processedClient = trim(substr($processedClient, strlen($prefix)));
                                $clientNotes = trim(rtrim($prefix, '-: '));
                                break;
                            }
                        }
                        
                        if (empty($clientNotes) && strpos($transaction['cliente'], ' - ') !== false) {
                            $parts = explode(' - ', $transaction['cliente'], 2);
                            if (strpos(strtolower($parts[0]), 'pix') !== false || 
                                strpos(strtolower($parts[0]), 'transferência') !== false || 
                                strpos(strtolower($parts[0]), 'receb') !== false) {
                                $clientNotes = $parts[0];
                                $processedClient = $parts[1];
                            }
                        }
                        
                        $processedTransaction['_cliente_processed'] = trim($processedClient);
                        $processedTransaction['_cliente_notes'] = $clientNotes;
                    }
                    
                    // Processar fornecedor se existir
                    if (!empty($transaction['fornecedor'])) {
                        $processedVendor = $transaction['fornecedor'];
                        $descriptionPatterns = [
                            '/^(enviada|enviado|transferência enviada|transferencia enviada|pix enviado|pagamento)\s*(para|via|pelo|por|do)?\s*(pix|ted|doc|transferência|transferencia|cartão|cartao)?\s*(-|:|\s+)/i',
                            '/^(pagamento|compra|pix|ted|doc)\s*(enviado|enviada|realizado|realizada)?\s*(-|:|\s+)/i',
                        ];
                        
                        $vendorNotes = '';
                        foreach ($descriptionPatterns as $pattern) {
                            if (preg_match($pattern, $processedVendor, $matches)) {
                                $prefix = trim($matches[0]);
                                $processedVendor = trim(substr($processedVendor, strlen($prefix)));
                                $vendorNotes = trim(rtrim($prefix, '-: '));
                                break;
                            }
                        }
                        
                        if (empty($vendorNotes) && strpos($transaction['fornecedor'], ' - ') !== false) {
                            $parts = explode(' - ', $transaction['fornecedor'], 2);
                            if (strpos(strtolower($parts[0]), 'pix') !== false || 
                                strpos(strtolower($parts[0]), 'transferência') !== false || 
                                strpos(strtolower($parts[0]), 'pagamento') !== false) {
                                $vendorNotes = $parts[0];
                                $processedVendor = $parts[1];
                            }
                        }
                        
                        $processedTransaction['_fornecedor_processed'] = trim($processedVendor);
                        $processedTransaction['_fornecedor_notes'] = $vendorNotes;
                    }
                    
                    $detailedResults[] = [
                        'original' => $originalTransaction,
                        'ai_analysis' => $transaction,
                        'processed' => $processedTransaction
                    ];
                }
            }
            
            return response()->json([
                'success' => true,
                'message' => 'Análise com IA concluída com sucesso',
                'provider_details' => [
                    'provider' => $provider,
                    'model' => $model,
                ],
                'count' => count($result['transactions']),
                'detailed_results' => $detailedResults
            ]);
            
        } catch (\Exception $e) {
            Log::error('❌ Erro no teste de IA', [
                'mensagem' => $e->getMessage(),
                'arquivo' => $e->getFile(),
                'linha' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return response()->json([
                'success' => false,
                'message' => 'Erro ao testar a API: ' . $e->getMessage(),
                'details' => [
                    'file' => $e->getFile(),
                    'line' => $e->getLine()
                ]
            ], 500);
        }
    }

    /**
     * Extrai nome do cliente a partir da descrição da transação
     * 
     * @param string $description Descrição da transação
     * @return string Nome do cliente extraído
     */
    private function extractClienteFromDescription($description)
    {
        if (empty($description)) {
            return '';
        }
        
        // Padrões comuns para extrair nomes de clientes em receitas
        $patterns = [
            '/pix\s+(?:recebido\s+)?(?:de|do|da)?\s+([A-Z][A-Za-z\s\.]+)/i',
            '/transfer[eê]ncia\s+(?:recebida\s+)?(?:de|do|da)?\s+([A-Z][A-Za-z\s\.]+)/i',
            '/recebido\s+(?:de|do|da)?\s+([A-Z][A-Za-z\s\.]+)/i',
            '/\-\s+([A-Z][A-Za-z\s\.]+)$/',
            '/\:\s+([A-Z][A-Za-z\s\.]+)$/',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $description, $matches)) {
                // Limpar o nome extraído
                $nome = trim($matches[1]);
                
                // Remover qualquer CPF/CNPJ do nome
                $nome = preg_replace('/\s+CPF\s+[\d\.\-\/]+/i', '', $nome);
                $nome = preg_replace('/\s+CNPJ\s+[\d\.\-\/]+/i', '', $nome);
                
                return trim($nome);
            }
        }
        
        // Se chegou aqui, não encontrou padrão conhecido
        // Dividir por hífen e pegar a última parte, se existir
        if (strpos($description, ' - ') !== false) {
            $parts = explode(' - ', $description);
            $lastPart = trim(end($parts));
            
            // Verificar se a última parte parece um nome (começa com maiúscula)
            if (preg_match('/^[A-Z]/', $lastPart)) {
                return $lastPart;
            }
        }
        
        return '';
    }
    
    /**
     * Extrai nome do fornecedor a partir da descrição da transação
     * 
     * @param string $description Descrição da transação
     * @return string Nome do fornecedor extraído
     */
    private function extractFornecedorFromDescription($description)
    {
        if (empty($description)) {
            return '';
        }
        
        // Padrões comuns para extrair nomes de fornecedores em despesas
        $patterns = [
            '/pix\s+(?:enviado\s+)?(?:para|ao|à)?\s+([A-Z][A-Za-z\s\.]+)/i',
            '/transfer[eê]ncia\s+(?:enviada\s+)?(?:para|ao|à)?\s+([A-Z][A-Za-z\s\.]+)/i',
            '/pagamento\s+(?:para|ao|à)?\s+([A-Z][A-Za-z\s\.]+)/i',
            '/compra\s+(?:em|no|na)?\s+([A-Z][A-Za-z\s\.]+)/i',
            '/\-\s+([A-Z][A-Za-z\s\.]+)$/',
            '/\:\s+([A-Z][A-Za-z\s\.]+)$/',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $description, $matches)) {
                // Limpar o nome extraído
                $nome = trim($matches[1]);
                
                // Remover qualquer CPF/CNPJ do nome
                $nome = preg_replace('/\s+CPF\s+[\d\.\-\/]+/i', '', $nome);
                $nome = preg_replace('/\s+CNPJ\s+[\d\.\-\/]+/i', '', $nome);
                
                return trim($nome);
            }
        }
        
        // Se chegou aqui, não encontrou padrão conhecido
        // Dividir por hífen e pegar a última parte, se existir
        if (strpos($description, ' - ') !== false) {
            $parts = explode(' - ', $description);
            $lastPart = trim(end($parts));
            
            // Verificar se a última parte parece um nome (começa com maiúscula)
            if (preg_match('/^[A-Z]/', $lastPart)) {
                return $lastPart;
            }
        }
        
        return '';
    }

    private function getSystemPrompt()
    {
        return <<<EOT
Você é um assistente especializado em análise financeira para uma plataforma de gestão financeira. Seu papel é analisar transações financeiras de extratos bancários e fornecer informações estruturadas para cada transação.

### FORMATO DE RESPOSTA OBRIGATÓRIO
Você DEVE responder APENAS com um objeto JSON válido contendo um array "transactions", onde cada item representa uma transação analisada. Não inclua textos introdutórios, explicações ou qualquer outro conteúdo fora do objeto JSON. Exemplo de formato:

```json
{
  "transactions": [
    {
      "id": 0,
      "type": "expense",
      "suggested_category": "Alimentação",
      "cliente": "",
      "fornecedor": "Supermercado XYZ",
      "notes": "CNPJ: 12.345.678/0001-99 | Compra realizada com cartão de crédito final 1234",
      "original_index": 0
    },
    {
      "id": 1,
      "type": "income",
      "suggested_category": "Venda",
      "cliente": "João Silva",
      "fornecedor": "",
      "notes": "Pagamento de fatura #12345 | Transferência recebida via PIX",
      "original_index": 1
    }
  ]
}
```

### INSTRUÇÕES DE ANÁLISE
1. Para cada transação:
   - Mantenha o campo "id" e "original_index" exatamente como recebido
   - Identifique o "type" como "income" (receita) ou "expense" (despesa)
   - Sugira uma categoria apropriada no campo "suggested_category"
   - Para transações do tipo "income", identifique o cliente no campo "cliente" e deixe "fornecedor" vazio
   - Para transações do tipo "expense", identifique o fornecedor no campo "fornecedor" e deixe "cliente" vazio
   - No campo "notes", inclua SEMPRE informações relevantes como:
     * CPF/CNPJ quando disponível
     * Número do cartão (apenas os últimos 4 dígitos)
     * Tipo de transação (PIX, TED, DOC, cartão de crédito/débito)
     * Número de referência ou código da transação
     * Qualquer informação adicional que ajude a identificar a transação

2. Análise detalhada:
   - Examine o texto da descrição para identificar nomes de pessoas ou empresas
   - Procure por padrões que identifiquem instituições financeiras, empresas ou pessoas
   - Extraia números de documentos (CPF/CNPJ) quando disponíveis
   - Identifique padrões de transações frequentes (ex: pagamentos de contas, compras, transferências)
   - SEMPRE inclua observações relevantes no campo "notes", mesmo que seja apenas o tipo de transação

### CÓDIGOS E IDENTIFICADORES
Para o campo "notes", procure por:
   - CPF/CNPJ: Números no formato 000.000.000-00 ou 00.000.000/0001-00
   - Cartões: Últimos 4 dígitos após "final" ou "cartão"
   - Códigos: Números após "ref", "código", "id" ou "#"
   - Tipos de transação: PIX, TED, DOC, cartão de crédito/débito
EOT;
    }

    /**
     * Calcula o tamanho ideal do lote com base no número total de transações
     * 
     * @param int $totalTransactions Número total de transações
     * @return int Tamanho ideal do lote
     */
    private function calculateOptimalBatchSize($totalTransactions) 
    {
        // Para transações muito pequenas, processe tudo de uma vez
        if ($totalTransactions <= 5) {
            return $totalTransactions;
        }
        
        // Para conjuntos de dados grandes, use lotes menores para evitar timeout
        if ($totalTransactions > 100) {
            return 8; 
        }
        
        if ($totalTransactions > 50) {
            return 10;
        }
        
        if ($totalTransactions > 20) {
            return 15;
        }
        
        // Para conjuntos médios, use lotes de tamanho moderado
        return 20;
    }

    /**
     * Carrega todas as configurações de IA disponíveis
     * @return \Illuminate\Database\Eloquent\Collection Coleção de objetos ModelApiKey ordenados por prioridade
     */
    private function loadAllActiveConfigurations()
    {
        try {
            // Buscar todas as configurações ativas como objetos Eloquent
            $configs = \App\Models\ModelApiKey::where('is_active', true)->get();

            // **** DEBUG LOG ****
            Log::debug('[DEBUG Fallback Load] Resultado da query ModelApiKey::where(is_active, true)', [
                'count' => $configs->count(),
                'sql' => \App\Models\ModelApiKey::where('is_active', true)->toSql(), // Mostrar SQL gerado
                'bindings' => \App\Models\ModelApiKey::where('is_active', true)->getBindings() // Mostrar bindings
            ]);
            // **** END DEBUG ****

            if ($configs->isEmpty()) {
                Log::warning('Nenhuma configuração de IA ativa encontrada em model_api_keys');
                
                // Tentar buscar configurações de OpenRouter como fallback
                try {
                    $openRouterConfigs = \App\Models\OpenRouterConfig::all();
                    if ($openRouterConfigs->isNotEmpty()) {
                        Log::info('Encontradas configurações OpenRouter que podem ser usadas como fallback', ['total' => $openRouterConfigs->count()]);
                        
                        // Converter OpenRouterConfigs em ModelApiKey compatíveis
                        $convertedConfigs = $openRouterConfigs->map(function($config) {
                            $modelApiKey = new \App\Models\ModelApiKey();
                            $modelApiKey->provider = $config->provider;
                            $modelApiKey->model = $config->model;
                            $modelApiKey->api_token = $config->api_key;
                            $modelApiKey->system_prompt = $config->system_prompt;
                            $modelApiKey->is_active = true;
                            // Não salvar, apenas criar um objeto temporário
                            return $modelApiKey;
                        });
                        
                        return $convertedConfigs;
                    }
                } catch (\Exception $e) {
                    Log::error('Erro ao tentar carregar configurações OpenRouter como fallback', ['error' => $e->getMessage()]);
                }
                
                return collect(); // Retornar coleção vazia se não houver configs
            }

            // Definir prioridade dos provedores
            $providerPriority = [
                'gemini' => 1, 'google' => 1, 'anthropic' => 2, 'openai' => 3, 'openrouter' => 4, 'deepseek' => 5
            ];

            // Ordenar a coleção com base na prioridade
            $sortedConfigs = $configs->sortBy(function($config) use ($providerPriority) {
                return $providerPriority[$config->provider] ?? 99;
            });

            Log::info('Configurações de IA carregadas e ordenadas', [
                'total' => $sortedConfigs->count(),
                'principais' => $sortedConfigs->take(3)->map(fn($c) => $c->provider.'/'.$c->model)->toArray()
            ]);

            return $sortedConfigs; // Retornar a coleção ordenada de objetos

        } catch (\Exception $e) { // Use base Exception
            Log::error('Erro ao carregar configs de IA: ' . $e->getMessage());
            return collect(); // Retornar coleção vazia em caso de erro
        }
    }

    /**
     * Tenta analisar transações usando todas as IAs disponíveis em ordem de prioridade
     * @param array $transactions Transações para analisar
     * @param \App\Models\ModelApiKey|null $failedConfig O objeto ModelApiKey da configuração que falhou inicialmente (opcional)
     * @return array|null Resultado da análise ou null em caso de falha completa
     */
    private function tryAnalysisWithAllAvailableProviders($transactions, $failedConfig = null)
    {
        // Carrega a coleção de objetos ModelApiKey
        $allConfigs = $this->loadAllActiveConfigurations();

        // Filtrar a configuração que falhou inicialmente, se fornecida
        $filteredConfigs = $allConfigs; // Começa com todas as configs
        if ($failedConfig && $failedConfig instanceof \App\Models\ModelApiKey && $failedConfig->id) {
            // Filtra a coleção para remover o objeto com o ID que falhou
            $filteredConfigs = $allConfigs->filter(function($config) use ($failedConfig) {
                return $config->id !== $failedConfig->id;
            });
             Log::info('Configuração que falhou inicialmente foi removida da lista de fallback', ['failed_id' => $failedConfig->id]);
        } elseif ($failedConfig && !($failedConfig instanceof \App\Models\ModelApiKey) && isset($failedConfig->provider)) {
            // Se for um objeto de outro tipo (ex: OpenRouterConfig convertido), filtrar por propriedades
            $filteredConfigs = $allConfigs->filter(function($config) use ($failedConfig) {
                return !($config->provider === $failedConfig->provider && 
                       $config->model === $failedConfig->model);
            });
            Log::info('Configuração que falhou inicialmente foi removida da lista por propriedades', [
                'failed_provider' => $failedConfig->provider,
                'failed_model' => $failedConfig->model
            ]);
        }

        if ($filteredConfigs->isEmpty()) {
            Log::warning('Sem configurações de IA *alternativas* ativas para tentar fallback. Usando resposta simulada.', [
                'failed_provider' => $failedConfig->provider ?? 'N/A',
                'failed_model' => $failedConfig->model ?? 'N/A'
            ]);
            return $this->getMockAIResponse($transactions);
        }

        // Logar as configurações alternativas disponíveis
        Log::info('Tentando fallback com configurações alternativas', [
            'total_configs' => $filteredConfigs->count(),
            'providers' => $filteredConfigs->pluck('provider')->toArray(),
            'models' => $filteredConfigs->pluck('model')->toArray(),
        ]);

        $batchSize = 8;
        $batches = array_chunk($transactions, $batchSize);
        $totalBatches = count($batches);

        // Itera sobre a coleção filtrada de objetos ModelApiKey
        foreach ($filteredConfigs as $config) { // $config é agora um objeto ModelApiKey
            Log::info('🔄 Tentando fallback com ' . $config->provider . '/' . $config->model);
            $processedTransactionsBatch = [];
            $allBatchesSuccess = true;

            try {
                foreach ($batches as $index => $batch) {
                    $currentBatch = $index + 1;
                    Log::debug('Processando lote ' . $currentBatch . ' de ' . $totalBatches . ' com fallback ' . $config->provider);

                    $result = null;
                    // Usar o objeto $config diretamente
                    switch (strtolower($config->provider)) {
                        case 'google':
                        case 'gemini':
                            $result = $this->analyzeTransactionsWithGemini($batch, $config); // Passa o objeto
                            break;
                        case 'openai':
                             Log::warning('Método analyzeTransactionsWithOpenAI não implementado para fallback');
                             $allBatchesSuccess = false;
                             break 2;
                        case 'anthropic':
                            Log::warning('Método analyzeTransactionsWithAnthropic não implementado para fallback');
                            $allBatchesSuccess = false;
                            break 2;
                        case 'openrouter':
                            $result = $this->analyzeTransactionsWithOpenRouter($batch, $config); // Passa o objeto
                            break;
                        case 'grok':
                            $result = $this->analyzeTransactionsWithGrok($batch, $config); // Passa o objeto
                            break;
                        default:
                            // Se o provedor não for reconhecido, tentar usar OpenRouter como genérico
                            Log::warning('Provedor não suportado diretamente: ' . $config->provider . '. Tentando via OpenRouter.');
                            try {
                                $result = $this->analyzeTransactionsWithOpenRouter($batch, $config);
                            } catch (\Exception $e) {
                                Log::error('Falha ao usar OpenRouter para provedor desconhecido: ' . $e->getMessage());
                                $allBatchesSuccess = false;
                                break 2;
                            }
                            break;
                    }

                    // Verificar resultado do lote
                    if ($result && isset($result['transactions']) && is_array($result['transactions'])) {
                         $processedTransactionsBatch = array_merge($processedTransactionsBatch, $result['transactions']);
                         Log::info('Lote ' . $currentBatch . ' processado com sucesso com fallback ' . $config->provider);
                     } else {
                         Log::warning('Falha ou resposta inválida no lote ' . $currentBatch . ' com fallback ' . $config->provider);
                         $allBatchesSuccess = false;
                         break; // Falhou em um lote, tentar próximo provedor
                     }
                } // Fim do loop de lotes

                if ($allBatchesSuccess) {
                    Log::info('🎉 Fallback bem-sucedido com ' . $config->provider . '/' . $config->model);
                    return ['transactions' => $processedTransactionsBatch];
                }

            } catch (\Exception $e) { // Use base Exception
                Log::error('❌ Falha completa no fallback com ' . $config->provider . ': ' . $e->getMessage());
                continue;
            }
        } // Fim do loop de provedores

        Log::error('❌ Nenhuma IA conseguiu processar as transações após todas as tentativas de fallback. Usando mock final.');
        return $this->getMockAIResponse($transactions);
    }
    
    /**
     * Cria uma resposta mock/simulada simples quando todas as IAs falham
     * @param array $transactions Lista de transações para simular análise
     * @return array Resposta simulada no formato esperado
     */
    private function getMockAIResponse($transactions)
    {
        // Implementação do método para gerar respostas simuladas de IA
        // Este é um placeholder - a implementação real dependeria do formato esperado
        
        $response = [
            'transactions' => [],
            'is_mock_response' => true  // Flag para identificar que é uma resposta simulada
        ];
        
        foreach ($transactions as $index => $transaction) {
            $amount = $transaction['amount'] ?? 0;
            $type = $transaction['type'] ?? 'expense';
            $description = $transaction['description'] ?? '';
            
            // Tentar extrair informações básicas da descrição
            $cliente = null;
            $fornecedor = null;
            $notes = [];
            
            // Extrair possível nome de cliente/fornecedor da descrição
            if (preg_match('/(?:pix|ted|doc|transferência)(.*?)(cnpj|cpf|ag[êe]ncia|conta|\d{2}\.\d{3}\.\d{3}\/\d{4}|\d{3}\.\d{3}\.\d{3}\-\d{2}|$)/i', $description, $matches)) {
                $entityName = trim($matches[1]);
                if (strlen($entityName) > 3) {
                    if ($type == 'income') {
                        $cliente = $entityName;
                    } else {
                        $fornecedor = $entityName;
                    }
                }
            }
            
            // Extrair tipo de transação
            if (preg_match('/(pix|ted|doc|transferência|cartão|cartao|crédito|credito|débito|debito)/i', $description, $matches)) {
                $notes[] = ucfirst(strtolower($matches[1]));
            }
            
            // Extrair número do cartão
            if (preg_match('/(?:final|cartão|cartao)\s*(\d{4})/i', $description, $matches)) {
                $notes[] = "Cartão final {$matches[1]}";
            }
            
            // Extrair CPF/CNPJ
            if (preg_match('/(\d{2}\.\d{3}\.\d{3}\/\d{4}|\d{3}\.\d{3}\.\d{3}\-\d{2})/', $description, $matches)) {
                $notes[] = $matches[1];
            }
            
            // Extrair código de referência
            if (preg_match('/(?:ref|código|codigo|id|#)\s*([a-zA-Z0-9]+)/i', $description, $matches)) {
                $notes[] = "Ref: {$matches[1]}";
            }
            
            // Se não encontrou nenhuma informação específica, adicionar a descrição completa
            if (empty($notes)) {
                $notes[] = $description;
            }
            
            $response['transactions'][] = [
                'id' => $index,
                'type' => $type,
                'category_id' => null,
                'suggested_category' => $type == 'income' ? 'Receita Diversa' : 'Despesa Diversa',
                'cliente' => $cliente,
                'fornecedor' => $fornecedor,
                'notes' => implode(' | ', $notes),
                'original_index' => $index
            ];
        }
        
        Log::info('✅ Resposta simulada gerada com sucesso', [
            'num_transactions' => count($response['transactions'])
        ]);
        
        return $response;
    }
}
