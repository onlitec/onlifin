<?php

namespace App\Livewire;

use Livewire\Component;
use Carbon\Carbon;
use App\Models\Transaction;
use App\Models\Account;

class Dashboard extends Component
{
    public function render()
    {
        // Remover a referência à view de teste
        return view('livewire.dashboard');
    }
} 