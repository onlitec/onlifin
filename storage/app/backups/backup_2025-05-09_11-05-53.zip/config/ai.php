<?php

return [
    'enabled' => env('AI_ENABLED', false),
    'provider' => env('AI_PROVIDER', 'openai'),
    
    // Configurações gerais por provedor
    'openai' => [
        'api_key' => env('OPENAI_API_KEY'),
        'model' => env('OPENAI_MODEL', 'gpt-3.5-turbo'),
    ],
    'anthropic' => [
        'api_key' => env('ANTHROPIC_API_KEY'),
        'model' => env('ANTHROPIC_MODEL', 'claude-3-sonnet-20240229'),
    ],
    'gemini' => [
        'api_key' => env('GEMINI_API_KEY'),
        'model' => env('GEMINI_MODEL', 'gemini-1.5-pro'),
    ],
    
    // Lista de provedores e seus modelos para a interface
    'providers' => [
        'microsoft' => [
            'name' => 'Microsoft',
            'models' => [
                'microsoft/phi-4-reasoning:free',
                'microsoft/mai-ds-r1:free'
            ],
            'icon' => 'ri-microsoft-fill'
        ],
        'qwen' => [
            'name' => 'Qwen',
            'models' => [
                'qwen/qwen3-0.6b-04-28:free',
                'qwen/qwen3-1.7b:free',
                'qwen/qwen3-4b:free',
                'qwen/qwen3-8b:free',
                'qwen/qwen3-14b:free',
                'qwen/qwen3-30b-a3b:free',
                'qwen/qwen3-32b:free',
                'qwen/qwen3-235b-a22b:free',
                'qwen/qwen2.5-vl-32b-instruct:free'
            ],
            'icon' => 'ri-robot-2-fill'
        ],
        'opengvlab' => [
            'name' => 'OpenGVLab',
            'models' => [
                'opengvlab/internvl3-14b:free',
                'opengvlab/internvl3-2b:free'
            ],
            'icon' => 'ri-lab-fill'
        ],
        'deepseek' => [
            'name' => 'DeepSeek',
            'models' => [
                'deepseek/deepseek-prover-v2:free',
                'deepseek/deepseek-chat-v3-0324:free',
                'deepseek/deepseek-chat:free'
            ],
            'icon' => 'ri-braces-fill'
        ],
        'tngtech' => [
            'name' => 'TNG Tech',
            'models' => [
                'tngtech/deepseek-r1t-chimera:free'
            ],
            'icon' => 'ri-cpu-fill'
        ],
        'thudm' => [
            'name' => 'THUDM',
            'models' => [
                'thudm/glm-z1-9b:free',
                'thudm/glm-4-9b:free',
                'thudm/glm-z1-32b:free',
                'thudm/glm-4-32b:free'
            ],
            'icon' => 'ri-robot-3-fill'
        ],
        'shisa' => [
            'name' => 'Shisa AI',
            'models' => [
                'shisa-ai/shisa-v2-llama3.3-70b:free'
            ],
            'icon' => 'ri-robot-2-fill'
        ],
        'nvidia' => [
            'name' => 'NVIDIA',
            'models' => [
                'nvidia/llama-3.3-nemotron-super-49b-v1:free'
            ],
            'icon' => 'ri-nvidia-fill'
        ],
        'meta' => [
            'name' => 'Meta',
            'models' => [
                'meta-llama/llama-4-maverick:free',
                'meta-llama/llama-4-scout:free',
                'meta-llama/llama-3.3-70b-instruct:free'
            ],
            'icon' => 'ri-meta-fill'
        ],
        'mistral' => [
            'name' => 'Mistral AI',
            'models' => [
                'mistralai/mistral-small-3.1-24b-instruct:free'
            ],
            'icon' => 'ri-cloud-fill'
        ],
        'openai' => [
            'name' => 'OpenAI',
            'models' => [
                'gpt-3.5-turbo',
                'gpt-4',
                'gpt-4-turbo-preview',
                'gpt-4o',
                'gpt-4o-mini'
            ],
            'icon' => 'ri-openai-fill'
        ],
        'anthropic' => [
            'name' => 'Anthropic Claude',
            'models' => [
                'claude-3-opus-20240229',
                'claude-3-sonnet-20240229'
            ],
            'icon' => 'ri-robot-fill'
        ],
        'gemini' => [
            'name' => 'Google Gemini',
            'models' => [
                'gemini-2.0-flash-exp:free',
                'gemini-1.5-flash',
                'gemini-1.5-pro',
                'gemini-pro',
                'gemini-pro-vision'
            ],
            'icon' => 'ri-google-fill'
        ],
        'moonshot' => [
            'name' => 'Moonshot AI',
            'models' => [
                'moonlight-16b-a3b-instruct'
            ],
            'icon' => 'ri-moon-fill'
        ],
        'gemma' => [
            'name' => 'Google Gemma',
            'models' => [
                'gemma-2-9b'
            ],
            'icon' => 'ri-google-fill'
        ],
        'llama' => [
            'name' => 'Meta Llama',
            'models' => [
                'llama-3.3-70b-instruct'
            ],
            'icon' => 'ri-meta-fill'
        ],
        'allenai' => [
            'name' => 'AllenAI',
            'models' => [
                'molmo-7b-d'
            ],
            'icon' => 'ri-robot-3-fill'
        ],
        'huggingface' => [
            'name' => 'Hugging Face',
            'models' => [
                'zephyr-7b'
            ],
            'icon' => 'ri-facebook-fill'
        ],
        'openrouter' => [
            'name' => 'OpenRouter',
            'models' => ['meta-llama/llama-3-70b-instruct', 'other-openrouter-models'],
            'icon' => 'ri-global-fill'
        ]
    ]
];
