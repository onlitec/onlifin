// Fallback script quando o Vite falhar em carregar
console.log('Fallback script carregado com sucesso!');

// Alpine.js polyfill
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM carregado');
    
    // Inicializar elementos básicos da UI
    const dropdowns = document.querySelectorAll('.dropdown-toggle');
    dropdowns.forEach(dropdown => {
        dropdown.addEventListener('click', function(e) {
            e.preventDefault();
            const parent = this.parentNode;
            const menu = parent.querySelector('.dropdown-menu');
            if (menu) {
                menu.classList.toggle('show');
            }
        });
    });
    
    // Fechar dropdowns quando clicar fora
    document.addEventListener('click', function(e) {
        if (!e.target.matches('.dropdown-toggle')) {
            document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
                menu.classList.remove('show');
            });
        }
    });
}); 