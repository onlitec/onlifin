/**
 * Desativa completamente o SweetAlert2 e seus popups
 * Este arquivo bloqueia todas as tentativas de exibição de alertas SweetAlert2
 */

(function() {
    function applySwalOverride() {
        // 1. Sobrescrever o método fire do SweetAlert2 para não fazer nada
        if (window.Swal) {
            console.log('SweetAlert2: Applying override...');
            
            // Preserve o objeto original para debugging, se ainda não foi preservado
            if (!window._originalSwal) {
                window._originalSwal = window.Swal;
            }
            
            // Sobrescrever os métodos do Swal
            window.Swal = {
                ...window._originalSwal, // Manter métodos originais que não queremos sobrescrever
                fire: function() {
                    console.log('SweetAlert2: Tentativa de fire() bloqueada');
                    removeSweetAlert2Popups(); // Limpeza extra ao tentar disparar
                    return Promise.resolve({
                        isConfirmed: false,
                        isDenied: false,
                        isDismissed: true
                    });
                },
                mixin: function() {
                    console.log('SweetAlert2: Tentativa de mixin() bloqueada');
                    return window.Swal;
                },
                stopTimer: function() {
                    console.log('SweetAlert2: Tentativa de stopTimer() bloqueada');
                },
                resumeTimer: function() {
                    console.log('SweetAlert2: Tentativa de resumeTimer() bloqueada');
                },
                showLoading: function() {
                    console.log('SweetAlert2: Tentativa de showLoading() bloqueada');
                },
                enableButtons: function() {
                    console.log('SweetAlert2: Tentativa de enableButtons() bloqueada');
                }
                // Adicione outros métodos que deseja bloquear, se necessário
            };
            console.log('SweetAlert2: Override applied.');
        } else {
             console.log('SweetAlert2: window.Swal not found for override.');
        }
    }

    // 2. Remover qualquer popup existente
    function removeSweetAlert2Popups() {
        const sweetAlertElements = document.querySelectorAll('.swal2-container, .swal2-popup, .swal2-toast');
        if (sweetAlertElements.length > 0) {
            console.log('SweetAlert2: Removendo popups existentes:', sweetAlertElements.length);
            sweetAlertElements.forEach(el => el.remove());
        }
    }

    // Especialmente focado em remover os popups de sucesso
    function removeSuccessToasts() {
        const successToasts = document.querySelectorAll('.swal2-toast.swal2-icon-success');
        if (successToasts.length > 0) {
            console.log('SweetAlert2: Removendo popups de sucesso:', successToasts.length);
            successToasts.forEach(toast => {
                const container = toast.closest('.swal2-container');
                if (container) container.remove();
                toast.remove();
            });
        }
    }

    // 3. Executar a limpeza e aplicar override imediatamente
    applySwalOverride();
    removeSweetAlert2Popups();
    setInterval(removeSweetAlert2Popups, 100);
    setInterval(removeSuccessToasts, 50);

    // 4. Observar o DOM para remover novos popups imediatamente
    const observer = new MutationObserver((mutations) => {
        let needsCleanup = false;
        mutations.forEach((mutation) => {
            if (mutation.addedNodes && mutation.addedNodes.length > 0) {
                for (let i = 0; i < mutation.addedNodes.length; i++) {
                    const node = mutation.addedNodes[i];
                    if (node.classList && 
                        (node.classList.contains('swal2-container') || 
                         node.classList.contains('swal2-popup') || 
                         node.classList.contains('swal2-toast'))) {
                        node.remove();
                        needsCleanup = true;
                        console.log('SweetAlert2: Popup removido via MutationObserver');
                    }
                }
            }
        });
        if (needsCleanup) {
             // Limpeza adicional caso o observer pegue algo
             removeSweetAlert2Popups(); 
             removeSuccessToasts();
        }
    });

    // Iniciar o observador
    observer.observe(document.body, { childList: true, subtree: true });

    // 5. Adicionar manipulador de eventos para cliques nos botões de "Marcar como Pago"
    document.addEventListener('click', function(e) {
        if (e.target && (
            e.target.classList.contains('ri-checkbox-circle-line') || 
            (e.target.closest('button') && e.target.closest('button').title && 
             (e.target.closest('button').title.includes('Marcar como Pago') || 
              e.target.closest('button').title.includes('Marcar como Recebido')))
        )) {
            console.log('SweetAlert2: Mark as paid button clicked, scheduling cleanups.');
            setTimeout(removeSweetAlert2Popups, 50);
            setTimeout(removeSweetAlert2Popups, 100);
            setTimeout(removeSweetAlert2Popups, 200);
        }
    }, true);

    // 6. Reaplicar override após Livewire carregar
    document.addEventListener('livewire:load', function () {
        console.log('SweetAlert2: Livewire loaded, reapplying override.');
        applySwalOverride();
        removeSweetAlert2Popups(); // Limpeza extra após Livewire carregar
    });

    // 7. Executar limpeza no DOMContentLoaded também
    document.addEventListener('DOMContentLoaded', function() {
         console.log('SweetAlert2: DOMContentLoaded, ensuring cleanup.');
         removeSweetAlert2Popups();
         applySwalOverride(); // Garantir que o override está ativo
    });

})(); 